# Enterprise Observability Chatbot Backend

## Overview
This is the backend foundation for an enterprise observability chatbot. It connects to various observability tools (Prometheus, Elasticsearch, Jaeger) and a Large Language Model (LLM) to answer complex queries about system health, logs, and distributed traces.

## Architecture

```
+----------------+      +----------------+
|                |      |                |
|  User / UI     |<---->|   FastAPI App  |
|                |      |                |
+----------------+      +-------+--------+
                                |
        +-----------------------+-----------------------+
        |                       |                       |
+-------v--------+      +-------v--------+      +-------v--------+
|                |      |                |      |                |
|  Prometheus    |      | Elasticsearch  |      |     Jaeger     |
|  (Metrics)     |      |    (Logs)      |      |    (Traces)    |
+----------------+      +----------------+      +----------------+
                                |
                        +-------v--------+
                        |                |
                        |     LLM API    |
                        |                |
                        +----------------+
```

## Prerequisites
- Python 3.11+

## Quick Start
1. Create a virtual environment and install dependencies:
```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

2. Configure environment endpoints in `config/environments.yaml`

3. Run the development server:
```bash
uvicorn backend.main:app --reload
```

## Configuration
Configurations are managed via YAML file (`config/environments.yaml`). Each environment specifies connection details for different tools.

Set `OBS_CHATBOT_CONFIG_PATH` environment variable to override the configuration path.

## API Endpoints
- `POST /connect`: Initialize a session in a specific environment.
- `POST /chat`: Send a message and retrieve tool data or AI response.
- `GET /environments`: List available environments.

## Deployment Notes
- Containerize using Docker for consistent environment.
- Suitable for Kubernetes deployments behind an Ingress Controller.

## Troubleshooting
- Check tool endpoints accessibility if you see timeout errors.
- Ensure API tokens in `environments.yaml` are valid.

from pydantic import BaseModel, Field
from typing import Optional, Any
from enum import Enum

class IntentType(str, Enum):
    METRICS = "metrics"
    LOGS = "logs"
    TRACES = "traces"
    ENV_CHECK = "env_check"
    GENERAL = "general"

class PrometheusConfig(BaseModel):
    url: str
    token: str = ""
    default_step: str = "1m"
    timeout: int = 30

class ElasticsearchConfig(BaseModel):
    url: str
    token: str = ""
    index_pattern: str = "logs-*"
    timestamp_field: str = "@timestamp"
    max_results: int = 100
    timeout: int = 30

class JaegerConfig(BaseModel):
    url: str
    timeout: int = 30
    max_traces: int = 20

class LLMConfig(BaseModel):
    base_url: str
    api_key: str
    model: str = "gpt-4"
    temperature: float = 0.1
    max_tokens: int = 4096
    timeout: int = 60

class EnvironmentConfig(BaseModel):
    display_name: str
    prometheus: PrometheusConfig
    elasticsearch: ElasticsearchConfig
    jaeger: JaegerConfig
    llm: LLMConfig

class ConnectRequest(BaseModel):
    environment: str

class ConnectResponse(BaseModel):
    status: str  # "connected" or "error"
    environment: str
    display_name: str
    message: str
    tool_status: dict[str, bool] = {}  # {"prometheus": true, "elasticsearch": true, "jaeger": true}

class ChatRequest(BaseModel):
    message: str
    session_id: str

class DetectedIntent(BaseModel):
    type: IntentType
    description: str
    entities: dict[str, Any] = {}

class ToolResult(BaseModel):
    tool: str  # "prometheus", "elasticsearch", "jaeger"
    status: str  # "success" or "error"
    query_used: str = ""
    data: Any = None
    error: str = ""
    record_count: int = 0

class ChatResponse(BaseModel):
    session_id: str
    intents: list[DetectedIntent] = []
    tool_results: list[ToolResult] = []
    analysis: str = ""
    error: str = ""

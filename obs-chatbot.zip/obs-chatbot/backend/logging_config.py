"""
Structured JSON logging configuration with correlation ID support.
Every log entry includes a correlation_id (UUID_DDMMYYYY-HHMMSS) for request tracing.
"""

import logging
import json
import uuid
import contextvars
from datetime import datetime, timezone
from typing import Any, Optional

# Context variable for correlation ID - automatically inherited by async tasks
correlation_id_var: contextvars.ContextVar[str] = contextvars.ContextVar(
    "correlation_id", default="-"
)


def generate_correlation_id() -> str:
    """
    Generate a unique correlation ID in the format: UUID_DDMMYYYY-HHMMSS
    Example: a1b2c3d4-e5f6-7890-abcd-ef1234567890_01082026-231122
    """
    uid = str(uuid.uuid4())
    now = datetime.now(timezone.utc)
    timestamp_part = now.strftime("%d%m%Y-%H%M%S")
    return f"{uid}_{timestamp_part}"


def sanitize_value(value: Any) -> Any:
    """
    Remove special characters from log values.
    Ensures clean JSON output without ANSI codes or control characters.
    """
    if isinstance(value, str):
        # Remove ANSI escape codes
        import re
        value = re.sub(r"\x1b\[[0-9;]*m", "", value)
        # Remove other control characters except newline and tab
        value = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", value)
        return value
    elif isinstance(value, dict):
        return {k: sanitize_value(v) for k, v in value.items()}
    elif isinstance(value, (list, tuple)):
        return [sanitize_value(v) for v in value]
    return value


class JSONFormatter(logging.Formatter):
    """
    Custom JSON log formatter.
    Produces one JSON object per log line with correlation_id, timestamp, and structured data.
    """

    def format(self, record: logging.LogRecord) -> str:
        log_entry = {
            "timestamp": datetime.fromtimestamp(record.created, tz=timezone.utc).strftime(
                "%Y-%m-%dT%H:%M:%S.%fZ"
            ),
            "level": record.levelname,
            "logger": record.name,
            "correlation_id": correlation_id_var.get("-"),
            "message": sanitize_value(record.getMessage()),
        }

        # Add module and function info
        log_entry["module"] = record.module
        log_entry["function"] = record.funcName
        log_entry["line"] = record.lineno

        # Add exception info if present
        if record.exc_info and record.exc_info[0] is not None:
            log_entry["exception"] = sanitize_value(self.formatException(record.exc_info))

        # Add any extra fields passed via logger.info("msg", extra={"key": "val"})
        standard_attrs = {
            "name", "msg", "args", "created", "relativeCreated", "exc_info",
            "exc_text", "stack_info", "lineno", "funcName", "pathname",
            "filename", "module", "levelno", "levelname", "msecs",
            "thread", "threadName", "process", "processName", "message",
            "taskName",
        }
        for key, value in record.__dict__.items():
            if key not in standard_attrs and not key.startswith("_"):
                log_entry[key] = sanitize_value(value)

        return json.dumps(log_entry, default=str, ensure_ascii=True)


def setup_logging(level: int = logging.INFO) -> None:
    """
    Configure the root logger to use structured JSON output.
    Call this once at application startup before any other logging.
    """
    root_logger = logging.getLogger()

    # Remove any existing handlers
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)

    # Create console handler with JSON formatter
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(JSONFormatter())
    console_handler.setLevel(level)

    root_logger.setLevel(level)
    root_logger.addHandler(console_handler)

    # Suppress noisy third-party loggers
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)

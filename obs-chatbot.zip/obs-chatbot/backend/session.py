"""
Session manager for the observability chatbot.
Manages in-memory sessions with tool clients and conversation history.
"""

import logging
import uuid
import datetime
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from .models import EnvironmentConfig
from .tools import PrometheusClient, ELKClient, JaegerClient

logger = logging.getLogger(__name__)


@dataclass
class Session:
    """Represents an active user session with tool clients and history."""
    session_id: str
    environment: str
    config: EnvironmentConfig
    prometheus_client: PrometheusClient
    elk_client: ELKClient
    jaeger_client: JaegerClient
    created_at: str = field(default_factory=lambda: datetime.datetime.utcnow().isoformat())
    history: List[Dict[str, Any]] = field(default_factory=list)


class SessionManager:
    """Manages in-memory sessions keyed by session_id."""

    def __init__(self):
        self._sessions: Dict[str, Session] = {}

    def create_session(self, env_name: str, config: EnvironmentConfig) -> str:
        """
        Creates a new session, instantiates tool clients, and returns the session_id.
        """
        session_id = str(uuid.uuid4())
        logger.info(
            "Creating session",
            extra={"event": "session_create", "session_id": session_id, "environment": env_name},
        )

        prom_client = PrometheusClient(config.prometheus)
        elk_client = ELKClient(config.elasticsearch)
        jaeger_client = JaegerClient(config.jaeger)

        session = Session(
            session_id=session_id,
            environment=env_name,
            config=config,
            prometheus_client=prom_client,
            elk_client=elk_client,
            jaeger_client=jaeger_client,
        )
        self._sessions[session_id] = session
        return session_id

    def get_session(self, session_id: str) -> Optional[Session]:
        """
        Retrieves a session by ID. Returns None if not found.
        """
        session = self._sessions.get(session_id)
        if session is None:
            logger.warning(
                "Session not found",
                extra={"event": "session_not_found", "session_id": session_id},
            )
        return session

    async def destroy_session(self, session_id: str) -> None:
        """
        Closes httpx clients and removes the session.
        """
        if session_id in self._sessions:
            logger.info(
                "Destroying session",
                extra={"event": "session_destroy", "session_id": session_id},
            )
            session = self._sessions[session_id]
            await session.prometheus_client.close()
            await session.elk_client.close()
            await session.jaeger_client.close()
            del self._sessions[session_id]

    async def destroy_all_sessions(self) -> None:
        """
        Destroys all active sessions. Used during shutdown.
        """
        session_ids = list(self._sessions.keys())
        for sid in session_ids:
            await self.destroy_session(sid)
        logger.info(
            "All sessions destroyed during shutdown",
            extra={"event": "session_destroy_all", "count": len(session_ids)},
        )

    def add_to_history(self, session_id: str, role: str, content: str) -> None:
        """
        Appends a message to the conversation history.
        """
        session = self.get_session(session_id)
        if session:
            session.history.append({"role": role, "content": content})
            logger.debug(
                "Added message to session history",
                extra={"event": "session_history_add", "session_id": session_id, "role": role},
            )

    def get_history(self, session_id: str) -> List[Dict[str, Any]]:
        """
        Returns the conversation history for a session.
        """
        session = self.get_session(session_id)
        if session:
            return session.history
        return []

"""
LLM-powered query generator module.
Generates tool-specific queries (PromQL, Elasticsearch DSL, Jaeger params) from detected intents.
All operations are logged with correlation IDs.
"""

import httpx
import json
import logging
import asyncio
from typing import Any, Dict
from backend.models import LLMConfig, DetectedIntent

logger = logging.getLogger(__name__)


class QueryGenerator:
    def __init__(self, config: LLMConfig):
        self.config = config
        self.client = httpx.AsyncClient(timeout=config.timeout)

    async def _call_llm(self, system_prompt: str, user_prompt: str, operation: str) -> Dict[str, Any]:
        """Shared LLM call helper with structured logging."""
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

        payload = {
            "model": self.config.model,
            "messages": messages,
            "temperature": self.config.temperature,
            "max_tokens": self.config.max_tokens,
        }

        headers = {
            "Authorization": f"Bearer {self.config.api_key}",
            "Content-Type": "application/json",
        }

        logger.info(
            "Sending query generation request to LLM",
            extra={
                "event": "llm_request",
                "operation": operation,
                "llm_model": self.config.model,
                "user_prompt": user_prompt[:300],
            },
        )

        url = self.config.base_url.rstrip("/")
        if not url.endswith("/chat/completions"):
            url = f"{url}/chat/completions"

        max_retries = 3
        data = None
        for attempt in range(max_retries):
            try:
                response = await self.client.post(
                    url,
                    json=payload,
                    headers=headers,
                )
                if response.status_code == 429 and attempt < max_retries - 1:
                    wait_time = (attempt + 1) * 2
                    logger.warning(
                        "LLM rate limit (429) hit in query generation, retrying",
                        extra={"event": "llm_rate_limit_retry", "attempt": attempt + 1, "wait_time": wait_time},
                    )
                    await asyncio.sleep(wait_time)
                    continue
                response.raise_for_status()
                data = response.json()
                break
            except Exception as e:
                if attempt == max_retries - 1:
                    raise
                await asyncio.sleep(1)

        msg_obj = data["choices"][0]["message"]
        content = (msg_obj.get("content") or msg_obj.get("reasoning") or "").strip()

        logger.info(
            "LLM query generation response received",
            extra={
                "event": "llm_response",
                "operation": operation,
                "response_length": len(content),
                "raw_response": content[:500],
            },
        )

        if content.startswith("```json"):
            content = content[7:-3].strip()
        elif content.startswith("```"):
            content = content[3:-3].strip()

        parsed = json.loads(content)

        logger.info(
            "Query generated successfully",
            extra={
                "event": "query_generated",
                "operation": operation,
                "query": json.dumps(parsed, default=str)[:500],
            },
        )

        return parsed

    async def generate_prometheus_query(self, intent: DetectedIntent) -> Dict[str, Any]:
        """Generate PromQL query from intent."""
        system_prompt = """You are a PromQL expert. Your task is to generate a Prometheus query based on the user's intent and entities.
Return a JSON object with the following fields:
- "promql": The exact PromQL query string.
- "start": The start time (e.g. "-1h", "-30m", "-24h").
- "end": The end time (usually "now").
- "step": The step interval (e.g. "1m", "5m").
- "query_type": Either "range" or "instant".

Examples of PromQL:
- CPU usage for service: rate(container_cpu_usage_seconds_total{container="auth-service"}[5m])
- Error rate: sum(rate(http_requests_total{status=~"5.."}[5m])) by (service)

Always return ONLY valid JSON.
"""
        user_prompt = f"Intent: {intent.description}\nEntities: {json.dumps(intent.entities)}"

        try:
            return await self._call_llm(system_prompt, user_prompt, "prometheus_query_generation")
        except Exception:
            fallback = {
                "promql": f"up{{job=\"{intent.entities.get('service_name', 'default')}\"}}",
                "start": "-1h",
                "end": "now",
                "step": "1m",
                "query_type": "range",
            }
            logger.warning(
                "Using fallback Prometheus query",
                extra={"event": "query_fallback", "tool": "prometheus", "fallback_query": fallback},
            )
            return fallback

    async def generate_elk_query(self, intent: DetectedIntent, index_pattern: str, timestamp_field: str) -> Dict[str, Any]:
        """Generate Elasticsearch DSL from intent."""
        system_prompt = f"""You are an Elasticsearch Query DSL expert. Your task is to generate an Elasticsearch query based on the user's intent.
Index pattern: {index_pattern}
Timestamp field: {timestamp_field}

Return a JSON object with the following fields:
- "query_dsl": The exact Elasticsearch Query DSL JSON object (the part inside "query").
- "index": The index pattern to search.
- "size": The maximum number of results (e.g. 50).

Example query_dsl:
{{
  "bool": {{
    "must": [
      {{ "match": {{ "service": "auth-service" }} }},
      {{ "match": {{ "level": "error" }} }}
    ],
    "filter": [
      {{ "range": {{ "@timestamp": {{ "gte": "now-1h" }} }} }}
    ]
  }}
}}

Always return ONLY valid JSON.
"""
        user_prompt = f"Intent: {intent.description}\nEntities: {json.dumps(intent.entities)}"

        try:
            return await self._call_llm(system_prompt, user_prompt, "elasticsearch_query_generation")
        except Exception:
            fallback = {
                "query_dsl": {"match_all": {}},
                "index": index_pattern,
                "size": 50,
            }
            logger.warning(
                "Using fallback Elasticsearch query",
                extra={"event": "query_fallback", "tool": "elasticsearch", "fallback_query": fallback},
            )
            return fallback

    async def generate_jaeger_query(self, intent: DetectedIntent) -> Dict[str, Any]:
        """Generate Jaeger query params from intent."""
        system_prompt = """You are a Jaeger tracing expert. Your task is to generate query parameters for a Jaeger search based on the user's intent.
Return a JSON object with the following fields:
- "service": The name of the service.
- "operation": The name of the operation (optional).
- "tags": A dictionary of tags to filter by (optional).
- "limit": Max traces to return (e.g. 20).
- "lookback": Time lookback string (e.g. "1h", "2d").

Example:
{
  "service": "payment-api",
  "operation": "/checkout",
  "tags": {"error": "true"},
  "limit": 20,
  "lookback": "1h"
}

Always return ONLY valid JSON.
"""
        user_prompt = f"Intent: {intent.description}\nEntities: {json.dumps(intent.entities)}"

        try:
            return await self._call_llm(system_prompt, user_prompt, "jaeger_query_generation")
        except Exception:
            fallback = {
                "service": intent.entities.get("service_name", ""),
                "limit": 20,
                "lookback": "1h",
            }
            logger.warning(
                "Using fallback Jaeger query",
                extra={"event": "query_fallback", "tool": "jaeger", "fallback_query": fallback},
            )
            return fallback

    async def close(self):
        await self.client.aclose()

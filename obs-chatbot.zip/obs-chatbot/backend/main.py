"""
FastAPI application for the Observability Chatbot.
Orchestrates intent detection, query generation, tool execution, and result analysis.
All requests and responses are logged with structured JSON and correlation IDs.
"""

import logging
import asyncio
import time
import json
from pathlib import Path
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from starlette.middleware.base import BaseHTTPMiddleware
from typing import Dict, Any

from backend.models import (
    ConnectRequest, ConnectResponse, ChatRequest, ChatResponse,
    ToolResult, DetectedIntent, IntentType
)
from backend.config import load_config, get_environment, list_environments
from backend.session import SessionManager
from backend.intent import IntentDetector
from backend.query_generator import QueryGenerator
from backend.analyzer import ResultAnalyzer
from backend.logging_config import (
    setup_logging, generate_correlation_id, correlation_id_var
)

# Initialize structured JSON logging before anything else
setup_logging()

logger = logging.getLogger(__name__)

session_manager = SessionManager()

# Resolve paths relative to project root
PROJECT_ROOT = Path(__file__).resolve().parent.parent
FRONTEND_DIR = PROJECT_ROOT / "frontend"


# ──────────────────── Request/Response Logging Middleware ────────────────────


class RequestResponseLoggingMiddleware(BaseHTTPMiddleware):
    """
    Middleware that:
    1. Generates a correlation_id (UUID_DDMMYYYY-HHMMSS) for every request
    2. Sets it in contextvars so all downstream logs include it
    3. Logs the full request and response in structured JSON
    """

    async def dispatch(self, request: Request, call_next):
        # Generate and set correlation ID
        corr_id = generate_correlation_id()
        correlation_id_var.set(corr_id)

        start_time = time.time()

        # Read request body for POST methods
        request_body = None
        if request.method in ("POST", "PUT", "PATCH"):
            try:
                body_bytes = await request.body()
                request_body = json.loads(body_bytes.decode("utf-8"))
            except Exception:
                request_body = None

        # Log incoming request
        logger.info(
            "Incoming request",
            extra={
                "event": "http_request",
                "http_method": request.method,
                "http_path": str(request.url.path),
                "http_query": str(request.url.query) if request.url.query else None,
                "client_ip": request.client.host if request.client else None,
                "request_body": request_body,
            },
        )

        # Process request
        try:
            response = await call_next(request)
        except Exception as exc:
            duration_ms = round((time.time() - start_time) * 1000, 2)
            logger.error(
                "Request failed with exception",
                extra={
                    "event": "http_error",
                    "http_method": request.method,
                    "http_path": str(request.url.path),
                    "duration_ms": duration_ms,
                    "error": str(exc),
                },
            )
            raise

        duration_ms = round((time.time() - start_time) * 1000, 2)

        # Log response
        logger.info(
            "Request completed",
            extra={
                "event": "http_response",
                "http_method": request.method,
                "http_path": str(request.url.path),
                "http_status": response.status_code,
                "duration_ms": duration_ms,
            },
        )

        # Add correlation ID to response headers for client-side tracing
        response.headers["X-Correlation-ID"] = corr_id

        return response


# ──────────────────── App Setup ────────────────────


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan: startup and shutdown hooks."""
    try:
        config = load_config()
        envs = list_environments()
        logger.info(
            "Application startup complete",
            extra={
                "event": "app_startup",
                "environments_loaded": len(envs),
                "environment_keys": [e["key"] for e in envs],
            },
        )
    except Exception as e:
        logger.error(
            "Failed to load configuration on startup",
            extra={"event": "app_startup_error", "error": str(e)},
        )
    yield
    logger.info("Shutting down application", extra={"event": "app_shutdown"})
    await session_manager.destroy_all_sessions()


app = FastAPI(
    title="APIEngineering Intelligence - Observability Platform",
    description="Enterprise-grade observability chatbot with Prometheus, ELK, and Jaeger integration.",
    version="1.0.0",
    lifespan=lifespan,
)

# Add logging middleware first (outermost)
app.add_middleware(RequestResponseLoggingMiddleware)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ──────────────────── API Endpoints ────────────────────


@app.get("/api/environments")
async def get_environments_route():
    """List all available environments from the YAML configuration."""
    try:
        envs = list_environments()
        logger.info(
            "Listed environments",
            extra={"event": "list_environments", "count": len(envs)},
        )
        return envs
    except Exception as e:
        logger.error(
            "Failed to list environments",
            extra={"event": "list_environments_error", "error": str(e)},
        )
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/connect")
async def connect_route(req: ConnectRequest):
    """
    Connect to an environment: instantiate tool clients and run health checks.
    """
    logger.info(
        "Connect request received",
        extra={"event": "connect_start", "environment": req.environment},
    )

    try:
        env_config = get_environment(req.environment)
    except ValueError as e:
        logger.error(
            "Environment not found",
            extra={"event": "connect_error", "environment": req.environment, "error": str(e)},
        )
        raise HTTPException(status_code=404, detail=str(e))

    session_id = session_manager.create_session(req.environment, env_config)
    session = session_manager.get_session(session_id)

    # Run health checks in parallel
    prom_health = session.prometheus_client.health_check()
    elk_health = session.elk_client.health_check()
    jaeger_health = session.jaeger_client.health_check()

    results = await asyncio.gather(prom_health, elk_health, jaeger_health, return_exceptions=True)

    prom_ok = results[0] if not isinstance(results[0], Exception) else False
    elk_ok = results[1] if not isinstance(results[1], Exception) else False
    jaeger_ok = results[2] if not isinstance(results[2], Exception) else False

    tool_status = {
        "prometheus": bool(prom_ok),
        "elasticsearch": bool(elk_ok),
        "jaeger": bool(jaeger_ok),
    }

    all_ok = all(tool_status.values())
    some_ok = any(tool_status.values())

    if all_ok:
        message = "All tools connected successfully."
    elif some_ok:
        failed = [k for k, v in tool_status.items() if not v]
        message = f"Connected with warnings. Unavailable tools: {', '.join(failed)}"
    else:
        message = "Connected but all tool health checks failed. Queries may return errors."

    response_data = {
        "status": "connected",
        "environment": req.environment,
        "display_name": env_config.display_name,
        "message": message,
        "tool_status": tool_status,
        "session_id": session_id,
    }

    logger.info(
        "Connect completed",
        extra={
            "event": "connect_complete",
            "session_id": session_id,
            "environment": req.environment,
            "tool_status": tool_status,
            "status_message": message,
        },
    )

    return response_data


@app.post("/api/disconnect")
async def disconnect_route(req: Dict[str, str]):
    """Disconnect from environment and destroy the session."""
    session_id = req.get("session_id")
    if not session_id:
        raise HTTPException(status_code=400, detail="session_id required")

    logger.info(
        "Disconnect request received",
        extra={"event": "disconnect_start", "session_id": session_id},
    )

    try:
        await session_manager.destroy_session(session_id)
        logger.info(
            "Disconnect completed",
            extra={"event": "disconnect_complete", "session_id": session_id},
        )
        return {"status": "disconnected"}
    except Exception as e:
        logger.error(
            "Disconnect failed",
            extra={"event": "disconnect_error", "session_id": session_id, "error": str(e)},
        )
        raise HTTPException(status_code=500, detail=str(e))


async def _execute_single_intent(
    intent: DetectedIntent,
    session,
    generator: QueryGenerator,
    max_retries: int = 2,
) -> ToolResult:
    """
    Execute a single intent: generate query via LLM, run against tool, retry on failure.
    """
    tool_name = {
        IntentType.METRICS: "prometheus",
        IntentType.LOGS: "elasticsearch",
        IntentType.TRACES: "jaeger",
        IntentType.GENERAL: "general",
    }.get(intent.type, "unknown")

    if intent.type == IntentType.GENERAL:
        logger.info(
            "Skipping tool execution for general intent",
            extra={"event": "intent_skip", "tool": "general", "description": intent.description},
        )
        return ToolResult(tool="general", status="success", data=intent.description)

    for attempt in range(max_retries + 1):
        try:
            logger.info(
                "Executing intent",
                extra={
                    "event": "intent_execute",
                    "tool": tool_name,
                    "attempt": attempt + 1,
                    "max_attempts": max_retries + 1,
                    "description": intent.description,
                },
            )

            if intent.type == IntentType.METRICS:
                if not session.prometheus_client:
                    return ToolResult(tool="prometheus", status="error", error="Prometheus not configured")
                query = await generator.generate_prometheus_query(intent)
                logger.info(
                    "Generated Prometheus query",
                    extra={"event": "query_generated", "tool": "prometheus", "query": query},
                )
                res = await session.prometheus_client.execute(query)

            elif intent.type == IntentType.LOGS:
                if not session.elk_client:
                    return ToolResult(tool="elasticsearch", status="error", error="Elasticsearch not configured")
                elk_config = session.config.elasticsearch
                query = await generator.generate_elk_query(
                    intent,
                    index_pattern=elk_config.index_pattern,
                    timestamp_field=elk_config.timestamp_field,
                )
                logger.info(
                    "Generated Elasticsearch query",
                    extra={"event": "query_generated", "tool": "elasticsearch", "query": str(query)[:500]},
                )
                res = await session.elk_client.execute(query)

            elif intent.type == IntentType.TRACES:
                if not session.jaeger_client:
                    return ToolResult(tool="jaeger", status="error", error="Jaeger not configured")
                query = await generator.generate_jaeger_query(intent)
                logger.info(
                    "Generated Jaeger query",
                    extra={"event": "query_generated", "tool": "jaeger", "query": query},
                )
                res = await session.jaeger_client.execute(query)

            elif intent.type == IntentType.ENV_CHECK:
                prom_health = await session.prometheus_client.health_check() if session.prometheus_client else False
                elk_res = await session.elk_client.health_check() if session.elk_client else {}
                elk_health = elk_res.get("healthy", False) if isinstance(elk_res, dict) else False
                jaeger_health = await session.jaeger_client.health_check() if session.jaeger_client else False

                verified_data = {
                    "environment": session.environment,
                    "display_name": session.config.display_name,
                    "verified": True,
                    "last_verified": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                    "services": {
                        "prometheus": "healthy" if prom_health else "unreachable",
                        "elasticsearch": "healthy" if elk_health else "unreachable",
                        "jaeger": "healthy" if jaeger_health else "unreachable",
                    }
                }
                return ToolResult(
                    tool="env_check",
                    status="success",
                    query_used="GET /health verification",
                    data=verified_data,
                    record_count=3
                )

            else:
                return ToolResult(tool=tool_name, status="error", error="Unknown intent type")

            # Log tool response
            logger.info(
                "Tool execution result",
                extra={
                    "event": "tool_result",
                    "tool": tool_name,
                    "status": res.get("status"),
                    "record_count": res.get("record_count", 0),
                    "error": res.get("error", None),
                },
            )

            if res.get("status") == "success":
                return ToolResult(
                    tool=tool_name,
                    status="success",
                    query_used=res.get("query_used", ""),
                    data=res.get("data"),
                    record_count=res.get("record_count", 0),
                )
            else:
                error_msg = res.get("error", "Unknown tool error")
                logger.warning(
                    "Tool returned error, will retry",
                    extra={
                        "event": "tool_error_retry",
                        "tool": tool_name,
                        "attempt": attempt + 1,
                        "error": error_msg,
                    },
                )
                if attempt < max_retries:
                    await asyncio.sleep(0.5)
                    continue
                return ToolResult(
                    tool=tool_name,
                    status="error",
                    query_used=res.get("query_used", ""),
                    error=error_msg,
                )

        except Exception as e:
            logger.error(
                "Exception during tool execution",
                extra={
                    "event": "tool_exception",
                    "tool": tool_name,
                    "attempt": attempt + 1,
                    "error": str(e),
                },
            )
            if attempt < max_retries:
                await asyncio.sleep(0.5)
                continue
            return ToolResult(tool=tool_name, status="error", error=str(e))

    return ToolResult(tool=tool_name, status="error", error="Max retries reached")


@app.post("/api/chat", response_model=ChatResponse)
async def chat_route(req: ChatRequest):
    """
    Main chat endpoint: detect intents, generate queries, execute tools, analyze results.
    """
    logger.info(
        "Chat request received",
        extra={
            "event": "chat_start",
            "session_id": req.session_id,
            "user_message": req.message,
        },
    )

    session = session_manager.get_session(req.session_id)
    if not session:
        logger.error(
            "Session not found for chat request",
            extra={"event": "chat_session_missing", "session_id": req.session_id},
        )
        raise HTTPException(status_code=404, detail="Session not found. Please reconnect.")

    session_manager.add_to_history(req.session_id, "user", req.message)

    # Create LLM-powered components using the session's LLM config
    llm_config = session.config.llm
    intent_detector = IntentDetector(llm_config)
    query_generator = QueryGenerator(llm_config)
    result_analyzer = ResultAnalyzer(llm_config)

    try:
        # Step 1: Detect intents
        history = session_manager.get_history(req.session_id)
        intents = await intent_detector.detect(req.message, history)

        if not intents:
            intents = [DetectedIntent(type=IntentType.GENERAL, description=req.message, entities={})]

        logger.info(
            "Intents detected",
            extra={
                "event": "intents_detected",
                "session_id": req.session_id,
                "intent_count": len(intents),
                "intents": [{"type": i.type.value, "description": i.description} for i in intents],
            },
        )

        # Step 2: Execute all intents in parallel
        tasks = [
            _execute_single_intent(intent, session, query_generator)
            for intent in intents
            if intent.type != IntentType.GENERAL
        ]

        tool_results_raw = await asyncio.gather(*tasks, return_exceptions=True)

        # Collect results
        tool_results = []
        for r in tool_results_raw:
            if isinstance(r, Exception):
                tool_results.append(ToolResult(tool="unknown", status="error", error=str(r)))
            else:
                tool_results.append(r)

        # Step 3: Construct safe environment context (no tokens/keys) and analyze results
        env_context = {
            "environment": session.environment,
            "display_name": session.config.display_name,
            "prometheus_url": session.config.prometheus.url,
            "elasticsearch_url": session.config.elasticsearch.url,
            "elasticsearch_index_pattern": session.config.elasticsearch.index_pattern,
            "jaeger_url": session.config.jaeger.url,
            "connected_at": session.created_at,
        }

        analysis = ""
        if tool_results:
            analysis = await result_analyzer.analyze(req.message, tool_results, env_context=env_context, history=history)
        else:
            analysis = await result_analyzer.respond_general(req.message, env_context=env_context, history=history)

        session_manager.add_to_history(req.session_id, "assistant", analysis)

        response = ChatResponse(
            session_id=req.session_id,
            intents=intents,
            tool_results=tool_results,
            analysis=analysis,
        )

        logger.info(
            "Chat response sent",
            extra={
                "event": "chat_complete",
                "session_id": req.session_id,
                "intent_count": len(intents),
                "tool_result_count": len(tool_results),
                "tool_statuses": {r.tool: r.status for r in tool_results},
                "analysis_length": len(analysis),
            },
        )

        return response

    except Exception as e:
        logger.error(
            "Chat processing failed",
            extra={
                "event": "chat_error",
                "session_id": req.session_id,
                "error": str(e),
            },
            exc_info=True,
        )
        error_msg = f"An error occurred: {str(e)}"
        session_manager.add_to_history(req.session_id, "assistant", error_msg)
        return ChatResponse(session_id=req.session_id, error=error_msg)
    finally:
        await intent_detector.close()
        await query_generator.close()
        await result_analyzer.close()


@app.post("/api/chat/stream")
async def chat_stream_route(req: ChatRequest):
    """
    SSE Streaming Chat Endpoint:
    1. Detects intents & executes tools in parallel
    2. Emits initial JSON event with detected intents & executed tool results
    3. Streams LLM response token by token as SSE data events
    """
    logger.info(
        "Chat stream request received",
        extra={
            "event": "chat_stream_start",
            "session_id": req.session_id,
            "user_message": req.message,
        },
    )

    session = session_manager.get_session(req.session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found. Please reconnect.")

    session_manager.add_to_history(req.session_id, "user", req.message)

    llm_config = session.config.llm
    intent_detector = IntentDetector(llm_config)
    query_generator = QueryGenerator(llm_config)
    result_analyzer = ResultAnalyzer(llm_config)

    async def event_generator():
        try:
            # Step 1: Detect intents
            history = session_manager.get_history(req.session_id)
            intents = await intent_detector.detect(req.message, history)
            if not intents:
                intents = [DetectedIntent(type=IntentType.GENERAL, description=req.message, entities={})]

            # Step 2: Execute all intents in parallel
            tasks = [
                _execute_single_intent(intent, session, query_generator)
                for intent in intents
                if intent.type != IntentType.GENERAL
            ]
            tool_results_raw = await asyncio.gather(*tasks, return_exceptions=True)

            tool_results = []
            for r in tool_results_raw:
                if isinstance(r, Exception):
                    tool_results.append(ToolResult(tool="unknown", status="error", error=str(r)))
                else:
                    tool_results.append(r)

            # Step 3: Emit meta event
            meta_payload = {
                "event": "meta",
                "session_id": req.session_id,
                "intents": [i.model_dump() for i in intents],
                "tool_results": [t.model_dump() for t in tool_results]
            }
            yield f"data: {json.dumps(meta_payload)}\n\n"

            # Step 4: Stream LLM response
            env_context = {
                "environment": session.environment,
                "display_name": session.config.display_name,
                "prometheus_url": session.config.prometheus.url,
                "elasticsearch_url": session.config.elasticsearch.url,
                "elasticsearch_index_pattern": session.config.elasticsearch.index_pattern,
                "jaeger_url": session.config.jaeger.url,
                "connected_at": session.created_at,
            }

            accumulated_analysis = []
            if tool_results:
                stream_gen = result_analyzer.stream_analyze(req.message, tool_results, env_context=env_context, history=history)
            else:
                stream_gen = result_analyzer.stream_general_response(req.message, env_context=env_context, history=history)

            async for token in stream_gen:
                accumulated_analysis.append(token)
                token_payload = {"event": "token", "token": token}
                yield f"data: {json.dumps(token_payload)}\n\n"

            full_analysis = "".join(accumulated_analysis)
            session_manager.add_to_history(req.session_id, "assistant", full_analysis)
            yield f"data: {json.dumps({'event': 'done'})}\n\n"

        except Exception as e:
            logger.error("Error in chat stream generator", extra={"event": "stream_error", "error": str(e)})
            err_payload = {"event": "error", "error": str(e)}
            yield f"data: {json.dumps(err_payload)}\n\n"
        finally:
            await intent_detector.close()
            await query_generator.close()
            await result_analyzer.close()

    return StreamingResponse(event_generator(), media_type="text/event-stream")


@app.get("/api/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy", "version": "1.0.0"}


# ──────────────────── Static File Serving ────────────────────

@app.get("/")
async def serve_index():
    """Serve the frontend index.html."""
    index_path = FRONTEND_DIR / "index.html"
    if not index_path.exists():
        raise HTTPException(status_code=404, detail="Frontend not found")
    return FileResponse(str(index_path))


app.mount("/", StaticFiles(directory=str(FRONTEND_DIR)), name="frontend")

import os
import yaml
import logging
from typing import Dict, List
from .models import EnvironmentConfig

logger = logging.getLogger(__name__)

def load_config() -> Dict[str, EnvironmentConfig]:
    """
    Load environment configurations from YAML file.
    Supports environment variable override: OBS_CHATBOT_CONFIG_PATH
    """
    config_path = os.environ.get("OBS_CHATBOT_CONFIG_PATH", "config/environments.yaml")
    
    # Check absolute path from project root if relative doesn't exist
    if not os.path.exists(config_path):
        root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        alt_path = os.path.join(root_dir, config_path)
        if os.path.exists(alt_path):
            config_path = alt_path

    logger.info(f"Loading configuration from {config_path}")
    
    if not os.path.exists(config_path):
        msg = f"Configuration file not found at {config_path}. Please create it or set OBS_CHATBOT_CONFIG_PATH."
        logger.error(msg)
        raise FileNotFoundError(msg)

    with open(config_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    
    if not data or "environments" not in data:
        msg = "Invalid configuration format: 'environments' key not found."
        logger.error(msg)
        raise ValueError(msg)
        
    envs = {}
    for key, val in data["environments"].items():
        try:
            envs[key] = EnvironmentConfig(**val)
        except Exception as e:
            logger.error(f"Failed to parse environment '{key}': {e}")
            raise ValueError(f"Invalid configuration for {key}") from e
            
    return envs

def get_environment(name: str) -> EnvironmentConfig:
    """
    Get a specific environment configuration by name.
    """
    configs = load_config()
    if name not in configs:
        msg = f"Environment '{name}' not found."
        logger.error(msg)
        raise ValueError(msg)
    return configs[name]

def list_environments() -> List[Dict[str, str]]:
    """
    List all available environments.
    """
    configs = load_config()
    return [{"key": k, "display_name": v.display_name} for k, v in configs.items()]

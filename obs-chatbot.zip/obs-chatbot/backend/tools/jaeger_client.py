"""
Jaeger HTTP API client.
Supports trace search by service/operation/tags and fetching specific traces by ID.
All operations are logged with correlation IDs.
"""

import logging
import json
from typing import Any, Dict, List
from .base import BaseTool
from ..models import JaegerConfig

logger = logging.getLogger(__name__)


class JaegerClient(BaseTool):
    def __init__(self, config: JaegerConfig):
        super().__init__(base_url=config.url, timeout=config.timeout)
        self.max_traces = config.max_traces
        logger.info(
            "Jaeger client initialized",
            extra={"event": "tool_init", "tool": "jaeger", "url": config.url},
        )

    async def execute(self, query: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a Jaeger trace query."""
        trace_id = query.get("trace_id")
        query_used = ""

        try:
            if trace_id:
                query_used = f"GET /api/traces/{trace_id}"
                logger.info(
                    "Fetching specific Jaeger trace",
                    extra={
                        "event": "tool_request",
                        "tool": "jaeger",
                        "trace_id": trace_id,
                        "query_used": query_used,
                    },
                )
                response = await self.client.get(f"/api/traces/{trace_id}")
            else:
                service = query.get("service")
                if not service:
                    logger.error(
                        "Jaeger execute called without service",
                        extra={"event": "tool_error", "tool": "jaeger", "error": "Missing service parameter"},
                    )
                    return {"status": "error", "error": "Missing service parameter", "query_used": "GET /api/traces"}

                params = {
                    "service": service,
                    "limit": query.get("limit", self.max_traces),
                }

                if "operation" in query:
                    params["operation"] = query["operation"]
                if "tags" in query:
                    params["tags"] = json.dumps(query["tags"])
                if "start" in query:
                    params["start"] = query["start"]
                if "end" in query:
                    params["end"] = query["end"]

                query_used = f"GET /api/traces service={service} params={json.dumps(params, default=str)}"

                logger.info(
                    "Searching Jaeger traces",
                    extra={
                        "event": "tool_request",
                        "tool": "jaeger",
                        "service": service,
                        "params": params,
                        "query_used": query_used,
                    },
                )
                response = await self.client.get("/api/traces", params=params)

            response.raise_for_status()
            data = response.json()

            trace_data = data.get("data", [])

            logger.info(
                "Jaeger query succeeded",
                extra={
                    "event": "tool_response",
                    "tool": "jaeger",
                    "record_count": len(trace_data),
                    "query_used": query_used,
                },
            )

            return {
                "status": "success",
                "data": trace_data,
                "record_count": len(trace_data),
                "query_used": query_used,
            }
        except Exception as e:
            logger.error(
                "Jaeger query failed",
                extra={
                    "event": "tool_error",
                    "tool": "jaeger",
                    "error": str(e),
                    "query_used": query_used,
                },
            )
            return {"status": "error", "error": str(e), "query_used": query_used}

    async def health_check(self) -> bool:
        """Check Jaeger connectivity."""
        logger.info(
            "Running Jaeger health check",
            extra={"event": "tool_health_check", "tool": "jaeger"},
        )
        try:
            response = await self.client.get("/api/services")
            response.raise_for_status()
            logger.info(
                "Jaeger health check passed",
                extra={"event": "tool_health_result", "tool": "jaeger", "healthy": True},
            )
            return True
        except Exception as e:
            logger.warning(
                "Jaeger health check failed",
                extra={"event": "tool_health_result", "tool": "jaeger", "healthy": False, "error": str(e)},
            )
            return False

    async def get_services(self) -> List[str]:
        """Fetch available services from Jaeger."""
        logger.info(
            "Fetching Jaeger services",
            extra={"event": "tool_request", "tool": "jaeger", "operation": "get_services"},
        )
        try:
            response = await self.client.get("/api/services")
            response.raise_for_status()
            services = response.json().get("data", [])
            logger.info(
                "Jaeger services fetched",
                extra={
                    "event": "tool_response",
                    "tool": "jaeger",
                    "operation": "get_services",
                    "service_count": len(services),
                },
            )
            return services
        except Exception as e:
            logger.error(
                "Failed to fetch Jaeger services",
                extra={"event": "tool_error", "tool": "jaeger", "operation": "get_services", "error": str(e)},
            )
            return []

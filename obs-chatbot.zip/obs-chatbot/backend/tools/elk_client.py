"""
Elasticsearch REST API client.
Executes search queries using Query DSL via the _search endpoint.
All operations are logged with correlation IDs.
"""

import logging
import json
from typing import Any, Dict
from .base import BaseTool
from ..models import ElasticsearchConfig

logger = logging.getLogger(__name__)


class ELKClient(BaseTool):
    def __init__(self, config: ElasticsearchConfig):
        super().__init__(base_url=config.url, token=config.token, timeout=config.timeout)
        self.client.headers.update({"Content-Type": "application/json"})
        self.index_pattern = config.index_pattern
        self.timestamp_field = config.timestamp_field
        self.max_results = config.max_results
        logger.info(
            "Elasticsearch client initialized",
            extra={
                "event": "tool_init",
                "tool": "elasticsearch",
                "url": config.url,
                "index_pattern": self.index_pattern,
            },
        )

    async def execute(self, query: Dict[str, Any]) -> Dict[str, Any]:
        """Execute an Elasticsearch search query."""
        query_dsl = query.get("query_dsl", {})
        index = query.get("index", self.index_pattern)
        size = query.get("size", self.max_results)

        query_str = json.dumps(query_dsl, default=str)

        logger.info(
            "Executing Elasticsearch query",
            extra={
                "event": "tool_request",
                "tool": "elasticsearch",
                "index": index,
                "size": size,
                "query_dsl": query_str[:500],
            },
        )

        try:
            response = await self.client.post(
                f"/{index}/_search",
                params={"size": size},
                json=query_dsl,
            )
            response.raise_for_status()
            data = response.json()

            hits = data.get("hits", {}).get("hits", [])
            sources = [hit.get("_source", {}) for hit in hits]
            total_hits = data.get("hits", {}).get("total", {}).get("value", len(hits))

            logger.info(
                "Elasticsearch query succeeded",
                extra={
                    "event": "tool_response",
                    "tool": "elasticsearch",
                    "record_count": total_hits,
                    "hits_returned": len(sources),
                    "query_used": query_str[:300],
                },
            )

            return {
                "status": "success",
                "data": sources,
                "record_count": total_hits,
                "query_used": query_str,
            }
        except Exception as e:
            logger.error(
                "Elasticsearch query failed",
                extra={
                    "event": "tool_error",
                    "tool": "elasticsearch",
                    "error": str(e),
                    "query_used": query_str[:300],
                },
            )
            return {"status": "error", "error": str(e), "query_used": query_str}

    async def health_check(self) -> bool:
        """Check Elasticsearch cluster health."""
        logger.info(
            "Running Elasticsearch health check",
            extra={"event": "tool_health_check", "tool": "elasticsearch"},
        )
        try:
            response = await self.client.get("/_cluster/health")
            response.raise_for_status()
            data = response.json()
            status = data.get("status")
            healthy = status in ["green", "yellow"]
            logger.info(
                "Elasticsearch health check result",
                extra={
                    "event": "tool_health_result",
                    "tool": "elasticsearch",
                    "healthy": healthy,
                    "cluster_status": status,
                },
            )
            return healthy
        except Exception as e:
            logger.warning(
                "Elasticsearch health check failed",
                extra={"event": "tool_health_result", "tool": "elasticsearch", "healthy": False, "error": str(e)},
            )
            return False

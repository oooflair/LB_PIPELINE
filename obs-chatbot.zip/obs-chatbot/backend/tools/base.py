from abc import ABC, abstractmethod
from typing import Any
import httpx

class BaseTool(ABC):
    def __init__(self, base_url: str, token: str = "", timeout: int = 30):
        headers = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        self.client = httpx.AsyncClient(
            base_url=base_url,
            headers=headers,
            timeout=timeout,
            verify=False  # For internal services
        )
        self.base_url = base_url
    
    @abstractmethod
    async def execute(self, query: Any) -> dict:
        pass
    
    @abstractmethod
    async def health_check(self) -> bool:
        pass
    
    async def close(self):
        await self.client.aclose()

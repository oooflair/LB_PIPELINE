"""
Prometheus HTTP API client.
Supports instant and range queries with relative time parsing.
All operations are logged with correlation IDs.
"""

import logging
import json
from typing import Any, Dict
import datetime
import time
from .base import BaseTool
from ..models import PrometheusConfig

logger = logging.getLogger(__name__)


class PrometheusClient(BaseTool):
    def __init__(self, config: PrometheusConfig):
        super().__init__(base_url=config.url, token=config.token, timeout=config.timeout)
        self.default_step = config.default_step
        logger.info(
            "Prometheus client initialized",
            extra={"event": "tool_init", "tool": "prometheus", "url": config.url},
        )

    def _parse_time(self, t_str: str) -> str:
        """Helper to convert relative times like '1h' to unix timestamp."""
        if not t_str or t_str == "now":
            return str(int(time.time()))
        if t_str.startswith("-"):
            t_str = t_str[1:]
        if t_str.endswith("h"):
            return str(int(time.time() - int(t_str[:-1]) * 3600))
        if t_str.endswith("m"):
            return str(int(time.time() - int(t_str[:-1]) * 60))
        if t_str.endswith("d"):
            return str(int(time.time() - int(t_str[:-1]) * 86400))
        try:
            dt = datetime.datetime.fromisoformat(t_str.replace("Z", "+00:00"))
            return str(int(dt.timestamp()))
        except ValueError:
            pass
        return t_str

    async def execute(self, query: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a PromQL query against the Prometheus HTTP API."""
        promql = query.get("promql", "")
        query_type = query.get("query_type", "range")
        start = self._parse_time(query.get("start", "1h"))
        end = self._parse_time(query.get("end", "now"))
        step = query.get("step", self.default_step)

        if not promql:
            logger.error(
                "Prometheus execute called without promql",
                extra={"event": "tool_error", "tool": "prometheus", "error": "Missing promql"},
            )
            return {"status": "error", "error": "Missing promql in query", "query_used": ""}

        logger.info(
            "Executing Prometheus query",
            extra={
                "event": "tool_request",
                "tool": "prometheus",
                "query_type": query_type,
                "promql": promql,
                "start": start,
                "end": end,
                "step": step,
            },
        )

        try:
            if query_type == "instant":
                response = await self.client.get("/api/v1/query", params={"query": promql})
            else:
                params = {"query": promql, "start": start, "end": end, "step": step}
                response = await self.client.get("/api/v1/query_range", params=params)

            response.raise_for_status()
            data = response.json()

            if data.get("status") != "success":
                logger.error(
                    "Prometheus API returned error status",
                    extra={
                        "event": "tool_response_error",
                        "tool": "prometheus",
                        "api_error": data.get("error"),
                        "query_used": promql,
                    },
                )
                return {"status": "error", "error": f"API returned error: {data.get('error')}", "query_used": promql}

            result_data = data.get("data", {}).get("result", [])

            logger.info(
                "Prometheus query succeeded",
                extra={
                    "event": "tool_response",
                    "tool": "prometheus",
                    "record_count": len(result_data),
                    "query_used": promql,
                },
            )

            return {
                "status": "success",
                "data": result_data,
                "record_count": len(result_data),
                "query_used": promql,
            }
        except Exception as e:
            logger.error(
                "Prometheus query failed",
                extra={
                    "event": "tool_error",
                    "tool": "prometheus",
                    "error": str(e),
                    "query_used": promql,
                },
            )
            return {"status": "error", "error": str(e), "query_used": promql}

    async def health_check(self) -> bool:
        """Check Prometheus connectivity."""
        logger.info(
            "Running Prometheus health check",
            extra={"event": "tool_health_check", "tool": "prometheus"},
        )
        try:
            response = await self.client.get("/api/v1/query", params={"query": "up"})
            response.raise_for_status()
            logger.info(
                "Prometheus health check passed",
                extra={"event": "tool_health_result", "tool": "prometheus", "healthy": True},
            )
            return True
        except Exception as e:
            logger.warning(
                "Prometheus health check failed",
                extra={"event": "tool_health_result", "tool": "prometheus", "healthy": False, "error": str(e)},
            )
            return False

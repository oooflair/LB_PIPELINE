"""
LLM-powered intent detection module.
Classifies user messages into one or more intents (metrics, logs, traces, env_check, general)
with entity extraction and priority evaluation. All operations are logged with correlation IDs.
"""

import httpx
import json
import logging
import asyncio
from typing import Any, List, Optional
from backend.models import LLMConfig, DetectedIntent, IntentType

logger = logging.getLogger(__name__)


class IntentDetector:
    def __init__(self, config: LLMConfig):
        self.config = config
        self.client = httpx.AsyncClient(timeout=config.timeout)

    async def detect(self, message: str, history: Optional[List[dict]] = None) -> List[DetectedIntent]:
        """Detect one or more intents from user message with priority order and context awareness."""
        if self.client.is_closed:
            self.client = httpx.AsyncClient(timeout=self.config.timeout)
        system_prompt = """You are an expert intent classifier for APIEngineering Intelligence, an enterprise observability chatbot.

## INTENT EVALUATION PRIORITY ORDER (HIGHEST TO LOWEST):

1. 'general' (Conversational Intents):
   Recognize conversational messages including:
   - Greetings: hi, hello, hey, good morning, good afternoon, good evening
   - Acknowledgements: hmm, hmmm, okay, ok, got it, understood, makes sense, cool, nice, great, awesome, perfect
   - Gratitude: thanks, thank you, appreciate it
   - Affirmation: yes, yep, yeah, sure, correct, exactly
   - Negation: no, nope, not really
   - Farewell: bye, goodbye, see you, catch you later
   - Small Talk: how are you, what's up, good job, well done, that's helpful
   
   CRITICAL RULE: Purely conversational messages MUST be classified as 'general'. No backend telemetry tools will be executed for 'general' messages.

2. Context-Aware Follow-up (Observability Continuity):
   Do NOT classify a message as purely conversational if it clearly continues a previous observability query!
   Examples:
   - User: "Show CPU usage" -> User: "What about memory?" => 'metrics'
   - User: "Show ERROR logs" -> User: "Same for payment-service" => 'logs'
   - User: "Check environment" -> User: "Check again" => 'env_check'
   - User: "Show traces" -> User: "Last 30 minutes" => 'traces'

3. 'env_check':
   For environment connectivity verification or proof questions (e.g. "What is the proof?", "Is it really connected?", "Check again", "Verify cluster", "Are tools reachable?").

4. 'metrics':
   For queries about numerical time-series data like CPU, memory, request rates, latency, OR for queries requesting lists of running applications, active services, pods, or cluster status.

5. 'logs':
   For queries about text records, error messages, exceptions, or specific log events.

6. 'traces':
   For queries about request flow, spans, bottlenecks across services, or distributed tracing.

You must extract entities for each intent. Possible entities:
- 'service_name': The name of the service/application (e.g. "auth-service", "frontend").
- 'time_range': The timeframe for the query (e.g. "last 15m", "past hour"). Default to "last 1h" if not specified.
- 'keywords': Any specific words to search for in logs (e.g. "NullPointerException", "timeout").
- 'error_type': Specific error codes or types (e.g. "500", "404").
- 'metric_name': Specific metric name if implied (e.g. "cpu", "memory", "latency").
- 'operation_name': Specific operation or endpoint for traces.
- 'trace_id': A specific trace ID if provided.

OUTPUT FORMAT:
You MUST return a strict JSON array of objects. Do NOT include markdown blocks like ```json ... ```. Just the raw JSON array.
Each object must have:
- "type": One of "metrics", "logs", "traces", "env_check", "general".
- "description": A brief summary of what this specific intent is asking for.
- "entities": A dictionary of extracted entities.

Example 1:
User: "Hi"
Output: [{"type": "general", "description": "User greeting", "entities": {}}]

Example 2:
User: "Okay, got it"
Output: [{"type": "general", "description": "User acknowledgement", "entities": {}}]

Example 3:
User: "Show CPU usage"
Output: [{"type": "metrics", "description": "Fetch CPU metrics", "entities": {"metric_name": "cpu"}}]
User: "What about memory?"
Output: [{"type": "metrics", "description": "Fetch memory metrics for previous context", "entities": {"metric_name": "memory"}}]
"""
        messages = [{"role": "system", "content": system_prompt}]

        if history:
            prev_turns = history[:-1] if (history and history[-1]["content"] == message) else history
            for msg in prev_turns[-5:]:
                messages.append({"role": msg["role"], "content": msg["content"]})

        messages.append({"role": "user", "content": message})

        payload = {
            "model": self.config.model,
            "messages": messages,
            "temperature": self.config.temperature,
            "max_tokens": self.config.max_tokens,
        }

        url = self.config.base_url.rstrip("/")
        if not url.endswith("/chat/completions"):
            url = f"{url}/chat/completions"

        headers = {
            "Authorization": f"Bearer {self.config.api_key}",
            "Content-Type": "application/json",
        }

        try:
            logger.info(
                "Sending intent detection request to LLM",
                extra={
                    "event": "llm_request",
                    "operation": "intent_detection",
                    "llm_model": self.config.model,
                    "llm_url": self.config.base_url,
                    "user_message": message,
                },
            )

            async with self.client as client: # Note: reuse client
                pass

            # Execute via httpx client
            response = await self.client.post(url, json=payload, headers=headers)
            response.raise_for_status()
            data = response.json()

            raw_response = data["choices"][0]["message"]["content"].strip()

            # Clean JSON formatting
            if raw_response.startswith("```json"):
                raw_response = raw_response[7:]
            if raw_response.startswith("```"):
                raw_response = raw_response[3:]
            if raw_response.endswith("```"):
                raw_response = raw_response[:-3]
            raw_response = raw_response.strip()

            intents_data = json.loads(raw_response)
            intents = []
            for item in intents_data:
                intent_type_str = item.get("type", "general").lower()
                try:
                    intent_type = IntentType(intent_type_str)
                except ValueError:
                    intent_type = IntentType.GENERAL

                intents.append(
                    DetectedIntent(
                        type=intent_type,
                        description=item.get("description", ""),
                        entities=item.get("entities", {}),
                    )
                )

            logger.info(
                "Intent detection completed",
                extra={
                    "event": "intent_detection_complete",
                    "intent_count": len(intents),
                    "intents": [{"type": i.type.value, "description": i.description} for i in intents],
                },
            )
            return intents

        except Exception as e:
            logger.error(
                "Intent detection failed, falling back to general",
                extra={"event": "intent_detection_fallback", "error": str(e)},
            )
            return [DetectedIntent(type=IntentType.GENERAL, description=message, entities={})]

    async def close(self):
        await self.client.aclose()

"""
Standalone Mock Observability Servers for Mule UAT and Java UAT.
Provides realistic microservice telemetry for Prometheus, Elasticsearch, and Jaeger endpoints.

Port Mapping:
Mule UAT:
  - Prometheus: http://localhost:9091
  - Elasticsearch: http://localhost:9201
  - Jaeger: http://localhost:16686

Java UAT:
  - Prometheus: http://localhost:9092
  - Elasticsearch: http://localhost:9202
  - Jaeger: http://localhost:16687
"""

import asyncio
import json
import logging
from typing import Dict, Any, List
from fastapi import FastAPI, Query, Request
from fastapi.responses import JSONResponse
import uvicorn

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger("mock_servers")

# ─────────────────────────────────────────────────────────────
# MULE UAT MOCK DATA & ROUTERS
# ─────────────────────────────────────────────────────────────

# 1. Mule Prometheus App (Port 9091)
mule_prom_app = FastAPI(title="Mule UAT Prometheus Mock")

@mule_prom_app.get("/api/v1/query")
@mule_prom_app.get("/api/v1/query_range")
async def mule_prom_query(query: str = Query(default="up")):
    logger.info(f"[Mule Prometheus] Query: {query}")
    
    if "cpu" in query.lower():
        result = [
            {
                "metric": {
                    "__name__": "container_cpu_usage_seconds_total",
                    "container": "mule-payment-integration",
                    "namespace": "uat-mule-integrations",
                    "pod": "mule-payment-integration-7d8f9c-x291a",
                    "job": "mule-uat-apps"
                },
                "values": [[1785607200, "0.78"], [1785607260, "0.84"], [1785607320, "0.89"]]
            },
            {
                "metric": {
                    "__name__": "container_cpu_usage_seconds_total",
                    "container": "mule-sap-connector",
                    "namespace": "uat-mule-integrations",
                    "pod": "mule-sap-connector-59f7bd-v72ka",
                    "job": "mule-uat-apps"
                },
                "values": [[1785607200, "0.88"], [1785607260, "0.92"], [1785607320, "0.95"]]
            },
            {
                "metric": {
                    "__name__": "container_cpu_usage_seconds_total",
                    "container": "mule-order-api",
                    "namespace": "uat-mule-integrations",
                    "pod": "mule-order-api-65489f6d7-m91qp",
                    "job": "mule-uat-apps"
                },
                "values": [[1785607200, "0.35"], [1785607260, "0.38"], [1785607320, "0.32"]]
            }
        ]
    elif "memory" in query.lower():
        result = [
            {
                "metric": {
                    "__name__": "container_memory_working_set_bytes",
                    "container": "mule-sap-connector",
                    "namespace": "uat-mule-integrations",
                    "pod": "mule-sap-connector-59f7bd-v72ka"
                },
                "values": [[1785607200, "2147483648"], [1785607320, "2147483648"]]
            },
            {
                "metric": {
                    "__name__": "container_memory_working_set_bytes",
                    "container": "mule-payment-integration",
                    "namespace": "uat-mule-integrations",
                    "pod": "mule-payment-integration-7d8f9c-x291a"
                },
                "values": [[1785607200, "1476395008"], [1785607320, "1510000000"]]
            }
        ]
    else:
        result = [
            {
                "metric": {"__name__": "up", "job": "mule-payment-integration", "namespace": "uat-mule-integrations"},
                "values": [[1785607320, "1"]]
            },
            {
                "metric": {"__name__": "up", "job": "mule-sap-connector", "namespace": "uat-mule-integrations"},
                "values": [[1785607320, "1"]]
            },
            {
                "metric": {"__name__": "up", "job": "mule-order-api", "namespace": "uat-mule-integrations"},
                "values": [[1785607320, "1"]]
            }
        ]

    return {"status": "success", "data": {"resultType": "matrix", "result": result}}


# 2. Mule ELK App (Port 9201)
mule_elk_app = FastAPI(title="Mule UAT ELK Mock")

@mule_elk_app.get("/_cluster/health")
async def mule_elk_health():
    return {"cluster_name": "mule-uat-elk", "status": "green", "number_of_nodes": 3}

@mule_elk_app.post("/{index}/_search")
@mule_elk_app.post("/_search")
async def mule_elk_search(index: str = "mule-uat-logs-*", size: int = 50):
    logger.info(f"[Mule ELK] Search index: {index}, size: {size}")
    hits = [
        {
            "_index": "mule-uat-logs-2026.08.02",
            "_source": {
                "@timestamp": "2026-08-02T00:05:12.124Z",
                "level": "ERROR",
                "service": "mule-payment-integration",
                "namespace": "uat-mule-integrations",
                "pod": "mule-payment-integration-7d8f9c-x291a",
                "transaction_id": "TXN-894210",
                "order_id": "ORD-77192",
                "message": "ConnectionTimeoutException: Failed to connect to PaymentGateway endpoint https://pgw-stage.internal/v2/charge after 5000ms. TransactionID: TXN-894210. Retries exhausted."
            }
        },
        {
            "_index": "mule-uat-logs-2026.08.02",
            "_source": {
                "@timestamp": "2026-08-02T00:04:45.892Z",
                "level": "ERROR",
                "service": "mule-sap-connector",
                "namespace": "uat-mule-integrations",
                "pod": "mule-sap-connector-59f7bd-v72ka",
                "sap_system": "ERP-UAT-01",
                "message": "SAPBapiException: BAPI_SALESORDER_CREATEFROMDAT2 returned error code 501: Customer 109482 locked for update."
            }
        },
        {
            "_index": "mule-uat-logs-2026.08.02",
            "_source": {
                "@timestamp": "2026-08-02T00:03:10.450Z",
                "level": "WARN",
                "service": "mule-order-api",
                "namespace": "uat-mule-integrations",
                "pod": "mule-order-api-65489f6d7-m91qp",
                "order_id": "ORD-99182",
                "message": "Slow message processing: Order ID ORD-99182 took 3420ms to process in Mule flow 'process-order-subflow'. Memory utilization at 82%."
            }
        },
        {
            "_index": "mule-uat-logs-2026.08.02",
            "_source": {
                "@timestamp": "2026-08-02T00:02:15.001Z",
                "level": "INFO",
                "service": "mule-salesforce-sync",
                "namespace": "uat-mule-integrations",
                "message": "Successfully synced 250 contact accounts to Salesforce CRM instance uat.salesforce.com"
            }
        }
    ]
    return {"hits": {"total": {"value": len(hits)}, "hits": hits}}


# 3. Mule Jaeger App (Port 16686)
mule_jaeger_app = FastAPI(title="Mule UAT Jaeger Mock")

@mule_jaeger_app.get("/api/services")
async def mule_jaeger_services():
    return {"data": ["mule-order-api", "mule-payment-integration", "mule-sap-connector", "mule-salesforce-sync"]}

@mule_jaeger_app.get("/api/traces")
@mule_jaeger_app.get("/api/traces/{trace_id}")
async def mule_jaeger_traces(trace_id: str = None, service: str = Query(default=None)):
    logger.info(f"[Mule Jaeger] Trace query for service={service}, trace_id={trace_id}")
    traces = [
        {
            "traceID": "a10984f982c741e2",
            "spans": [
                {
                    "traceID": "a10984f982c741e2",
                    "spanID": "span001",
                    "operationName": "POST /api/v1/orders",
                    "duration": 3420000,  # 3.42s
                    "tags": [
                        {"key": "service.name", "value": "mule-order-api"},
                        {"key": "http.status_code", "value": "500"},
                        {"key": "error", "value": True}
                    ]
                },
                {
                    "traceID": "a10984f982c741e2",
                    "spanID": "span002",
                    "operationName": "POST /v2/charge",
                    "duration": 2800000,
                    "tags": [
                        {"key": "service.name", "value": "mule-payment-integration"},
                        {"key": "http.status_code", "value": "504"},
                        {"key": "error.message", "value": "Gateway Timeout"}
                    ]
                },
                {
                    "traceID": "a10984f982c741e2",
                    "spanID": "span003",
                    "operationName": "BAPI_SALESORDER_CREATEFROMDAT2",
                    "duration": 620000,
                    "tags": [
                        {"key": "service.name", "value": "mule-sap-connector"},
                        {"key": "sap.bapi", "value": "BAPI_SALESORDER_CREATEFROMDAT2"},
                        {"key": "error", "value": True}
                    ]
                }
            ]
        }
    ]
    return {"data": traces}


# ─────────────────────────────────────────────────────────────
# JAVA UAT MOCK DATA & ROUTERS
# ─────────────────────────────────────────────────────────────

# 4. Java Prometheus App (Port 9092)
java_prom_app = FastAPI(title="Java UAT Prometheus Mock")

@java_prom_app.get("/api/v1/query")
@java_prom_app.get("/api/v1/query_range")
async def java_prom_query(query: str = Query(default="up")):
    logger.info(f"[Java Prometheus] Query: {query}")
    
    if "cpu" in query.lower():
        result = [
            {
                "metric": {
                    "__name__": "container_cpu_usage_seconds_total",
                    "container": "payment-gateway-service",
                    "namespace": "uat-java-apps",
                    "pod": "payment-gateway-service-8d6f54c9-k49pq",
                    "job": "java-microservices"
                },
                "values": [[1785607200, "0.91"], [1785607260, "0.94"], [1785607320, "0.97"]]  # CPU Spike!
            },
            {
                "metric": {
                    "__name__": "container_cpu_usage_seconds_total",
                    "container": "order-fulfillment-api",
                    "namespace": "uat-java-apps",
                    "pod": "order-fulfillment-api-5c79bf4-n11ab",
                    "job": "java-microservices"
                },
                "values": [[1785607200, "0.42"], [1785607260, "0.45"], [1785607320, "0.41"]]
            },
            {
                "metric": {
                    "__name__": "container_cpu_usage_seconds_total",
                    "container": "customer-portal-backend",
                    "namespace": "uat-java-apps",
                    "pod": "customer-portal-backend-7f89d-q11aa",
                    "job": "java-microservices"
                },
                "values": [[1785607200, "0.55"], [1785607260, "0.58"], [1785607320, "0.52"]]
            }
        ]
    elif "memory" in query.lower():
        result = [
            {
                "metric": {
                    "__name__": "container_memory_working_set_bytes",
                    "container": "payment-gateway-service",
                    "namespace": "uat-java-apps",
                    "pod": "payment-gateway-service-8d6f54c9-k49pq"
                },
                "values": [[1785607200, "1932735283"], [1785607320, "1980000000"]]  # 1.84 GB / 2 GB
            },
            {
                "metric": {
                    "__name__": "container_memory_working_set_bytes",
                    "container": "order-fulfillment-api",
                    "namespace": "uat-java-apps",
                    "pod": "order-fulfillment-api-5c79bf4-n11ab"
                },
                "values": [[1785607200, "858993459"], [1785607320, "860000000"]]
            }
        ]
    else:
        result = [
            {
                "metric": {"__name__": "up", "job": "payment-gateway-service", "namespace": "uat-java-apps"},
                "values": [[1785607320, "1"]]
            },
            {
                "metric": {"__name__": "up", "job": "order-fulfillment-api", "namespace": "uat-java-apps"},
                "values": [[1785607320, "1"]]
            },
            {
                "metric": {"__name__": "up", "job": "inventory-service", "namespace": "uat-java-apps"},
                "values": [[1785607320, "1"]]
            }
        ]

    return {"status": "success", "data": {"resultType": "matrix", "result": result}}


# 5. Java ELK App (Port 9202)
java_elk_app = FastAPI(title="Java UAT ELK Mock")

@java_elk_app.get("/_cluster/health")
async def java_elk_health():
    return {"cluster_name": "java-uat-elk", "status": "green", "number_of_nodes": 4}

@java_elk_app.post("/{index}/_search")
@java_elk_app.post("/_search")
async def java_elk_search(index: str = "java-uat-logs-*", size: int = 50):
    logger.info(f"[Java ELK] Search index: {index}, size: {size}")
    hits = [
        {
            "_index": "java-uat-logs-2026.08.02",
            "_source": {
                "@timestamp": "2026-08-02T00:08:33.412Z",
                "level": "ERROR",
                "service": "payment-gateway-service",
                "namespace": "uat-java-apps",
                "pod": "payment-gateway-service-8d6f54c9-k49pq",
                "trace_id": "c4829a1b02f8491c",
                "message": "java.lang.NullPointerException: Cannot invoke 'com.company.payment.model.Account.getAccountBalance()' because 'account' is null\n\tat com.company.payment.service.PaymentProcessor.processCharge(PaymentProcessor.java:142)\n\tat com.company.payment.controller.PaymentController.charge(PaymentController.java:58)"
            }
        },
        {
            "_index": "java-uat-logs-2026.08.02",
            "_source": {
                "@timestamp": "2026-08-02T00:07:19.880Z",
                "level": "ERROR",
                "service": "order-fulfillment-api",
                "namespace": "uat-java-apps",
                "pod": "order-fulfillment-api-5c79bf4-n11ab",
                "trace_id": "c4829a1b02f8491c",
                "message": "org.hibernate.exception.JDBCConnectionException: Unable to acquire JDBC Connection from HikariPool-1 (Pool exhausted: active=50, idle=0, waiting=24, timeout=30000ms). Database Host: postgres-uat.internal:5432"
            }
        },
        {
            "_index": "java-uat-logs-2026.08.02",
            "_source": {
                "@timestamp": "2026-08-02T00:06:02.115Z",
                "level": "WARN",
                "service": "inventory-service",
                "namespace": "uat-java-apps",
                "pod": "inventory-service-6789b-p33lm",
                "message": "High memory utilization: JVM Heap usage at 89.2% (1.78GB / 2.00GB). G1GC Old Generation utilization 92%."
            }
        },
        {
            "_index": "java-uat-logs-2026.08.02",
            "_source": {
                "@timestamp": "2026-08-02T00:05:40.090Z",
                "level": "INFO",
                "service": "customer-portal-backend",
                "namespace": "uat-java-apps",
                "message": "User session authenticated for userId=usr_99812, tenant=tenant_enterprise_01"
            }
        }
    ]
    return {"hits": {"total": {"value": len(hits)}, "hits": hits}}


# 6. Java Jaeger App (Port 16687)
java_jaeger_app = FastAPI(title="Java UAT Jaeger Mock")

@java_jaeger_app.get("/api/services")
async def java_jaeger_services():
    return {"data": ["payment-gateway-service", "order-fulfillment-api", "inventory-service", "customer-portal-backend", "notification-dispatcher"]}

@java_jaeger_app.get("/api/traces")
@java_jaeger_app.get("/api/traces/{trace_id}")
async def java_jaeger_traces(trace_id: str = None, service: str = Query(default=None)):
    logger.info(f"[Java Jaeger] Trace query for service={service}, trace_id={trace_id}")
    traces = [
        {
            "traceID": "c4829a1b02f8491c",
            "spans": [
                {
                    "traceID": "c4829a1b02f8491c",
                    "spanID": "jspan001",
                    "operationName": "POST /v1/checkout",
                    "duration": 5120000,  # 5.12s
                    "tags": [
                        {"key": "service.name", "value": "customer-portal-backend"},
                        {"key": "http.status_code", "value": "500"},
                        {"key": "error", "value": True}
                    ]
                },
                {
                    "traceID": "c4829a1b02f8491c",
                    "spanID": "jspan002",
                    "operationName": "POST /v2/orders/create",
                    "duration": 4800000,
                    "tags": [
                        {"key": "service.name", "value": "order-fulfillment-api"},
                        {"key": "http.status_code", "value": "500"},
                        {"key": "db.type", "value": "postgres"},
                        {"key": "error.message", "value": "HikariPool Connection Timeout"}
                    ]
                },
                {
                    "traceID": "c4829a1b02f8491c",
                    "spanID": "jspan003",
                    "operationName": "POST /v1/payments/charge",
                    "duration": 4500000,
                    "tags": [
                        {"key": "service.name", "value": "payment-gateway-service"},
                        {"key": "http.status_code", "value": "500"},
                        {"key": "exception.type", "value": "NullPointerException"}
                    ]
                }
            ]
        }
    ]
    return {"data": traces}


# ─────────────────────────────────────────────────────────────
# SERVER RUNNER (Runs all 6 mock services concurrently)
# ─────────────────────────────────────────────────────────────

async def run_all_mock_servers():
    config_mule_prom = uvicorn.Config(mule_prom_app, host="0.0.0.0", port=9091, log_level="warning")
    config_mule_elk = uvicorn.Config(mule_elk_app, host="0.0.0.0", port=9201, log_level="warning")
    config_mule_jaeger = uvicorn.Config(mule_jaeger_app, host="0.0.0.0", port=16686, log_level="warning")

    config_java_prom = uvicorn.Config(java_prom_app, host="0.0.0.0", port=9092, log_level="warning")
    config_java_elk = uvicorn.Config(java_elk_app, host="0.0.0.0", port=9202, log_level="warning")
    config_java_jaeger = uvicorn.Config(java_jaeger_app, host="0.0.0.0", port=16687, log_level="warning")

    servers = [
        uvicorn.Server(config_mule_prom).serve(),
        uvicorn.Server(config_mule_elk).serve(),
        uvicorn.Server(config_mule_jaeger).serve(),
        uvicorn.Server(config_java_prom).serve(),
        uvicorn.Server(config_java_elk).serve(),
        uvicorn.Server(config_java_jaeger).serve(),
    ]

    logger.info("Starting all 6 Mock Observability Endpoints...")
    logger.info("  [MULE UAT] Prom: 9091 | ELK: 9201 | Jaeger: 16686")
    logger.info("  [JAVA UAT] Prom: 9092 | ELK: 9202 | Jaeger: 16687")

    await asyncio.gather(*servers)

if __name__ == "__main__":
    asyncio.run(run_all_mock_servers())

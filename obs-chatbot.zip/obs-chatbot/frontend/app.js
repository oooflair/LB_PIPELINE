const App = (function() {
    // --- State ---
    const state = {
        connected: false,
        sessionId: null,
        environment: null,
        displayName: null
    };

    // --- DOM Elements ---
    const elements = {
        envSelect: document.getElementById('env-select'),
        disconnectBtn: document.getElementById('disconnect-btn'),
        statusBadge: document.getElementById('status-badge'),
        statusText: document.getElementById('status-text'),
        chatOverlay: document.getElementById('chat-overlay'),
        chatInput: document.getElementById('chat-input'),
        sendBtn: document.getElementById('send-btn'),
        chatMessages: document.getElementById('chat-messages'),
        typingIndicator: document.getElementById('typing-indicator'),
        toastContainer: document.getElementById('toast-container')
    };

    // --- Initialization ---
    async function init() {
        bindEvents();
        initTypewriterRotator();
        await loadEnvironments();
    }

    function initTypewriterRotator() {
        const rotator = document.getElementById('type-rotator');
        if (!rotator) return;

        const words = [
            { text: "DevOps", class: "text-devops" },
            { text: "Cloud Infrastructure", class: "text-cloud" },
            { text: "AI & Microservices", class: "text-ai" },
            { text: "Enterprise Observability", class: "text-obs" }
        ];

        let index = 0;
        setInterval(() => {
            index = (index + 1) % words.length;
            rotator.style.opacity = '0';
            rotator.style.transform = 'translateY(10px)';

            setTimeout(() => {
                rotator.textContent = words[index].text;
                rotator.className = `type-rotator ${words[index].class}`;
                rotator.style.opacity = '1';
                rotator.style.transform = 'translateY(0)';
            }, 300);
        }, 3000);
    }

    function bindEvents() {
        const themeToggleBtn = document.getElementById('theme-toggle');
        if (themeToggleBtn) {
            const savedTheme = localStorage.getItem('escbash:theme') || 'dark';
            document.documentElement.dataset.theme = savedTheme;

            themeToggleBtn.addEventListener('click', () => {
                const currentTheme = document.documentElement.dataset.theme || 'dark';
                const nextTheme = currentTheme === 'dark' ? 'light' : 'dark';
                document.documentElement.dataset.theme = nextTheme;
                localStorage.setItem('escbash:theme', nextTheme);
                showToast(`Switched to ${nextTheme} mode`, 'info');
            });
        }

        elements.envSelect.addEventListener('change', connect);
        elements.disconnectBtn.addEventListener('click', disconnect);
        
        elements.sendBtn.addEventListener('click', sendMessage);
        elements.chatInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });

        // Auto-expand textarea
        elements.chatInput.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
            if(this.value === '') {
                this.style.height = 'auto';
            }
        });
    }

    // --- API Interactions ---
    async function fetchApi(endpoint, options = {}) {
        try {
            // Using absolute URL to same origin as per instructions (or relative)
            const response = await fetch(`/api${endpoint}`, {
                headers: {
                    'Content-Type': 'application/json'
                },
                ...options
            });
            if (!response.ok) {
                let err = await response.text();
                throw new Error(err || `HTTP ${response.status}`);
            }
            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            showToast(error.message || 'Connection error. Please check your network.', 'error');
            throw error;
        }
    }

    async function loadEnvironments() {
        try {
            const envs = await fetchApi('/environments');
            envs.forEach(env => {
                const opt = document.createElement('option');
                opt.value = env.key;
                opt.textContent = env.display_name;
                elements.envSelect.appendChild(opt);
            });
        } catch (e) {
            elements.envSelect.innerHTML = '<option value="" disabled selected>Failed to load environments</option>';
        }
    }

    async function connect() {
        const envKey = elements.envSelect.value;
        if (!envKey) return;

        elements.envSelect.disabled = true;
        showToast('Connecting to cluster environment...', 'info');

        try {
            const res = await fetchApi('/connect', {
                method: 'POST',
                body: JSON.stringify({ environment: envKey })
            });

            if (res.status === 'connected') {
                state.connected = true;
                state.sessionId = res.session_id;
                state.environment = res.environment;
                state.displayName = res.display_name;

                elements.statusBadge.classList.remove('hidden');
                elements.statusText.textContent = `Connected to ${state.displayName}`;
                elements.disconnectBtn.classList.remove('hidden');
                
                unlockChat();
                showToast(`Connected to ${state.displayName}`, 'success');
            }
        } catch (error) {
            elements.envSelect.disabled = false;
            elements.envSelect.value = '';
            showToast('Failed to connect to cluster.', 'error');
        }
    }

    async function disconnect() {
        if (!state.sessionId) return;
        
        try {
            await fetchApi('/disconnect', {
                method: 'POST',
                body: JSON.stringify({ session_id: state.sessionId })
            });
        } catch(e) {
            // Ignore error on disconnect, force UI reset
        }

        // Reset state
        state.connected = false;
        state.sessionId = null;
        state.environment = null;

        elements.envSelect.disabled = false;
        elements.envSelect.value = '';
        elements.statusBadge.classList.add('hidden');
        elements.disconnectBtn.classList.add('hidden');
        elements.disconnectBtn.disabled = false;
        
        lockChat();
        elements.chatMessages.innerHTML = '';
        showToast('Disconnected', 'info');
    }

    async function sendMessage() {
        const text = elements.chatInput.value.trim();
        if (!text || !state.connected) return;

        addMessage('user', text);
        elements.chatInput.value = '';
        elements.chatInput.style.height = 'auto';
        
        showTypingIndicator();

        try {
            const response = await fetch('/api/chat/stream', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: text, session_id: state.sessionId })
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }

            hideTypingIndicator();

            const botMsgDiv = document.createElement('div');
            botMsgDiv.className = 'message bot';

            const cardContainer = document.createElement('div');
            cardContainer.className = 'card-container';

            const intentRowDiv = document.createElement('div');
            intentRowDiv.className = 'intent-row';
            cardContainer.appendChild(intentRowDiv);

            const toolResultsContainer = document.createElement('div');
            cardContainer.appendChild(toolResultsContainer);

            const analysisCard = document.createElement('div');
            analysisCard.className = 'analysis-card';
            analysisCard.innerHTML = `<div class="card-header">🧠 APIEngineering Intelligence Analysis</div><div class="card-body markdown-body"></div>`;
            const analysisBody = analysisCard.querySelector('.card-body');
            cardContainer.appendChild(analysisCard);

            botMsgDiv.innerHTML = `<div class="msg-bubble"></div>`;
            botMsgDiv.querySelector('.msg-bubble').appendChild(cardContainer);
            elements.chatMessages.appendChild(botMsgDiv);

            let rawAnalysisText = "";

            const reader = response.body.getReader();
            const decoder = new TextDecoder('utf-8');
            let buffer = "";

            while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop();

                for (let line of lines) {
                    line = line.trim();
                    if (line.startsWith('data: ')) {
                        try {
                            const payload = JSON.parse(line.slice(6));
                            if (payload.event === 'meta') {
                                if (payload.intents) {
                                    let intentHtml = '';
                                    payload.intents.forEach((intent, idx) => {
                                        const typeClass = `intent-${intent.type.toLowerCase()}`;
                                        const iconMap = { metrics: '📊', logs: '📋', traces: '🔍', general: '⚡' };
                                        const icon = iconMap[intent.type.toLowerCase()] || '💡';
                                        const confidence = intent.type.toLowerCase() === 'general' ? '98%' : (95 - idx * 3) + '%';
                                        intentHtml += `<span class="intent-badge ${typeClass}">${icon} ${escapeHtml(intent.description || intent.type)} <span class="intent-confidence">${confidence}</span></span>`;
                                    });
                                    intentRowDiv.innerHTML = intentHtml;
                                }

                                if (payload.tool_results && payload.tool_results.length > 0) {
                                    const toolNames = payload.tool_results.map(t => t.tool.charAt(0).toUpperCase() + t.tool.slice(1)).join(', ');
                                    let toolsHtml = `<div class="executed-tools-badge">⚡ Executed Tools: <strong>${escapeHtml(toolNames)}</strong></div>`;
                                    payload.tool_results.forEach(tr => {
                                        toolsHtml += renderToolResult(tr);
                                    });
                                    toolResultsContainer.innerHTML = toolsHtml;
                                }
                            } else if (payload.event === 'token') {
                                rawAnalysisText += payload.token;
                                analysisBody.innerHTML = parseAnalysisText(rawAnalysisText);
                                scrollToBottom();
                            }
                        } catch (e) {
                            console.error("SSE Parse Error:", e);
                        }
                    }
                }
            }

        } catch (error) {
            hideTypingIndicator();
            addMessage('bot', `<div class="error-text">Failed to get response: ${error.message}</div>`);
        }
    }

    // --- Rendering logic ---
    
    function addMessage(type, contentHTML) {
        const msgDiv = document.createElement('div');
        msgDiv.className = `message ${type}`;
        msgDiv.innerHTML = `<div class="msg-bubble">${type === 'user' ? escapeHtml(contentHTML) : contentHTML}</div>`;
        elements.chatMessages.appendChild(msgDiv);
        scrollToBottom();
    }

    function renderBotMessage(response) {
        if (response.error) {
            addMessage('bot', `<div class="error-text">Error: ${escapeHtml(response.error)}</div>`);
            return;
        }

        let html = '<div class="card-container">';
        
        // 1. Intents with Confidence %
        if (response.intents && response.intents.length > 0) {
            html += '<div class="intent-row">';
            response.intents.forEach((intent, idx) => {
                const typeClass = `intent-${intent.type.toLowerCase()}`;
                const iconMap = { metrics: '📊', logs: '📋', traces: '🔍', general: '⚡' };
                const icon = iconMap[intent.type.toLowerCase()] || '💡';
                const confidence = intent.type.toLowerCase() === 'general' ? '98%' : (95 - idx * 3) + '%';
                html += `<span class="intent-badge ${typeClass}">${icon} ${escapeHtml(intent.description || intent.type)} <span class="intent-confidence">${confidence}</span></span>`;
            });
            html += '</div>';
        }

        // Executed tool list badge
        if (response.tool_results && response.tool_results.length > 0) {
            const toolNames = response.tool_results.map(t => t.tool.charAt(0).toUpperCase() + t.tool.slice(1)).join(', ');
            html += `<div class="executed-tools-badge">⚡ Executed Tools: <strong>${escapeHtml(toolNames)}</strong></div>`;
        }

        // 2. Tool Results
        if (response.tool_results && response.tool_results.length > 0) {
            response.tool_results.forEach(tr => {
                html += renderToolResult(tr);
            });
        }

        // 3. Analysis
        if (response.analysis) {
            html += renderAnalysis(response.analysis);
        }

        html += '</div>';
        addMessage('bot', html);
    }

    function renderToolResult(tr) {
        const isError = tr.status !== 'success';
        const cardClass = isError ? 'tool-card error-card' : 'tool-card';
        const statusIcon = isError ? '❌' : '✅';
        
        let title = "Tool Result";
        let contentHtml = "";

        let queryUsed = tr.query_used ? `<div class="code-block">${escapeHtml(tr.query_used)}</div>` : '';

        if (tr.tool === 'prometheus') {
            title = "📊 Prometheus Metrics";
            contentHtml = isError ? `<div class="error-text">${escapeHtml(tr.error)}</div>` : renderMetricsTable(tr.data);
        } else if (tr.tool === 'elasticsearch') {
            title = "📋 Elasticsearch Logs";
            contentHtml = isError ? `<div class="error-text">${escapeHtml(tr.error)}</div>` : renderLogEntries(tr.data);
        } else if (tr.tool === 'jaeger') {
            title = "🔍 Jaeger Traces";
            contentHtml = isError ? `<div class="error-text">${escapeHtml(tr.error)}</div>` : renderTraces(tr.data);
        } else {
            // fallback for unknown tools
            contentHtml = `<pre class="code-block">${escapeHtml(formatJson(tr.data))}</pre>`;
        }

        return `
            <div class="${cardClass}">
                <div class="card-header">
                    <span>${title}</span>
                    <span>${statusIcon}</span>
                </div>
                <div class="card-body">
                    ${queryUsed}
                    ${contentHtml}
                    ${tr.record_count !== undefined ? `<div style="font-size: 0.8rem; color: var(--text-secondary); margin-top: 8px; text-align: right;">Showing ${Math.min(tr.data ? tr.data.length : 0, 20)} of ${tr.record_count} results</div>` : ''}
                </div>
            </div>
        `;
    }

    function renderMetricsTable(data) {
        if (!Array.isArray(data) || data.length === 0) return '<div>No metrics found</div>';
        
        let rows = '';
        data.slice(0, 20).forEach(row => {
            rows += `<tr>
                <td>${escapeHtml(row.metric || '-')}</td>
                <td><span style="font-family:monospace; color:var(--text-secondary); font-size:0.8rem;">${escapeHtml(row.labels || '-')}</span></td>
                <td style="font-weight:600; color:var(--accent-cyan);">${escapeHtml(row.value || '-')}</td>
                <td style="font-size:0.8rem; color:var(--text-secondary);">${escapeHtml(row.timestamp || '-')}</td>
            </tr>`;
        });

        return `
            <div class="data-table-wrapper">
                <table class="data-table">
                    <thead>
                        <tr><th>Metric</th><th>Labels</th><th>Value</th><th>Timestamp</th></tr>
                    </thead>
                    <tbody>${rows}</tbody>
                </table>
            </div>
        `;
    }

    function renderLogEntries(data) {
        if (!Array.isArray(data) || data.length === 0) return '<div>No logs found</div>';
        
        let html = '<div class="log-list">';
        data.slice(0, 50).forEach(log => {
            const levelClass = log.level ? `log-${log.level.toLowerCase()}` : 'log-info';
            html += `
                <div class="log-entry ${levelClass}" title="${escapeHtml(formatJson(log))}">
                    <span class="log-time">${escapeHtml(formatTime(log['@timestamp'] || log.timestamp) || '-')}</span>
                    <span class="log-level">${escapeHtml(log.level || 'INFO')}</span>
                    <span class="log-msg">${escapeHtml(log.message || formatJson(log))}</span>
                </div>
            `;
        });
        html += '</div>';
        return html;
    }

    function renderTraces(data) {
        if (!Array.isArray(data) || data.length === 0) return '<div>No traces found</div>';
        
        let html = '<div class="trace-list">';
        // Find max duration to scale bars
        let maxDur = 0;
        data.forEach(t => {
            let dur = parseFloat(t.duration);
            if (!isNaN(dur) && dur > maxDur) maxDur = dur;
        });

        data.slice(0, 50).forEach(t => {
            let durVal = parseFloat(t.duration) || 0;
            let percent = maxDur > 0 ? Math.min(100, (durVal / maxDur) * 100) : 0;
            html += `
                <div class="trace-entry">
                    <div class="trace-header">
                        <span class="trace-id">${escapeHtml((t.traceID || '').substring(0,12))}</span>
                        <span class="trace-svc">${escapeHtml(t.services || t.serviceName || '-')}</span>
                    </div>
                    <div class="trace-header" style="color:var(--text-secondary); margin-bottom: 4px;">
                        <span>${escapeHtml(t.operation || 'unknown')} | ${escapeHtml(t.duration || '0ms')} | ${t.spanCount || 0} spans</span>
                        <span style="color:${t.status === 'error' ? 'var(--color-error)' : 'var(--color-success)'}">${escapeHtml(t.status || 'ok')}</span>
                    </div>
                    <div class="trace-duration-container">
                        <div class="trace-duration-bar" style="width: ${percent}%;"></div>
                    </div>
                </div>
            `;
        });
        html += '</div>';
        return html;
    }

    function renderAnalysis(text) {
        const parsedHtml = parseAnalysisText(text);
        return `
            <div class="analysis-card">
                <div class="card-header">
                    <span>🧠 AI Analysis</span>
                </div>
                <div class="card-body analysis-content">
                    ${parsedHtml}
                </div>
            </div>
        `;
    }

    // --- Utilities ---

    function showTypingIndicator() {
        elements.typingIndicator.classList.remove('hidden');
        scrollToBottom();
    }

    function hideTypingIndicator() {
        elements.typingIndicator.classList.add('hidden');
    }

    function scrollToBottom() {
        elements.chatMessages.parentElement.scrollTop = elements.chatMessages.parentElement.scrollHeight;
    }

    function lockChat() {
        elements.chatOverlay.classList.remove('hidden');
        elements.chatInput.disabled = true;
        elements.sendBtn.disabled = true;
    }

    function unlockChat() {
        elements.chatOverlay.classList.add('hidden');
        elements.chatInput.disabled = false;
        elements.sendBtn.disabled = false;
        elements.chatInput.focus();
    }

    function showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        
        let icon = 'ℹ️';
        if(type==='success') icon = '✅';
        if(type==='error') icon = '❌';
        if(type==='warning') icon = '⚠️';

        toast.innerHTML = `<span>${icon}</span> <span>${escapeHtml(message)}</span>`;
        elements.toastContainer.appendChild(toast);

        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateY(-20px)';
            toast.style.transition = 'all 0.3s ease';
            setTimeout(() => toast.remove(), 300);
        }, 5000);
    }

    function formatTime(isoString) {
        if (!isoString) return '';
        try {
            const d = new Date(isoString);
            return d.toLocaleTimeString([], {hour12:false}) + '.' + String(d.getMilliseconds()).padStart(3,'0');
        } catch(e) {
            return isoString;
        }
    }

    function formatJson(obj) {
        try {
            return JSON.stringify(obj, null, 2);
        } catch(e) {
            return String(obj);
        }
    }

    function escapeHtml(str) {
        if (typeof str !== 'string') return str;
        return str.replace(/[&<>'"]/g, 
            tag => ({
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                "'": '&#39;',
                '"': '&quot;'
            }[tag] || tag)
        );
    }

    function convertMarkdownTables(text) {
        if (!text || text.indexOf('|') === -1) return text;

        const lines = text.split(/\r?\n/);
        let resultLines = [];
        let inTable = false;
        let tableHeaders = [];
        let tableRows = [];

        function flushTable() {
            if (tableHeaders.length === 0 && tableRows.length === 0) return '';
            let html = '<div class="table-wrapper"><table class="analysis-table"><thead><tr>';
            tableHeaders.forEach(h => html += `<th>${h}</th>`);
            html += '</tr></thead><tbody>';
            tableRows.forEach(row => {
                html += '<tr>';
                row.forEach(cell => html += `<td>${cell}</td>`);
                html += '</tr>';
            });
            html += '</tbody></table></div>';
            return html;
        }

        for (let i = 0; i < lines.length; i++) {
            let line = lines[i].trim();
            if (line.startsWith('|') && line.endsWith('|')) {
                if (/^\|[\s\-:|]+\|$/.test(line)) {
                    inTable = true;
                    continue;
                }
                const cells = line.split('|').map(c => c.trim()).filter((c, idx, arr) => idx > 0 && idx < arr.length - 1);
                if (!inTable) {
                    tableHeaders = cells;
                } else {
                    tableRows.push(cells);
                }
            } else {
                if (inTable || tableHeaders.length > 0) {
                    resultLines.push(flushTable());
                    tableHeaders = [];
                    tableRows = [];
                    inTable = false;
                }
                resultLines.push(lines[i]);
            }
        }
        if (inTable || tableHeaders.length > 0) {
            resultLines.push(flushTable());
        }

        return resultLines.join('\n');
    }

    function parseAnalysisText(text) {
        if (!text) return '';
        
        // Convert any markdown pipe tables to clean HTML tables first
        let convertedText = convertMarkdownTables(text);
        let html = escapeHtml(convertedText);
        
        // Restore table HTML tags if converted
        html = html.replace(/&lt;div class="table-wrapper"&gt;/g, '<div class="table-wrapper">')
                   .replace(/&lt;\/div&gt;/g, '</div>')
                   .replace(/&lt;table class="analysis-table"&gt;/g, '<table class="analysis-table">')
                   .replace(/&lt;\/table&gt;/g, '</table>')
                   .replace(/&lt;thead&gt;/g, '<thead>')
                   .replace(/&lt;\/thead&gt;/g, '</thead>')
                   .replace(/&lt;tbody&gt;/g, '<tbody>')
                   .replace(/&lt;\/tbody&gt;/g, '</tbody>')
                   .replace(/&lt;tr&gt;/g, '<tr>')
                   .replace(/&lt;\/tr&gt;/g, '</tr>')
                   .replace(/&lt;th&gt;/g, '<th>')
                   .replace(/&lt;\/th&gt;/g, '</th>')
                   .replace(/&lt;td&gt;/g, '<td>')
                   .replace(/&lt;\/td&gt;/g, '</td>');
        
        // Headers ## Header -> <h3>Header</h3>
        html = html.replace(/^##\s+(.+)$/gm, '<h3>$1</h3>');
        
        // Bold **text** -> <strong>text</strong>
        html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
        
        // Inline code `code` -> <span style="font-family:monospace; color:var(--accent-cyan);">code</span>
        html = html.replace(/`([^`]+)`/g, '<span style="font-family:monospace; color:var(--accent-cyan);">$1</span>');

        // Lists
        const actualLines = html.split(/\r?\n/);
        let outputLines = [];
        let inList = false;

        for (let i = 0; i < actualLines.length; i++) {
            let line = actualLines[i].trim();
            if (line.startsWith('- ') || line.startsWith('• ')) {
                if (!inList) {
                    outputLines.push('<ul>');
                    inList = true;
                }
                outputLines.push(`<li>${line.substring(2)}</li>`);
            } else {
                if (inList) {
                    outputLines.push('</ul>');
                    inList = false;
                }
                if (line) {
                    if (!line.startsWith('<h') && !line.startsWith('<div') && !line.startsWith('<table') && !line.startsWith('<tr') && !line.startsWith('<td') && !line.startsWith('<th')) {
                        outputLines.push(`<p>${line}</p>`);
                    } else {
                        outputLines.push(line);
                    }
                }
            }
        }
        if (inList) outputLines.push('</ul>');

        return outputLines.join('');
    }

    function formatMarkdown(text) {
        return parseAnalysisText(text);
    }

    // Expose init
    return { init };
})();

document.addEventListener('DOMContentLoaded', () => {
    App.init();
});

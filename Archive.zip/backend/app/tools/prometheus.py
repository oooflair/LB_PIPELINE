"""Prometheus observability tool.

Enhancements over the original:
- _time_window()       — converts "last 30 minutes" → [30m] PromQL range
- _analyze_all_series() — anomaly detection (services > 2× mean), HPA near-max
- Richer PromQL for HPA and failed pods
- Structured analysis includes anomalies, hpa_scaled, namespace breakdown
"""
from __future__ import annotations

import re
from statistics import mean

import httpx

from app.core.config import OrganizationConfig, get_settings
from app.models import ToolResult
from .base import ObservabilityTool


class PrometheusTool(ObservabilityTool):
    name = "prometheus"

    def __init__(self, organization: OrganizationConfig) -> None:
        self.organization = organization

    # ------------------------------------------------------------------ #
    # Main entry                                                           #
    # ------------------------------------------------------------------ #

    async def run(self, question: str) -> ToolResult:
        s = get_settings()
        if not self.organization.prometheus_url:
            return ToolResult(
                tool="prometheus", data={},
                warning=f"Prometheus is not configured for **{self.organization.name}**.",
            )

        service = self._service(question)
        window = self._time_window(question)
        query = self._promql(question, service, window)

        try:
            async with httpx.AsyncClient(timeout=s.request_timeout_seconds, verify=True) as client:
                resp = await client.get(
                    f"{self.organization.prometheus_url.rstrip('/')}/api/v1/query",
                    params={"query": query},
                )
                resp.raise_for_status()
            result = resp.json().get("data", {}).get("result", [])
            return ToolResult(
                tool="prometheus",
                data={
                    "cluster": self.organization.name,
                    "promql": query,
                    "analysis": self._analyze_all_series(result, query),
                },
                source_url=self.organization.prometheus_url,
            )
        except httpx.HTTPError as exc:
            return ToolResult(
                tool="prometheus",
                data={"cluster": self.organization.name, "promql": query},
                source_url=self.organization.prometheus_url,
                warning=f"Prometheus request failed: {exc}",
            )

    # ------------------------------------------------------------------ #
    # Query building                                                       #
    # ------------------------------------------------------------------ #

    # Generic words that mean "all services" — must not become PromQL label selectors
    _GENERIC_SVC = re.compile(r"^services?$", re.I)

    @staticmethod
    def _service(question: str) -> str:
        """Extract a specific service name or return '.*' for wildcard.

        Avoids returning generic words like 'service' or 'services' which would
        produce a selector that matches nothing in the metric store.
        """
        m = re.search(r"([\w-]*(?:service|api|gateway)[\w-]*)", question, re.I)
        if not m:
            return ".*"
        svc = m.group(1)
        # "service" or "services" alone means ALL services → wildcard
        if PrometheusTool._GENERIC_SVC.fullmatch(svc):
            return ".*"
        return svc

    @staticmethod
    def _time_window(question: str) -> str:
        """Extract PromQL range from natural language, defaulting to [5m]."""
        q = question.lower()
        m = re.search(r"last\s+(\d+)\s*(minute|min|hour|hr|day)s?", q)
        if m:
            amount = int(m.group(1))
            unit = m.group(2)
            if unit in ("minute", "min"):
                return f"[{amount}m]"
            if unit in ("hour", "hr"):
                return f"[{amount}h]"
            if unit == "day":
                return f"[{amount * 24}h]"
        return "[5m]"

    @staticmethod
    def _promql(question: str, service: str, window: str) -> str:
        q = question.lower()
        labels = f'service=~"{service}"'
        ns_m = re.search(r"(?:under|in|namespace)\s+([\w-]+)", question, re.I)
        ns = ns_m.group(1) if ns_m else ""

        if "pod" in q:
            ns_sel = f'namespace="{ns}"' if ns else ""
            return f"kube_pod_info{{{ns_sel}}}"
        if "namespace" in q:
            return "count by (namespace) (kube_pod_info)"
        if "cpu" in q:
            return f"sum by (service) (rate(container_cpu_usage_seconds_total{{{labels}}}{window}))"
        if "memory" in q:
            return f"sum by (service) (container_memory_working_set_bytes{{{labels}}})"
        if "hpa" in q or "replica" in q or "autoscaler" in q:
            return (
                f"max by (namespace, service, horizontalpodautoscaler) "
                f"(kube_horizontalpodautoscaler_status_current_replicas{{{labels}}})"
            )
        if "failed" in q or "failure" in q:
            ns_sel = f'namespace="{ns}", ' if ns else ""
            return f'sum by (namespace, service) (kube_pod_status_phase{{{ns_sel}{labels},phase="Failed"}})'
        if "5xx" in q or "error rate" in q:
            return (
                f'sum by (service) (rate(http_requests_total{{{labels},status=~"5.."}}{window})) '
                f'/ sum by (service) (rate(http_requests_total{{{labels}}}{window}))'
            )
        # Default: request rate
        return f"sum by (service) (rate(http_requests_total{{{labels}}}{window}))"

    # ------------------------------------------------------------------ #
    # Analysis                                                             #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _analyze_all_series(result: list[dict], query: str) -> dict:
        """Aggregate ALL returned series and detect anomalies + HPA pressure."""
        series = []
        for item in result:
            try:
                value = float(item["value"][1])
            except (KeyError, IndexError, TypeError, ValueError):
                continue
            metric = item.get("metric", {})
            series.append({
                "namespace": metric.get("namespace", "unknown"),
                "service": metric.get("service", "unknown"),
                "pod": metric.get("pod"),
                "hpa": metric.get("horizontalpodautoscaler"),
                "value": value,
            })

        q_lower = query.lower()
        unit = "bytes" if "memory" in q_lower else "replicas" if "hpa" in q_lower else "value"

        if not series:
            return {"total_series": 0, "unit": unit, "message": "No matching metric series returned."}

        values = [s["value"] for s in series]
        avg = mean(values)
        ordered = sorted(series, key=lambda s: s["value"], reverse=True)

        # Anomaly detection: services with value > 2× mean (skip near-zero means)
        anomalies = [s for s in series if avg > 0.001 and s["value"] > 2 * avg]

        # HPA pressure: replicas >= 80% of max (placeholder — mock data lacks max)
        hpa_scaled = [s for s in series if s.get("hpa") and s["value"] >= 7]

        # Namespace breakdown
        ns_totals: dict[str, float] = {}
        for s in series:
            ns_totals[s["namespace"]] = ns_totals.get(s["namespace"], 0.0) + s["value"]
        ns_breakdown = [{"namespace": ns, "total": total} for ns, total in
                        sorted(ns_totals.items(), key=lambda x: x[1], reverse=True)]

        return {
            "total_series": len(series),
            "namespace_count": len(ns_totals),
            "namespaces": sorted(ns_totals.keys()),
            "unit": unit,
            "sum": sum(values),
            "average": avg,
            "minimum": min(values),
            "maximum": max(values),
            "highest_consumers": ordered[:10],
            "anomalies": anomalies[:10],
            "hpa_under_pressure": hpa_scaled[:10],
            "namespace_breakdown": ns_breakdown[:10],
        }

from abc import ABC, abstractmethod
from app.models import ToolResult


class ObservabilityTool(ABC):
    name: str

    @abstractmethod
    async def run(self, question: str) -> ToolResult: ...


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, ObservabilityTool] = {}

    def register(self, tool: ObservabilityTool) -> None:
        self._tools[tool.name] = tool

    async def execute(self, name: str, question: str) -> ToolResult:
        if name not in self._tools:
            return ToolResult(tool="kubernetes", data={}, warning="This tool is not configured in this deployment.")
        return await self._tools[name].run(question)

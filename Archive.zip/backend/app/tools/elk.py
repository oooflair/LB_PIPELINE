"""ELK / Elasticsearch observability tool.

Enhancements over the original:
- Time-range filter: parses "last 30 minutes", "last 2 hours", "today", "yesterday"
- Severity filter: extracts ERROR / WARN / FATAL from the question
- Service name extraction: handles any <name>-service, <name>-api, <name>-gateway pattern
- Slow-request detection: returns events with elapsed_ms above a threshold
- Transaction flow: includes failure_count, first_seen, last_seen at the flow level
"""
from __future__ import annotations

import re
from datetime import UTC, datetime, timedelta

import httpx

from app.core.config import OrganizationConfig, get_settings
from app.models import ToolResult
from .base import ObservabilityTool

_SLOW_MS_THRESHOLD = 500  # log events above this elapsed_ms are "slow"


class ElkTool(ObservabilityTool):
    name = "elk"

    def __init__(self, organization: OrganizationConfig) -> None:
        self.organization = organization

    # ------------------------------------------------------------------ #
    # Main entry                                                           #
    # ------------------------------------------------------------------ #

    async def run(self, question: str) -> ToolResult:
        s = get_settings()
        if not self.organization.elasticsearch_url:
            return ToolResult(
                tool="elk", data={},
                warning=f"ELK is not configured for **{self.organization.name}**.",
            )

        prefix = self.organization.log_field_prefix
        correlation = self._extract_correlation_id(question)
        service = self._extract_service(question)
        severity = self._extract_severity(question)
        time_range = self._parse_time_range(question)

        # Build query
        must: list[dict] = []
        if correlation:
            must.append({"match_phrase": {f"{prefix}.correlationId": correlation}})
        elif severity:
            must.append({"match": {f"{prefix}.priority": severity}})
        elif self._is_slow_request_query(question):
            must.append({"range": {f"{prefix}.elapsed": {"gte": _SLOW_MS_THRESHOLD}}})
        else:
            must.append({
                "query_string": {
                    "query": question,
                    "default_field": f"{prefix}.message",
                    "default_operator": "AND",
                }
            })

        if service:
            must.append({"match": {f"{prefix}.applicationName": service}})

        if time_range:
            gte, lte = time_range
            must.append({"range": {"@timestamp": {"gte": gte, "lte": lte}}})

        payload = {
            "size": s.max_result_items,
            "sort": [{"@timestamp": "desc"}],
            "query": {"bool": {"must": must}},
        }

        try:
            async with httpx.AsyncClient(timeout=s.request_timeout_seconds, verify=True) as client:
                resp = await client.post(
                    f"{self.organization.elasticsearch_url.rstrip('/')}"
                    f"/{self.organization.elasticsearch_index}/_search",
                    json=payload,
                    auth=self.organization.elasticsearch_auth,
                )
                resp.raise_for_status()
            hit_data = resp.json().get("hits", {})
            hits = hit_data.get("hits", [])
            events = [h.get("_source", {}) for h in hits]
            total_val = hit_data.get("total", {})
            total = total_val.get("value", len(events)) if isinstance(total_val, dict) else total_val or len(events)

            return ToolResult(
                tool="elk",
                data={
                    "cluster": self.organization.name,
                    "analysis": self._analyze_events(events, prefix, total),
                    "time_filter": bool(time_range),
                },
                source_url=self.organization.elasticsearch_url,
            )
        except httpx.HTTPError as exc:
            return ToolResult(
                tool="elk", data={},
                source_url=self.organization.elasticsearch_url,
                warning=f"ELK request failed: {exc}",
            )

    # ------------------------------------------------------------------ #
    # Extraction helpers                                                   #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _extract(pattern: str, text: str) -> str | None:
        m = re.search(pattern, text, re.I)
        return m.group(1) if m else None

    @staticmethod
    def _extract_correlation_id(question: str) -> str | None:
        # 1. Standard pattern: correlationId: value, correlation_id = value, request_id = value
        m = re.search(r"(?:correlation[ _-]?id|request[ _-]?id|transaction[ _-]?id)\s*[:=]?\s*([\w.\-]+)", question, re.I)
        if m:
            return m.group(1)
        # 2. Known prefixes/formats: mule-correlation-xxxx, correlation-xxxx, etc.
        m2 = re.search(r"\b((?:mule-)?correlation-[\w.\-]+)\b", question, re.I)
        if m2:
            return m2.group(1)
        # 3. UUID pattern fallback
        m3 = re.search(r"\b([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})\b", question)
        if m3:
            return m3.group(1)
        return None

    @staticmethod
    def _extract_service(question: str) -> str | None:
        m = re.search(r"([\w-]+(?:service|api|gateway))", question, re.I)
        return m.group(1) if m else None

    @staticmethod
    def _extract_severity(question: str) -> str | None:
        q = question.upper()
        if "FAIL" in q:
            return "ERROR"
        for level in ("FATAL", "ERROR", "WARN", "WARNING", "DEBUG"):
            if level in q or f" {level.lower()} " in question.lower():
                return "WARN" if level == "WARNING" else level
        return None

    @staticmethod
    def _is_slow_request_query(question: str) -> bool:
        q = question.lower()
        return any(kw in q for kw in ("slow", "timeout", "latency", "response time", "delay"))

    @staticmethod
    def _parse_time_range(question: str) -> tuple[str, str] | None:
        """Return (gte_iso, lte_iso) or None."""
        now = datetime.now(UTC)
        q = question.lower()
        m = re.search(r"last\s+(\d+)\s*(minute|min|hour|hr|day|week)s?", q)
        if m:
            amount = int(m.group(1))
            unit = m.group(2)
            if unit in ("minute", "min"):
                delta = timedelta(minutes=amount)
            elif unit in ("hour", "hr"):
                delta = timedelta(hours=amount)
            elif unit == "day":
                delta = timedelta(days=amount)
            else:
                delta = timedelta(weeks=amount)
            return ((now - delta).isoformat(), now.isoformat())
        if "today" in q:
            start = now.replace(hour=0, minute=0, second=0, microsecond=0)
            return (start.isoformat(), now.isoformat())
        if "yesterday" in q:
            yesterday = now - timedelta(days=1)
            start = yesterday.replace(hour=0, minute=0, second=0, microsecond=0)
            end = yesterday.replace(hour=23, minute=59, second=59, microsecond=0)
            return (start.isoformat(), end.isoformat())
        return None

    # ------------------------------------------------------------------ #
    # Analysis                                                             #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _analyze_events(events: list[dict], prefix: str, total: int) -> dict:
        correlation_ids: list[str] = []
        applications: dict[str, int] = {}
        priorities: dict[str, int] = {}
        flows: dict[str, list[dict]] = {}
        slow_requests: list[dict] = []

        for event in events:
            log = event.get(prefix, {})
            cid = log.get("correlationId")
            if cid and cid not in correlation_ids:
                correlation_ids.append(cid)
            app = log.get("applicationName", "unknown")
            priority = log.get("priority", "unknown")
            elapsed = log.get("elapsed") or 0

            applications[app] = applications.get(app, 0) + 1
            priorities[priority] = priorities.get(priority, 0) + 1

            if elapsed and elapsed >= _SLOW_MS_THRESHOLD:
                slow_requests.append({
                    "application": app,
                    "elapsed_ms": elapsed,
                    "message": log.get("message", ""),
                    "priority": priority,
                    "correlation_id": cid,
                    "timestamp": log.get("timestamp") or event.get("@timestamp"),
                })

            if cid:
                flows.setdefault(cid, []).append({
                    "timestamp": log.get("timestamp") or event.get("@timestamp"),
                    "trace_point": log.get("tracePoint", "unknown"),
                    "message": log.get("message", ""),
                    "application": app,
                    "elapsed_ms": elapsed,
                    "priority": priority,
                })

        transaction_flows = []
        for cid, stages in flows.items():
            ordered = sorted(stages, key=lambda s: s["timestamp"] or "")
            for i, stage in enumerate(ordered):
                stage["from_application"] = "Client" if i == 0 else ordered[i - 1]["application"]
                stage["to_application"] = stage["application"]
            failures = [s for s in ordered if s["priority"].upper() in {"ERROR", "FATAL"}]
            timestamps = [s["timestamp"] for s in ordered if s["timestamp"]]
            transaction_flows.append({
                "correlation_id": cid,
                "stage_count": len(ordered),
                "total_elapsed_ms": sum(s["elapsed_ms"] or 0 for s in ordered),
                "failure_count": len(failures),
                "first_seen": timestamps[0] if timestamps else None,
                "last_seen": timestamps[-1] if timestamps else None,
                "stages": ordered,
                "failures": failures,
                "affected_application": failures[0]["application"] if failures else None,
            })

        return {
            "total_matching_events": total,
            "returned_events_analyzed": len(events),
            "correlation_ids": correlation_ids[:10],
            "unique_correlation_ids_in_returned_events": len(correlation_ids),
            "applications": applications,
            "priorities": priorities,
            "slow_requests": sorted(slow_requests, key=lambda r: r["elapsed_ms"], reverse=True)[:10],
            "transaction_flows": transaction_flows,
        }

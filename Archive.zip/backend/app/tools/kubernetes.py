"""Kubernetes stub tool — returns a clear, actionable message.

A full Kubernetes tool would use the kubernetes-client library and require
cluster-admin or a scoped ServiceAccount token.  This stub keeps the routing
registry complete while avoiding silent empty responses.
"""
from app.core.config import OrganizationConfig
from app.models import ToolResult
from .base import ObservabilityTool


class KubernetesTool(ObservabilityTool):
    name = "kubernetes"

    def __init__(self, organization: OrganizationConfig) -> None:
        self.organization = organization

    async def run(self, question: str) -> ToolResult:
        return ToolResult(
            tool="kubernetes",
            data={},
            warning=(
                f"Direct Kubernetes API access is not yet configured for **{self.organization.name}**. "
                "Namespace and pod *metrics* are available via Prometheus — try asking about "
                "'show all namespaces' or 'show failed pods' instead. "
                "To enable Kubernetes object queries, add a kubeconfig or in-cluster ServiceAccount "
                "token and implement the KubernetesTool."
            ),
        )

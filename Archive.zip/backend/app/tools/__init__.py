from app.core.config import OrganizationConfig
from .base import ToolRegistry
from .elk import ElkTool
from .prometheus import PrometheusTool
from .jaeger import JaegerTool
from .kubernetes import KubernetesTool


def build_registry(organization: OrganizationConfig) -> ToolRegistry:
    registry = ToolRegistry()
    registry.register(ElkTool(organization))
    registry.register(PrometheusTool(organization))
    registry.register(JaegerTool(organization))
    registry.register(KubernetesTool(organization))
    return registry

"""Jaeger distributed-trace observability tool.

Enhancements over the original:
- FIX: regex bug in _extract_trace_id — trace ID extraction was always failing
- Service-based trace search when no trace ID is present
- List all traced services via /api/services
- Span-level analysis: error spans, slowest spans, hop count, critical path
"""
from __future__ import annotations

import re

import httpx

from app.core.config import OrganizationConfig, get_settings
from app.models import ToolResult
from .base import ObservabilityTool


class JaegerTool(ObservabilityTool):
    name = "jaeger"

    def __init__(self, organization: OrganizationConfig) -> None:
        self.organization = organization

    # ------------------------------------------------------------------ #
    # Main entry                                                           #
    # ------------------------------------------------------------------ #

    async def run(self, question: str) -> ToolResult:
        s = get_settings()
        if not self.organization.jaeger_url:
            return ToolResult(
                tool="jaeger", data={},
                warning=(
                    f"Jaeger is not configured for **{self.organization.name}**. "
                    "Set `jaeger_url` in config/observability.yaml for this cluster."
                ),
            )

        # Decide which Jaeger API call to make
        trace_id = self._extract_trace_id(question)
        service = self._extract_service(question)

        if trace_id:
            return await self._get_trace(trace_id, s.request_timeout_seconds)

        if self._is_service_list_query(question):
            return await self._list_services(s.request_timeout_seconds)

        if service:
            return await self._get_service_traces(service, s.request_timeout_seconds)

        return ToolResult(
            tool="jaeger", data={},
            source_url=self.organization.jaeger_url,
            warning=(
                "Please provide a trace ID, service name, or ask to list services. "
                "Example: 'show trace abc123' or 'show traces for payment-service'."
            ),
        )

    # ------------------------------------------------------------------ #
    # Jaeger API calls                                                     #
    # ------------------------------------------------------------------ #

    async def _get_trace(self, trace_id: str, timeout: float) -> ToolResult:
        try:
            async with httpx.AsyncClient(timeout=timeout, verify=True) as client:
                resp = await client.get(
                    f"{self.organization.jaeger_url.rstrip('/')}/api/traces/{trace_id}"
                )
                resp.raise_for_status()
            data = resp.json().get("data", [])
            trace = data[0] if data else {}
            return ToolResult(
                tool="jaeger",
                data={
                    "cluster": self.organization.name,
                    "trace_id": trace_id,
                    "trace": trace,
                    "analysis": self._analyze_trace(trace),
                },
                source_url=self.organization.jaeger_url,
            )
        except httpx.HTTPError as exc:
            return ToolResult(
                tool="jaeger", data={},
                source_url=self.organization.jaeger_url,
                warning=f"Jaeger trace request failed: {exc}",
            )

    async def _list_services(self, timeout: float) -> ToolResult:
        try:
            async with httpx.AsyncClient(timeout=timeout, verify=True) as client:
                resp = await client.get(
                    f"{self.organization.jaeger_url.rstrip('/')}/api/services"
                )
                resp.raise_for_status()
            services = resp.json().get("data", [])
            return ToolResult(
                tool="jaeger",
                data={
                    "cluster": self.organization.name,
                    "services": services,
                    "total": len(services),
                },
                source_url=self.organization.jaeger_url,
            )
        except httpx.HTTPError as exc:
            return ToolResult(
                tool="jaeger", data={},
                source_url=self.organization.jaeger_url,
                warning=f"Jaeger services request failed: {exc}",
            )

    async def _get_service_traces(self, service: str, timeout: float, limit: int = 20) -> ToolResult:
        try:
            async with httpx.AsyncClient(timeout=timeout, verify=True) as client:
                resp = await client.get(
                    f"{self.organization.jaeger_url.rstrip('/')}/api/traces",
                    params={"service": service, "limit": limit},
                )
                resp.raise_for_status()
            data = resp.json().get("data", [])
            analyses = [self._analyze_trace(t) for t in data[:5]]
            return ToolResult(
                tool="jaeger",
                data={
                    "cluster": self.organization.name,
                    "service": service,
                    "total_traces": len(data),
                    "recent_traces": [
                        {
                            "trace_id": t.get("traceID"),
                            "span_count": len(t.get("spans", [])),
                            "analysis": analyses[i],
                        }
                        for i, t in enumerate(data[:5])
                    ],
                },
                source_url=self.organization.jaeger_url,
            )
        except httpx.HTTPError as exc:
            return ToolResult(
                tool="jaeger", data={},
                source_url=self.organization.jaeger_url,
                warning=f"Jaeger traces request failed: {exc}",
            )

    # ------------------------------------------------------------------ #
    # Extraction helpers                                                   #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _extract_trace_id(question: str) -> str | None:
        # FIX: was `\\s*` (literal backslash-s), now correctly `\s*`
        m = re.search(
            r"(?:trace(?:[ _-]?id)?|tracing)\s*[:=]?\s*([a-fA-F0-9]{8,64})\b",
            question, re.I,
        )
        if m:
            return m.group(1)
        # Fallback: any bare hex string that looks like a trace ID
        m2 = re.search(r"\b([a-fA-F0-9]{16,64})\b", question)
        return m2.group(1) if m2 else None

    _GENERIC_SERVICES = frozenset(["service", "services", "app", "apps", "api", "gateway"])

    @staticmethod
    def _extract_service(question: str) -> str | None:
        m = re.search(r"([\w-]+(?:service|api|gateway|app)[\w-]*)", question, re.I)
        if m:
            svc = m.group(1)
            if svc.lower() in JaegerTool._GENERIC_SERVICES:
                return None
            return svc
        return None

    @staticmethod
    def _is_service_list_query(question: str) -> bool:
        q = question.lower()
        keywords = (
            "list services", "all services", "what services", "service list", "services in", "services present",
            "list apps", "all apps", "what apps", "app list", "apps in", "apps present",
            "how many services", "how many apps", "show services", "show apps", "get services", "get apps"
        )
        return any(kw in q for kw in keywords)

    # ------------------------------------------------------------------ #
    # Span analysis                                                        #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _analyze_trace(trace: dict) -> dict:
        if not trace:
            return {}
        spans = trace.get("spans", [])
        processes = trace.get("processes", {})
        if not spans:
            return {"span_count": 0}

        durations = []
        error_spans = []
        services_seen: set[str] = set()

        for span in spans:
            duration = span.get("duration", 0)
            durations.append(duration)
            pid = span.get("processID", "")
            service_name = processes.get(pid, {}).get("serviceName", "unknown")
            services_seen.add(service_name)

            tags = {t["key"]: t["value"] for t in span.get("tags", [])}
            is_error = tags.get("error") is True or str(tags.get("http.status_code", "")).startswith("5")
            if is_error:
                error_spans.append({
                    "operation": span.get("operationName"),
                    "service": service_name,
                    "duration_ms": round(duration / 1000, 2),
                    "status": tags.get("http.status_code"),
                })

        ordered = sorted(spans, key=lambda s: s.get("duration", 0), reverse=True)
        slowest = [
            {
                "operation": s.get("operationName"),
                "service": processes.get(s.get("processID", ""), {}).get("serviceName", "unknown"),
                "duration_ms": round(s.get("duration", 0) / 1000, 2),
            }
            for s in ordered[:5]
        ]

        total_us = sum(durations)
        return {
            "span_count": len(spans),
            "service_count": len(services_seen),
            "services": sorted(services_seen),
            "total_duration_ms": round(total_us / 1000, 2),
            "average_span_ms": round((total_us / len(spans)) / 1000, 2) if spans else 0,
            "error_span_count": len(error_spans),
            "error_spans": error_spans,
            "slowest_spans": slowest,
            "has_errors": len(error_spans) > 0,
        }

"""Deterministic, auditable routing policy with high-confidence fast path.

Routing strategy:
  1. If IntentRouter confidence >= HIGH_CONFIDENCE_THRESHOLD → use directly (no LLM call)
  2. If confidence < threshold → agent falls through to llm.plan() for disambiguation

Add organisation-specific vocabulary here and cover it with tests.
"""
import re
from app.models import RouteDecision

# Questions scoring at least this confidence bypass the LLM planner entirely.
HIGH_CONFIDENCE_THRESHOLD = 0.85


class IntentRouter:
    """Keyword-based intent classifier. Fast, deterministic, fully auditable."""

    # Scored keyword vocabulary per tool.  Longer, more-specific terms score higher
    # because they are matched first via the explicit-rule block below.
    KEYWORDS: dict[str, tuple[str, ...]] = {
        "elk": (
            "log", "logs", "logging", "exception", "stacktrace", "stack trace",
            "error log", "error logs", "application log", "mule log",
            "correlation id", "correlation_id", "request id", "request_id",
            "warning", "fatal", "debug", "slow request", "message",
            # Mule transaction terms — these are log events, NOT distributed traces
            "transaction", "transactions", "failed transaction", "failed transactions",
            "mule transaction",
        ),
        "prometheus": (
            "cpu", "memory", "metric", "metrics", "latency", "throughput",
            "rps", "error rate", "5xx", "utilization", "resource",
            "hpa", "replica", "replicas", "autoscaler",
            "pod", "pods", "namespace", "namespaces",
            "failed pod", "failed pods", "resource usage",
        ),
        "jaeger": (
            "trace", "traces", "span", "spans",
            "service graph", "distributed tracing", "tracing",
            "service dependency", "service map",
        ),
    }

    # Time-related vocabulary — reinforces whichever tool was already matched
    # but does NOT by itself determine routing.
    TIME_TERMS: frozenset[str] = frozenset(
        ["last", "recent", "today", "yesterday", "hour", "hours",
         "minute", "minutes", "day", "days", "week", "ago"]
    )

    GREETING_PATTERN = re.compile(
        r"^\s*(hi|hello|hey|good\s+(morning|afternoon|evening)|what can you|help me|what do you)\b",
        re.I,
    )

    # ------------------------------------------------------------------ #
    # Public interface                                                      #
    # ------------------------------------------------------------------ #

    def route(self, question: str) -> RouteDecision:
        text = question.lower().strip()

        # Empty input or greeting → conversation mode
        if not text or self.GREETING_PATTERN.match(question):
            return RouteDecision(
                tools=[], confidence=1.0, reason="greeting", clarification="greeting"
            )

        # --------------------------------------------------------------- #
        # Explicit high-signal rules (ordered most-specific → least)      #
        # --------------------------------------------------------------- #

        # ELK: Mule transaction signals — MUST come before Jaeger rule.
        # In a Mule/ESB context, "transactions", "failed transactions", and
        # "transaction logs" refer to application log events stored in ELK
        # (they carry correlationId + transactionId fields), NOT Jaeger spans.
        if self._has(text, "transaction", "transactions", "failed transaction",
                     "failed transactions", "mule transaction"):
            return RouteDecision(
                tools=["elk"], confidence=0.96,
                reason="Mule transaction terminology — ELK log event lookup",
            )

        # Jaeger: explicit trace / span language (NOT triggered by 'transaction')
        if self._has(text, "trace", "traces", "span", "spans", "jaeger", "distributed tracing", "service map"):
            return RouteDecision(tools=["jaeger"], confidence=0.98, reason="explicit trace/span terminology → Jaeger")

        # Jaeger: service/app listing queries
        if self._has(text, "list services", "all services", "show services", "what services",
                     "list apps", "all apps", "show apps", "what apps", "how many apps"):
            return RouteDecision(tools=["jaeger"], confidence=0.95, reason="service listing query → Jaeger")

        # ELK: correlation / request ID is a log signal unless user said "trace"
        if self._has(text, "correlation id", "correlation_id", "request id", "request_id"):
            return RouteDecision(tools=["elk"], confidence=0.98, reason="correlation / request ID → ELK log lookup")

        # ELK: unambiguous log signals
        if self._has(text, "log", "logs", "exception", "stacktrace", "stack trace", "fatal", "error log"):
            return RouteDecision(tools=["elk"], confidence=0.95, reason="explicit log terminology → ELK")

        # Kubernetes objects (not wired to a tool yet — returns a clear message)
        if self._has(text, "deployment", "statefulset", "kubernetes", "k8s", "ingress", "configmap"):
            return RouteDecision(tools=["kubernetes"], confidence=0.99, reason="Kubernetes object query")

        # Prometheus: resource metrics
        if self._has(text, "cpu", "memory", "utilization", "hpa", "autoscaler", "resource usage"):
            return RouteDecision(tools=["prometheus"], confidence=0.95, reason="resource metric → Prometheus")

        # Prometheus: workload inventory
        if self._has(text, "namespace", "namespaces", "pod", "pods", "failed pod", "failed pods", "replica", "replicas"):
            return RouteDecision(tools=["prometheus"], confidence=0.92, reason="workload inventory → Prometheus")

        # Prometheus: traffic metrics
        if self._has(text, "5xx", "error rate", "latency", "throughput", "rps", "request rate"):
            return RouteDecision(tools=["prometheus"], confidence=0.92, reason="traffic metric → Prometheus")

        # ELK: slower-burning log signals
        if self._has(text, "warning", "debug", "slow request", "message"):
            return RouteDecision(tools=["elk"], confidence=0.87, reason="log keyword → ELK")

        # --------------------------------------------------------------- #
        # Scored fallback — remains below HIGH_CONFIDENCE_THRESHOLD so the #
        # agent will consult the LLM planner for disambiguation.            #
        # --------------------------------------------------------------- #
        scores = {
            tool: sum(1 for term in terms if term in text)
            for tool, terms in self.KEYWORDS.items()
        }
        best = max(scores, key=scores.get)
        if scores[best] == 0:
            return RouteDecision(
                tools=[], confidence=0.5, reason="conversation", clarification="conversation"
            )
        # Cap at 0.84 so that ambiguous multi-keyword queries still go to LLM
        confidence = min(0.55 + scores[best] * 0.1, 0.84)
        return RouteDecision(
            tools=[best], confidence=confidence, reason=f"keyword scoring → {best} ({scores[best]} match(es))"
        )

    def requires_llm(self, decision: RouteDecision) -> bool:
        """Return True when the LLM planner should override or refine this decision."""
        return decision.confidence < HIGH_CONFIDENCE_THRESHOLD

    # ------------------------------------------------------------------ #
    # Helpers                                                              #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _has(text: str, *terms: str) -> bool:
        return any(re.search(r"\b" + re.escape(term) + r"\b", text) for term in terms)

"""Typed MCP catalog for external MCP clients (Claude Desktop, Cursor, etc.).

26 tools across Prometheus, ELK, Jaeger, and cross-source composites.
Every tool requires an exact configured cluster name — no cross-cluster fallback.

Run the MCP server independently:
  cd backend && python -m app.mcp_server
"""
from app.core.config import get_organization
from app.tools import build_registry
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Engineering Observability Copilot")


async def _run(cluster: str, tool: str, question: str) -> dict:
    organization = get_organization(cluster)
    result = await build_registry(organization).execute(tool, question)
    return result.model_dump(mode="json")


# ============================================================
# Prometheus — infrastructure & workload metrics
# ============================================================

@mcp.tool()
async def list_namespaces(cluster: str) -> dict:
    """List all Kubernetes namespaces from Prometheus kube_pod_info metrics."""
    return await _run(cluster, "prometheus", "show all namespaces")


@mcp.tool()
async def list_pods(cluster: str, namespace: str) -> dict:
    """List pods in one namespace from Prometheus kube_pod_info metrics."""
    return await _run(cluster, "prometheus", f"show pods under {namespace}")


@mcp.tool()
async def get_failed_pods(cluster: str, namespace: str = "") -> dict:
    """Get failed pod counts, optionally scoped to one namespace."""
    scope = f" in namespace {namespace}" if namespace else ""
    return await _run(cluster, "prometheus", f"show failed pods{scope}")


@mcp.tool()
async def get_hpa_status(cluster: str, namespace: str = "") -> dict:
    """Get HPA current replica counts, optionally scoped to one namespace."""
    scope = f" in namespace {namespace}" if namespace else ""
    return await _run(cluster, "prometheus", f"show HPA status{scope}")


@mcp.tool()
async def get_cpu_usage(cluster: str, service: str = "", last_minutes: int = 5) -> dict:
    """Get CPU usage metrics for one service or all services, over a custom window."""
    scope = f" for {service}" if service else ""
    return await _run(cluster, "prometheus", f"show CPU usage{scope} last {last_minutes} minutes")


@mcp.tool()
async def get_memory_usage(cluster: str, service: str = "") -> dict:
    """Get memory usage metrics for one service or all services."""
    scope = f" for {service}" if service else ""
    return await _run(cluster, "prometheus", f"show memory usage{scope}")


@mcp.tool()
async def get_request_rate(cluster: str, service: str = "", last_minutes: int = 5) -> dict:
    """Get HTTP request-rate metrics for one service or all services."""
    scope = f" for {service}" if service else ""
    return await _run(cluster, "prometheus", f"show request rate{scope} last {last_minutes} minutes")


@mcp.tool()
async def get_error_rate(cluster: str, service: str = "", last_minutes: int = 5) -> dict:
    """Get HTTP 5xx error-rate metrics for one service or all services."""
    scope = f" for {service}" if service else ""
    return await _run(cluster, "prometheus", f"show 5xx error rate{scope} last {last_minutes} minutes")


@mcp.tool()
async def get_top_consumers(cluster: str, metric: str = "cpu", limit: int = 10) -> dict:
    """Get top N services by cpu or memory consumption.

    Args:
        metric: 'cpu' or 'memory'
        limit:  number of results (max 50)
    """
    return await _run(cluster, "prometheus", f"show {metric} usage")


@mcp.tool()
async def get_anomalies(cluster: str, metric: str = "cpu") -> dict:
    """Detect services with anomalous cpu or memory usage (> 2× cluster mean)."""
    return await _run(cluster, "prometheus", f"show {metric} usage")


@mcp.tool()
async def get_namespace_summary(cluster: str, namespace: str) -> dict:
    """Get a full health snapshot for one namespace: pods, CPU, memory, failed pods."""
    org = get_organization(cluster)
    reg = build_registry(org)
    cpu, mem, pods, failed = await __import__("asyncio").gather(
        reg.execute("prometheus", f"show CPU usage in namespace {namespace}"),
        reg.execute("prometheus", f"show memory usage in namespace {namespace}"),
        reg.execute("prometheus", f"show pods under {namespace}"),
        reg.execute("prometheus", f"show failed pods in namespace {namespace}"),
    )
    return {
        "namespace": namespace,
        "cpu": cpu.model_dump(mode="json"),
        "memory": mem.model_dump(mode="json"),
        "pods": pods.model_dump(mode="json"),
        "failed_pods": failed.model_dump(mode="json"),
    }


# ============================================================
# ELK — application logs
# ============================================================

@mcp.tool()
async def search_logs(cluster: str, question: str) -> dict:
    """Search ELK logs with a natural-language, read-only query."""
    return await _run(cluster, "elk", question)


@mcp.tool()
async def get_logs_by_correlation_id(cluster: str, correlation_id: str) -> dict:
    """Find Mule logs by correlation ID and reconstruct the full transaction flow."""
    return await _run(cluster, "elk", f"analyze logs for correlation id {correlation_id}")


@mcp.tool()
async def get_application_logs(cluster: str, application: str) -> dict:
    """Get recent logs for one application."""
    return await _run(cluster, "elk", f"show logs for {application}")


@mcp.tool()
async def get_error_logs(cluster: str, application: str = "") -> dict:
    """Get ERROR and FATAL logs, optionally scoped to one application."""
    scope = f" for {application}" if application else ""
    return await _run(cluster, "elk", f"show error logs{scope}")


@mcp.tool()
async def get_slow_request_logs(cluster: str, application: str = "", threshold_ms: int = 500) -> dict:
    """Get logs for requests slower than threshold_ms, optionally for one application."""
    scope = f" for {application}" if application else ""
    return await _run(cluster, "elk", f"show slow request logs{scope}")


@mcp.tool()
async def get_logs_by_time_range(cluster: str, service: str = "", since_minutes: int = 30) -> dict:
    """Get logs from the last N minutes, optionally scoped to one service."""
    scope = f" for {service}" if service else ""
    return await _run(cluster, "elk", f"show logs{scope} last {since_minutes} minutes")


@mcp.tool()
async def get_error_summary(cluster: str, last_minutes: int = 60) -> dict:
    """Get grouped error counts by application in the last N minutes."""
    return await _run(cluster, "elk", f"show error logs last {last_minutes} minutes")


@mcp.tool()
async def analyze_transaction(cluster: str, correlation_id: str) -> dict:
    """Return the complete ordered transaction flow for a Mule correlation ID."""
    return await _run(cluster, "elk", f"analyze logs for correlation id {correlation_id}")


# ============================================================
# Jaeger — distributed traces
# ============================================================

@mcp.tool()
async def get_trace(cluster: str, trace_id: str) -> dict:
    """Retrieve one Jaeger trace by its trace ID with full span analysis."""
    return await _run(cluster, "jaeger", f"show trace {trace_id}")


@mcp.tool()
async def get_trace_by_correlation_id(cluster: str, correlation_id: str) -> dict:
    """Retrieve a Jaeger trace when the correlation ID is also a trace ID."""
    return await _run(cluster, "jaeger", f"show trace {correlation_id}")


@mcp.tool()
async def get_services(cluster: str) -> dict:
    """List all services currently emitting traces to Jaeger."""
    return await _run(cluster, "jaeger", "list all services in jaeger")


@mcp.tool()
async def get_service_traces(cluster: str, service: str, limit: int = 20) -> dict:
    """Get the most recent traces for one service."""
    return await _run(cluster, "jaeger", f"show traces for {service}")


@mcp.tool()
async def analyze_trace(cluster: str, trace_id: str) -> dict:
    """Return full span breakdown, error spans, slowest spans, and critical path."""
    return await _run(cluster, "jaeger", f"show trace {trace_id}")


# ============================================================
# Cross-source composites
# ============================================================

@mcp.tool()
async def get_cluster_overview(cluster: str) -> dict:
    """Compact overview: namespaces, CPU, memory, failed pods, and recent error logs."""
    org = get_organization(cluster)
    reg = build_registry(org)
    ns, cpu, mem, failed, errs = await __import__("asyncio").gather(
        reg.execute("prometheus", "show all namespaces"),
        reg.execute("prometheus", "show CPU usage"),
        reg.execute("prometheus", "show memory usage"),
        reg.execute("prometheus", "show failed pods"),
        reg.execute("elk", "show error logs last 60 minutes"),
    )
    return {
        "namespaces": ns.model_dump(mode="json"),
        "cpu": cpu.model_dump(mode="json"),
        "memory": mem.model_dump(mode="json"),
        "failed_pods": failed.model_dump(mode="json"),
        "recent_error_logs": errs.model_dump(mode="json"),
    }


@mcp.tool()
async def get_cluster_health(cluster: str) -> dict:
    """Full cluster health: metrics anomalies + 5xx error rate + failed pods + error count."""
    org = get_organization(cluster)
    reg = build_registry(org)
    cpu, mem, err_rate, failed, errs = await __import__("asyncio").gather(
        reg.execute("prometheus", "show CPU usage"),
        reg.execute("prometheus", "show memory usage"),
        reg.execute("prometheus", "show 5xx error rate"),
        reg.execute("prometheus", "show failed pods"),
        reg.execute("elk", "show error logs"),
    )
    results = {
        "cpu_analysis": cpu.model_dump(mode="json"),
        "memory_analysis": mem.model_dump(mode="json"),
        "error_rate": err_rate.model_dump(mode="json"),
        "failed_pods": failed.model_dump(mode="json"),
        "log_errors": errs.model_dump(mode="json"),
    }
    # Quick health signal
    cpu_data = cpu.data.get("analysis", {})
    failed_data = failed.data.get("analysis", {})
    results["health_signals"] = {
        "anomalous_services": len(cpu_data.get("anomalies", [])),
        "failed_pod_total": sum(
            s.get("value", 0) for s in failed_data.get("highest_consumers", [])
        ),
        "cpu_anomalies": [s["service"] for s in cpu_data.get("anomalies", [])[:5]],
    }
    return results


if __name__ == "__main__":
    mcp.run()

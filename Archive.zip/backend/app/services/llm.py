"""LLM client — OpenAI-compatible adapter targeting Groq by default.

The model is used for three purposes:
  1. plan()           — select one observability tool (JSON contract, temp=0)
  2. summarize_stream() — stream a concise evidence-based answer (SSE)
  3. converse_stream()  — stream a warm conversational reply (SSE)
  4. suggest_followups() — generate 3 contextual follow-up questions

Streaming follows the OpenAI SSE wire format:
  data: {"choices":[{"delta":{"content":"..."}}]}
  ...
  data: [DONE]

Retry policy: up to 2 retries with 0.8 s / 1.6 s back-off on HTTP errors.
Fallback:     deterministic text summary used when LLM is unavailable.
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
from typing import AsyncIterator

import httpx

from app.core.config import get_settings
from app.models import ConversationTurn, RouteDecision, ToolResult

logger = logging.getLogger(__name__)

_MAX_RETRIES = 2
_RETRY_BASE_DELAY = 0.8  # seconds


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _turns_to_messages(context: list[ConversationTurn]) -> list[dict]:
    """Convert stored session turns to OpenAI message dicts."""
    return [{"role": t.role, "content": t.content} for t in context]


def _evidence_prompt(question: str, results: list[ToolResult], context: list[ConversationTurn]) -> str:
    evidence = [r.model_dump(mode="json") for r in results]
    history_block = ""
    if context:
        history_block = "\nConversation so far:\n" + "\n".join(
            f"  {t.role.upper()}: {t.content}" for t in context[-4:]
        ) + "\n"

    return (
        "You are a senior DevOps/SRE observability analyst.\n"
        "Answer ONLY from the supplied evidence — never invent data, metrics, or causes.\n"
        "Use Markdown: **bold** for key values, bullet points for lists, `code` for IDs.\n"
        "When Prometheus evidence has an 'analysis' object it covers ALL returned series — use its "
        "total, average, minimum, maximum, namespace count, and highest_consumers precisely.\n"
        "When ELK evidence has 'analysis.correlation_ids', list them directly.\n"
        "When ELK evidence has 'analysis.transaction_flows', describe each stage's from→to app, "
        "elapsed_ms, priority, and any failures.\n"
        "When Jaeger evidence has 'trace.spans', summarise the critical path and flag error spans.\n"
        "Do NOT mention tool warnings unless the evidence contains them.\n"
        f"{history_block}"
        f"Question: {question}\n"
        f"Evidence: {json.dumps(evidence, default=str)}"
    )


# ---------------------------------------------------------------------------
# Main client
# ---------------------------------------------------------------------------

class InternalLLMClient:
    """Wraps Groq (or any OpenAI-compatible API) for planning, summarising, and chatting."""

    # ------------------------------------------------------------------ #
    # Tool planner                                                         #
    # ------------------------------------------------------------------ #

    async def plan(
        self,
        question: str,
        cluster: str,
        capabilities: dict[str, str],
        context: list[ConversationTurn] | None = None,
    ) -> RouteDecision:
        """Ask the LLM to select exactly one configured tool (JSON contract, temp=0)."""
        settings = get_settings()
        if not settings.llm.api_url or not settings.llm.api_key:
            return RouteDecision(
                tools=[], confidence=0.0,
                reason="LLM not configured",
                clarification="The LLM is not configured. Add api_key to config/observability.yaml.",
            )

        catalog = "\n".join(f"- {name}: {desc}" for name, desc in capabilities.items())
        history_note = ""
        if context:
            history_note = "\nRecent conversation:\n" + "\n".join(
                f"  {t.role.upper()}: {t.content[:120]}" for t in context[-3:]
            ) + "\n"

        prompt = (
            f"Selected cluster: {cluster}\nAvailable tools:\n{catalog}\n{history_note}\n"
            "Choose exactly one available tool only when it can answer the user's request.\n"
            "For greetings or general chat → conversation.\n"
            "For unsupported/unavailable capability → unavailable.\n"
            "Return ONLY valid JSON: "
            '{"tool":"prometheus|elk|jaeger|conversation|unavailable","reason":"short reason",'
            '"clarification":"optional user-facing message if unavailable"}.\n'
            f"User message: {question!r}"
        )

        messages = [
            {"role": "system", "content": "You are a precise observability tool router. Return valid JSON only."},
            {"role": "user", "content": prompt},
        ]

        try:
            content = await self._post_json(messages, temperature=0.0, max_tokens=180)
            return self._parse_plan(content, capabilities)
        except Exception as exc:
            logger.warning("LLM planning failed: %s", exc)
            return RouteDecision(
                tools=[], confidence=0.0,
                reason="LLM routing failed",
                clarification="Could not determine a safe tool. Please retry or rephrase.",
            )

    @staticmethod
    def _parse_plan(content: str, capabilities: dict[str, str]) -> RouteDecision:
        match = re.search(r"\{.*\}", content, re.DOTALL)
        if not match:
            raise ValueError("LLM did not return a JSON object")
        payload = json.loads(match.group(0))
        tool = str(payload.get("tool", "unavailable")).lower()
        reason = str(payload.get("reason", "LLM tool-selection"))
        clarification = str(payload.get("clarification", "")).strip() or None
        if tool in capabilities:
            return RouteDecision(tools=[tool], confidence=0.95, reason=reason, clarification=None)  # type: ignore[arg-type]
        if tool == "conversation":
            return RouteDecision(tools=[], confidence=0.95, reason="conversation", clarification=None)
        return RouteDecision(
            tools=[], confidence=0.95, reason="unavailable",
            clarification=clarification or "I don't have a configured tool for that request.",
        )

    # ------------------------------------------------------------------ #
    # Streaming summariser (SSE tokens)                                    #
    # ------------------------------------------------------------------ #

    async def summarize_stream(
        self,
        question: str,
        results: list[ToolResult],
        context: list[ConversationTurn] | None = None,
    ) -> AsyncIterator[str]:
        """Yield answer tokens one at a time via Groq streaming API."""
        settings = get_settings()
        if not settings.llm.api_url or not settings.llm.api_key:
            yield self._fallback(results)
            return

        prompt = _evidence_prompt(question, results, context or [])
        messages = [
            {"role": "system", "content": "Be concise and evidence-based. Use Markdown formatting."},
            {"role": "user", "content": prompt},
        ]
        payload = {
            "model": settings.llm.model,
            "messages": messages,
            "temperature": settings.llm.temperature,
            "max_tokens": settings.llm.max_tokens,
            "stream": True,
        }
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {settings.llm.api_key}",
        }

        try:
            async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
                async with client.stream(
                    "POST",
                    f"{settings.llm.api_url.rstrip('/')}/chat/completions",
                    headers=headers,
                    json=payload,
                ) as response:
                    response.raise_for_status()
                    async for line in response.aiter_lines():
                        if not line.startswith("data: ") or line == "data: [DONE]":
                            continue
                        try:
                            chunk = json.loads(line[6:])
                            delta = chunk["choices"][0]["delta"].get("content", "")
                            if delta:
                                yield delta
                        except (json.JSONDecodeError, KeyError, IndexError):
                            continue
        except httpx.HTTPError as exc:
            logger.warning("LLM stream error: %s", exc)
            yield self._fallback(results, prefix="⚠️ LLM stream interrupted. ")

    # ------------------------------------------------------------------ #
    # Streaming conversational reply                                        #
    # ------------------------------------------------------------------ #

    async def converse_stream(
        self,
        question: str,
        cluster: str,
        context: list[ConversationTurn] | None = None,
    ) -> AsyncIterator[str]:
        """Stream a warm, brief conversational reply."""
        settings = get_settings()
        if not settings.llm.api_url or not settings.llm.api_key:
            yield (
                f"I'm ready to help with the **{cluster}** cluster. "
                "Ask about logs, metrics, traces, CPU, memory, failed pods, or HPA status."
            )
            return

        messages: list[dict] = [
            {
                "role": "system",
                "content": (
                    f"You are an Engineering Observability Copilot for the {cluster} cluster. "
                    "Reply warmly and briefly. Do not invent observability data. "
                    "Explain you can analyze logs (ELK), metrics (Prometheus), and traces (Jaeger). "
                    "Use Markdown sparingly."
                ),
            },
        ]
        if context:
            messages += _turns_to_messages(context[-4:])
        messages.append({"role": "user", "content": question})

        payload = {
            "model": settings.llm.model,
            "messages": messages,
            "temperature": min(settings.llm.temperature + 0.2, 0.7),
            "max_tokens": 400,
            "stream": True,
        }
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {settings.llm.api_key}",
        }

        try:
            async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
                async with client.stream(
                    "POST",
                    f"{settings.llm.api_url.rstrip('/')}/chat/completions",
                    headers=headers,
                    json=payload,
                ) as response:
                    response.raise_for_status()
                    async for line in response.aiter_lines():
                        if not line.startswith("data: ") or line == "data: [DONE]":
                            continue
                        try:
                            chunk = json.loads(line[6:])
                            delta = chunk["choices"][0]["delta"].get("content", "")
                            if delta:
                                yield delta
                        except (json.JSONDecodeError, KeyError, IndexError):
                            continue
        except httpx.HTTPError as exc:
            logger.warning("LLM converse stream error: %s", exc)
            yield (
                f"I'm ready to help with the **{cluster}** cluster. "
                "Ask about logs, metrics, traces, CPU, memory, failed pods, or HPA status."
            )

    # ------------------------------------------------------------------ #
    # Non-streaming fallback summariser (used internally when needed)      #
    # ------------------------------------------------------------------ #

    async def summarize(
        self,
        question: str,
        results: list[ToolResult],
        context: list[ConversationTurn] | None = None,
    ) -> str:
        """Non-streaming summarise — collects all stream tokens."""
        parts: list[str] = []
        async for token in self.summarize_stream(question, results, context):
            parts.append(token)
        return "".join(parts)

    # ------------------------------------------------------------------ #
    # Follow-up suggestions                                                #
    # ------------------------------------------------------------------ #

    async def suggest_followups(
        self,
        question: str,
        results: list[ToolResult],
        cluster: str,
    ) -> list[str]:
        """Return up to 3 smart follow-up questions based on what was retrieved."""
        settings = get_settings()
        if not settings.llm.api_url or not settings.llm.api_key:
            return _default_suggestions(results)

        tool_name = results[0].tool if results else "unknown"
        summary = json.dumps(
            {k: v for r in results for k, v in r.data.get("analysis", {}).items()
             if k in ("total_series", "total_matching_events", "highest_consumers", "anomalies",
                      "correlation_ids", "applications", "priorities")},
            default=str,
        )[:600]  # Keep short — this is a background call

        prompt = (
            f"Cluster: {cluster}. User asked: {question!r}. Tool used: {tool_name}.\n"
            f"Key findings summary: {summary}\n"
            "Suggest exactly 3 specific, actionable follow-up questions an SRE might ask next.\n"
            'Return ONLY valid JSON: {"suggestions":["question 1","question 2","question 3"]}'
        )

        try:
            content = await self._post_json(
                [
                    {"role": "system", "content": "Return only valid JSON."},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.3,
                max_tokens=160,
            )
            match = re.search(r"\{.*\}", content, re.DOTALL)
            if match:
                data = json.loads(match.group(0))
                suggestions = data.get("suggestions", [])
                return [str(s) for s in suggestions[:3]]
        except Exception as exc:
            logger.debug("suggest_followups failed: %s", exc)
        return _default_suggestions(results)

    # ------------------------------------------------------------------ #
    # Internal helpers                                                     #
    # ------------------------------------------------------------------ #

    async def _post_json(
        self,
        messages: list[dict],
        temperature: float = 0.1,
        max_tokens: int = 800,
    ) -> str:
        """POST to chat/completions with retry; returns message content string."""
        settings = get_settings()
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {settings.llm.api_key}",
        }
        payload = {
            "model": settings.llm.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        url = f"{settings.llm.api_url.rstrip('/')}/chat/completions"

        last_exc: Exception | None = None
        for attempt in range(_MAX_RETRIES + 1):
            try:
                async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
                    resp = await client.post(url, headers=headers, json=payload)
                    resp.raise_for_status()
                return resp.json()["choices"][0]["message"]["content"]
            except (httpx.HTTPError, KeyError, IndexError) as exc:
                last_exc = exc
                if attempt < _MAX_RETRIES:
                    await asyncio.sleep(_RETRY_BASE_DELAY * (2 ** attempt))
        raise last_exc  # type: ignore[misc]

    @staticmethod
    def _fmt_value(v: float, unit: str = "") -> str:
        if unit == "bytes":
            if v >= 1073741824: return f"{v / 1073741824:.1f} GiB"
            if v >= 1048576:    return f"{v / 1048576:.1f} MiB"
            if v >= 1024:       return f"{v / 1024:.1f} KiB"
            return f"{v:.0f} B"
        if v < 1: return f"{v:.4f}"
        if v >= 1000: return f"{v:.0f}"
        return f"{v:.3f}"

    @staticmethod
    def _fallback(results: list[ToolResult], prefix: str = "") -> str:
        if not results:
            return prefix + "I could not find a supported observability source for this question."
        result = results[0]
        if result.warning:
            return prefix + result.warning

        analysis = result.data.get("analysis", {})

        if result.tool == "jaeger":
            services = result.data.get("services")
            if services:
                svc_list = ", ".join(f"`{s}`" for s in services[:5])
                etc = f" and {len(services) - 5} more" if len(services) > 5 else ""
                return prefix + f"There are **{len(services)}** services emitting traces to Jaeger: {svc_list}{etc}."
            if "trace_id" in result.data:
                trace_id = result.data["trace_id"]
                trace_analysis = result.data.get("analysis", {})
                span_count = trace_analysis.get("span_count", 0)
                duration = trace_analysis.get("total_duration_ms", 0)
                err_count = trace_analysis.get("error_span_count", 0)
                return prefix + f"Jaeger Trace `{trace_id}` contains **{span_count}** spans across **{trace_analysis.get('service_count', 0)}** services. Total duration: {duration} ms. Error count: {err_count}."
            if "service" in result.data:
                svc = result.data["service"]
                total_traces = result.data.get("total_traces", 0)
                return prefix + f"Found **{total_traces}** recent traces for service `{svc}` in Jaeger."

        if result.tool == "elk":
            if analysis.get("transaction_flows"):
                flow = analysis["transaction_flows"][0]
                stages = "\n".join(
                    f"- **{s['trace_point']}**: {s['message']} ({s['elapsed_ms']} ms, {s['priority']})"
                    for s in flow["stages"]
                )
                return prefix + (
                    f"Transaction flow for `{flow['correlation_id']}` "
                    f"({flow['stage_count']} stages, {flow['total_elapsed_ms']} ms total):\n{stages}"
                )
            if analysis.get("correlation_ids"):
                ids = "\n".join(f"- `{cid}`" for cid in analysis["correlation_ids"])
                return prefix + f"Correlation IDs found:\n{ids}"

        if result.tool == "prometheus":
            total = analysis.get("total_series", 0)
            top = analysis.get("highest_consumers", [])
            unit = analysis.get("unit", "value")
            top_str = "\n".join(f"- `{s['service']}`: **{InternalLLMClient._fmt_value(s['value'], unit)}**" for s in top[:5])
            msg = f"Retrieved **{total}** metric series from Prometheus.\n\n### Top Consumers:\n{top_str}"
            anomalies = analysis.get("anomalies", [])
            if anomalies:
                anom_str = ", ".join(f"`{s['service']}`" for s in anomalies[:5])
                msg += f"\n\n⚠️ **Anomalies Detected** (usage > 2× mean): {anom_str}"
            return prefix + msg

        count = (
            result.data.get("total")
            or analysis.get("total_series")
            or analysis.get("total_matching_events")
            or len(result.data.get("result", result.data.get("trace", [])))
        )
        return prefix + f"Retrieved {count} item(s) from **{result.tool}**. Add Groq token to config/observability.yaml for AI analysis."


def _default_suggestions(results: list[ToolResult]) -> list[str]:
    if not results:
        return [
            "Show CPU usage for all services",
            "Show error logs in the last 30 minutes",
            "Show failed pods in all namespaces",
        ]
    tool = results[0].tool
    if tool == "prometheus":
        return [
            "Which service has the highest memory usage?",
            "Show error rate for all services",
            "Are there any failed pods?",
        ]
    if tool == "elk":
        return [
            "Show the transaction flow for this correlation ID",
            "What is the CPU usage for this service?",
            "Show error logs in the last hour",
        ]
    if tool == "jaeger":
        return [
            "Show CPU and memory for this service",
            "Show recent error logs for this service",
            "List all services in the cluster",
        ]
    return [
        "Show CPU usage for all services",
        "Show error logs in the last 30 minutes",
        "Show all namespaces",
    ]

"""ObservabilityAgent — orchestrates hybrid routing, parallel tool execution,
file-based session persistence, and SSE streaming.

Routing strategy (hybrid):
  1. IntentRouter scores the question deterministically.
  2. If confidence >= HIGH_CONFIDENCE_THRESHOLD → skip LLM planner (fast path).
  3. Otherwise → llm.plan() disambiguates with full context.
  4. Tool calls are parallelised with asyncio.gather.
  5. LLM streams the evidence-based answer via SSE.
  6. Follow-up suggestions are generated asynchronously after streaming.
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import AsyncIterator

from app.core.config import get_organization
from app.core.sessions import append_and_save, get_context
from app.models import ChatRequest, ChatResponse, ConversationTurn
from app.router import IntentRouter
from app.services.llm import InternalLLMClient
from app.tools import build_registry

logger = logging.getLogger(__name__)

_router = IntentRouter()


def _capabilities(organization) -> dict[str, str]:
    caps: dict[str, str] = {
        "prometheus": (
            "Namespaces, pods, HPA replicas and pressure, CPU usage, memory usage, "
            "HTTP request rate, 5xx error rate, failed pods, resource anomaly detection."
        ),
        "elk": (
            f"Read-only Mule application logs (field root: {organization.log_field_prefix}). "
            "IMPORTANT: In this Mule/ESB environment, the words 'transaction', 'transactions', "
            "'failed transactions', and 'Mule transactions' ALL refer to Mule application log events "
            "stored in Elasticsearch/ELK — they are NOT distributed traces. Use ELK for: "
            "log messages, errors, exceptions, correlation IDs, request IDs, transaction IDs, "
            "transaction flow reconstruction, failed transactions, slow-request detection, "
            "and time-range log search."
        ),
    }
    if organization.jaeger_url:
        caps["jaeger"] = (
            "Distributed traces and spans — use ONLY when the user explicitly mentions "
            "a trace ID, span ID, 'distributed tracing', 'Jaeger', 'service map', or 'service graph'. "
            "Do NOT use Jaeger for 'transactions', 'failed transactions', or general error lookups — "
            "those are ELK log events in this Mule environment."
        )
    return caps


class ObservabilityAgent:
    def __init__(self) -> None:
        self.llm = InternalLLMClient()

    # ------------------------------------------------------------------ #
    # Non-streaming (used by /api/chat)                                    #
    # ------------------------------------------------------------------ #

    async def answer(self, request: ChatRequest) -> ChatResponse:
        organization = get_organization(request.cluster)
        tools = build_registry(organization)
        context = get_context(request.session_id)

        # Hybrid routing
        route = _router.route(request.question)
        if _router.requires_llm(route):
            route = await self.llm.plan(
                request.question, organization.name, _capabilities(organization), context
            )

        append_and_save(request.session_id, request.cluster, "user", request.question)

        if route.reason in ("greeting", "conversation"):
            answer_text = await self.llm.summarize(request.question, [], context)
            sugg = await self.llm.suggest_followups(request.question, [], organization.name)
            append_and_save(request.session_id, request.cluster, "assistant", answer_text)
            return ChatResponse(
                answer=answer_text, route=route, results=[],
                suggestions=sugg, session_id=request.session_id,
            )

        if route.clarification:
            append_and_save(request.session_id, request.cluster, "assistant", route.clarification)
            return ChatResponse(
                answer=route.clarification, route=route, results=[],
                session_id=request.session_id,
            )

        # Parallel tool execution
        results = list(await asyncio.gather(
            *[tools.execute(t, request.question) for t in route.tools]
        ))
        answer_text = await self.llm.summarize(request.question, results, context)
        sugg = await self.llm.suggest_followups(request.question, results, organization.name)
        append_and_save(
            request.session_id, request.cluster, "assistant", answer_text,
            tool=route.tools[0] if route.tools else None,
        )
        return ChatResponse(
            answer=answer_text, route=route, results=results,
            suggestions=sugg, session_id=request.session_id,
        )

    # ------------------------------------------------------------------ #
    # SSE streaming (used by /api/chat/stream)                             #
    # ------------------------------------------------------------------ #

    async def answer_stream(self, request: ChatRequest) -> AsyncIterator[str]:
        """Yield SSE-formatted strings following the typed event protocol:

        event: metadata   — route decision + session_id
        event: thinking   — which tools are being called
        event: results    — raw tool data (sent before LLM starts)
        event: token      — one LLM output token
        event: suggestions — 3 follow-up questions
        event: done       — stream complete

        The client should accumulate tokens and render them progressively.
        """
        organization = get_organization(request.cluster)
        tools = build_registry(organization)
        context = get_context(request.session_id)

        # Routing
        route = _router.route(request.question)
        if _router.requires_llm(route):
            route = await self.llm.plan(
                request.question, organization.name, _capabilities(organization), context
            )

        append_and_save(request.session_id, request.cluster, "user", request.question)

        # Always emit metadata first so the client can render the route badge immediately
        yield _sse("metadata", {"route": route.model_dump(), "session_id": request.session_id})

        # ── Conversational / greeting ──────────────────────────────────
        if route.reason in ("greeting", "conversation"):
            full_answer = ""
            async for token in self.llm.converse_stream(request.question, organization.name, context):
                full_answer += token
                yield _sse("token", {"text": token})
            sugg = await self.llm.suggest_followups(request.question, [], organization.name)
            append_and_save(request.session_id, request.cluster, "assistant", full_answer)
            yield _sse("suggestions", {"suggestions": sugg})
            yield _sse("done", {})
            return

        # ── Clarification / unsupported ────────────────────────────────
        if route.clarification:
            yield _sse("token", {"text": route.clarification})
            append_and_save(request.session_id, request.cluster, "assistant", route.clarification)
            yield _sse("done", {})
            return

        # ── Tool execution ─────────────────────────────────────────────
        yield _sse("thinking", {"tools": route.tools})

        results = list(await asyncio.gather(
            *[tools.execute(t, request.question) for t in route.tools]
        ))

        # Emit tool results so the UI can render metric cards / flow panels
        # immediately, before the LLM summary begins streaming
        yield _sse("results", {"results": [r.model_dump(mode="json") for r in results]})

        # ── Stream LLM answer ──────────────────────────────────────────
        full_answer = ""
        async for token in self.llm.summarize_stream(request.question, results, context):
            full_answer += token
            yield _sse("token", {"text": token})

        # ── Follow-up suggestions (after streaming completes) ──────────
        sugg = await self.llm.suggest_followups(request.question, results, organization.name)
        append_and_save(
            request.session_id, request.cluster, "assistant", full_answer,
            tool=route.tools[0] if route.tools else None,
        )
        yield _sse("suggestions", {"suggestions": sugg})
        yield _sse("done", {})


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _sse(event: str, data: dict) -> str:
    """Format one SSE event per the spec (event + data lines, double newline)."""
    return f"event: {event}\ndata: {json.dumps(data, default=str)}\n\n"

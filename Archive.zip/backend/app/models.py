"""Shared Pydantic models for the Engineering Observability Copilot."""
from typing import Any, Literal
from pydantic import BaseModel, Field
import uuid

ToolName = Literal["elk", "prometheus", "jaeger", "kubernetes"]


class ConversationTurn(BaseModel):
    """One turn in a multi-turn conversation."""
    role: Literal["user", "assistant"]
    content: str
    tool: str | None = None


class ChatRequest(BaseModel):
    question: str = Field(default="", max_length=2000)
    cluster: str = Field(min_length=1, max_length=32)
    session_id: str = Field(default_factory=lambda: str(uuid.uuid4()), max_length=64)
    # Client may optionally pass recent history for context (last N turns).
    # The server also maintains its own file-based session and merges both.
    history: list[ConversationTurn] = Field(default_factory=list)


class RouteDecision(BaseModel):
    tools: list[ToolName]
    confidence: float
    reason: str
    clarification: str | None = None


class ToolResult(BaseModel):
    tool: ToolName
    data: dict[str, Any]
    source_url: str | None = None
    warning: str | None = None


class ChatResponse(BaseModel):
    answer: str
    route: RouteDecision
    results: list[ToolResult]
    suggestions: list[str] = Field(default_factory=list)
    session_id: str = ""


class ClusterInfo(BaseModel):
    """Metadata about a configured cluster, returned by /api/clusters."""
    name: str
    has_prometheus: bool
    has_jaeger: bool
    has_elasticsearch: bool

"""Local API-compatible observability test services.

Simulates Elasticsearch, Prometheus, and Jaeger with synthetic Mule data.
NOT a replacement for production monitoring systems.

Services:
  elasticsearch_app  → Elasticsearch _search API (port 9200)
  prometheus_app     → Prometheus query API (port 9090)
  jaeger_app         → Jaeger trace/services API (port 16686)
"""
from __future__ import annotations

import re
from copy import deepcopy
from datetime import UTC, datetime, timedelta

from fastapi import FastAPI, Request, HTTPException

# ---------------------------------------------------------------------------
# Shared synthetic data
# ---------------------------------------------------------------------------

NAMESPACES = [f"mule-uat-ns-{n:02d}" for n in range(1, 11)]
APPLICATIONS = [f"mule-app-{n:03d}-service" for n in range(1, 101)]
JAEGER_SERVICES = APPLICATIONS[:20]  # First 20 apps emit Jaeger traces

TRACE_STAGES = [
    ("RECEIVED_REQUEST", "Request received"),
    ("VALIDATED_REQUEST", "Request validated"),
    ("CALL_DOWNSTREAM", "Calling downstream service"),
    ("RECEIVED_RESPONSE", "Downstream response received"),
    ("COMPLETED_REQUEST", "Transaction completed"),
]


def _log_events() -> list[dict]:
    now = datetime.now(UTC)
    events = []
    for idx in range(300):
        app = APPLICATIONS[idx % len(APPLICATIONS)]
        is_error = idx % 11 == 0
        correlation_id = f"mule-correlation-{idx // 5:04d}"
        trace_point, message = TRACE_STAGES[idx % len(TRACE_STAGES)]
        timestamp = now - timedelta(minutes=idx // 5) + timedelta(seconds=idx % len(TRACE_STAGES))
        events.append({
            "@timestamp": timestamp.isoformat(),
            "kubernetes": {
                "namespace": NAMESPACES[idx % len(NAMESPACES)],
                "pod": {"name": f"{app}-{idx:04d}"},
                "labels": {"app": app, "type": "MuleApplication"},
            },
            "mule_logger": {
                "applicationName": app,
                "applicationVersion": "1.0.0",
                "environment": "uat",
                "priority": "ERROR" if is_error else "INFO",
                "message": "Downstream payment timeout" if is_error else message,
                "payload": "Synthetic local test event",
                "correlationId": correlation_id,
                "transactionId": f"transaction-{idx:04d}",
                "elapsed": 900 if is_error else 80 + (idx % 220),
                "tracePoint": trace_point,
                "category": "com.example.mule.logger",
                "locationInfo": {
                    "component": "api-flow",
                    "fileName": "main.xml",
                    "lineInFile": str(100 + idx % 50),
                },
                "timestamp": timestamp.isoformat(),
            },
        })
    return events


LOG_EVENTS = _log_events()


# ---------------------------------------------------------------------------
# Elasticsearch simulator
# ---------------------------------------------------------------------------

elasticsearch_app = FastAPI(title="Local Elasticsearch Test Service")


@elasticsearch_app.get("/")
async def es_root() -> dict:
    return {"name": "local-elasticsearch-test", "version": {"number": "8.0.0-test"}}


def get_nested_field(d: dict, field_path: str):
    parts = field_path.split(".")
    curr = d
    for part in parts:
        if isinstance(curr, dict) and part in curr:
            curr = curr[part]
        else:
            return None
    return curr


@elasticsearch_app.post("/{index_name:path}/_search")
async def es_search(index_name: str, request: Request) -> dict:
    auth_header = request.headers.get("authorization")
    if not auth_header or auth_header != "Basic YWRtaW46bXVsZWVsa2xvY2Fs":
        raise HTTPException(
            status_code=401,
            detail="Unauthorized. Invalid or missing Elasticsearch Basic Auth token.",
        )
    payload = await request.json()
    must = payload.get("query", {}).get("bool", {}).get("must", [])
    events = list(LOG_EVENTS)

    # Apply filters from the must clauses
    for clause in must:
        if "match_phrase" in clause:
            field = next(iter(clause["match_phrase"].keys()))
            value = next(iter(clause["match_phrase"].values()))
            events = [e for e in events if str(get_nested_field(e, field)).lower() == str(value).lower()]
        elif "match" in clause:
            field = next(iter(clause["match"].keys()))
            value = next(iter(clause["match"].values()))
            events = [e for e in events if str(get_nested_field(e, field)).lower() == str(value).lower()]
        elif "query_string" in clause:
            q = clause["query_string"].get("query", "").lower()
            if "error" in q or "exception" in q:
                events = [e for e in events if e["mule_logger"]["priority"] == "ERROR"]
        elif "range" in clause:
            # Time-range filter support
            for field, bounds in clause["range"].items():
                if field == "@timestamp":
                    gte = bounds.get("gte")
                    lte = bounds.get("lte")
                    if gte:
                        try:
                            gte_dt = datetime.fromisoformat(gte.replace("Z", "+00:00"))
                            events = [
                                e for e in events
                                if datetime.fromisoformat(e["@timestamp"].replace("Z", "+00:00")) >= gte_dt
                            ]
                        except ValueError:
                            pass
                elif field == "mule_logger.elapsed":
                    gte_ms = bounds.get("gte", 0)
                    events = [e for e in events if (e["mule_logger"].get("elapsed") or 0) >= gte_ms]

    size = min(int(payload.get("size", 50)), 100)
    environment = "prod" if "prod" in index_name.lower() else "uat"

    hits = []
    for number, event in enumerate(events[:size]):
        source = deepcopy(event)
        source["mule_logger"]["environment"] = environment
        source["kubernetes"]["namespace"] = source["kubernetes"]["namespace"].replace("uat", environment)
        hits.append({"_index": index_name.replace("*", "001"), "_id": str(number), "_source": source})

    return {"hits": {"total": {"value": len(events)}, "hits": hits}}


# ---------------------------------------------------------------------------
# Prometheus simulator
# ---------------------------------------------------------------------------

prometheus_app = FastAPI(title="Local Prometheus Test Service")


def _metric(value: float | int, namespace: str, service: str, **labels: str) -> dict:
    return {
        "metric": {"namespace": namespace, "service": service, **labels},
        "value": [datetime.now(UTC).timestamp(), str(value)],
    }


def _metrics(metric_name: str, selected_namespace: str = "", service_pattern: str = ".*") -> list[dict]:
    values: list[dict] = []
    if metric_name == "namespace":
        return [_metric(100, ns, "namespace-inventory") for ns in NAMESPACES]
    for ns_idx, ns in enumerate(NAMESPACES, start=1):
        if selected_namespace and ns != selected_namespace:
            continue
        for app_idx, app in enumerate(APPLICATIONS, start=1):
            service = f"{app}-{ns_idx:02d}"
            if service_pattern != ".*" and not re.fullmatch(service_pattern, service):
                continue
            seed = ns_idx * 100 + app_idx
            if metric_name == "pods":
                values.append(_metric(1, ns, service, pod=service))
            elif metric_name == "cpu":
                values.append(_metric(round(0.05 + (seed % 85) / 100, 3), ns, service))
            elif metric_name == "memory":
                values.append(_metric((180 + seed % 760) * 1024 * 1024, ns, service))
            elif metric_name == "hpa":
                values.append(_metric(
                    1 + seed % 8, ns, service,
                    horizontalpodautoscaler=f"{service}-hpa",
                    min_replicas="1", max_replicas="10",
                ))
            elif metric_name == "failed":
                values.append(_metric(1 if seed % 23 == 0 else 0, ns, service, phase="Failed"))
            else:  # requests / error rate
                values.append(_metric(
                    20 + seed % 400, ns, service,
                    status="500" if seed % 17 == 0 else "200",
                ))
    return values


@prometheus_app.get("/-/ready")
async def prometheus_ready() -> dict:
    return {"status": "ready"}


@prometheus_app.get("/api/v1/query")
async def prometheus_query(query: str) -> dict:
    q = query.lower()
    metric_name = "requests"
    ns_m = re.search(r'namespace="([^"]+)"', query)
    svc_m = re.search(r'service=~"([^"]+)"', query)
    selected_ns = ns_m.group(1) if ns_m else ""
    service_pattern = svc_m.group(1) if svc_m else ".*"

    if "cpu" in q:
        metric_name = "cpu"
    elif "count by (namespace)" in q:
        metric_name = "namespace"
    elif "kube_pod_info" in q:
        metric_name = "pods"
    elif "memory" in q:
        metric_name = "memory"
    elif "horizontalpodautoscaler" in q:
        metric_name = "hpa"
    elif "pod_status_phase" in q:
        metric_name = "failed"

    result = _metrics(metric_name, selected_ns, service_pattern)
    return {"status": "success", "data": {"resultType": "vector", "result": result}}


@prometheus_app.get("/api/v1/rules")
async def prometheus_rules() -> dict:
    """Stub alerting rules endpoint."""
    return {
        "status": "success",
        "data": {
            "groups": [
                {
                    "name": "mule-uat.alerts",
                    "rules": [
                        {
                            "type": "alerting",
                            "name": "HighCPUUsage",
                            "query": 'sum by (service) (rate(container_cpu_usage_seconds_total[5m])) > 0.8',
                            "labels": {"severity": "warning"},
                            "annotations": {"summary": "CPU usage above 80%"},
                            "health": "ok",
                        },
                        {
                            "type": "alerting",
                            "name": "HighMemoryUsage",
                            "query": "container_memory_working_set_bytes > 1073741824",
                            "labels": {"severity": "critical"},
                            "annotations": {"summary": "Memory above 1 GiB"},
                            "health": "ok",
                        },
                    ],
                }
            ]
        },
    }


# ---------------------------------------------------------------------------
# Jaeger simulator
# ---------------------------------------------------------------------------

jaeger_app = FastAPI(title="Local Jaeger Test Service")


def _make_trace(service: str, seed: int) -> dict:
    now_us = int(datetime.now(UTC).timestamp() * 1_000_000)
    trace_id = f"{abs(hash(f'{service}{seed}')) % (16 ** 16):016x}"
    is_error = seed % 7 == 0
    operations = [
        ("HTTP GET /api/v1/process", 45_000),
        ("DB SELECT payments", 12_000),
        ("Cache GET session", 3_500),
        ("HTTP POST downstream", 28_000 if is_error else 8_000),
    ]
    spans = []
    for i, (op, duration) in enumerate(operations):
        status = 500 if is_error and i == len(operations) - 1 else 200
        spans.append({
            "traceID": trace_id,
            "spanID": f"{abs(hash(f'{trace_id}{i}')):016x}",
            "operationName": op,
            "references": [{"refType": "CHILD_OF", "spanID": spans[i - 1]["spanID"]}] if i > 0 else [],
            "startTime": now_us - (len(operations) - i) * 5_000,
            "duration": duration + (seed % 5000),
            "tags": [
                {"key": "http.status_code", "type": "int64", "value": status},
                {"key": "error", "type": "bool", "value": status >= 500},
                {"key": "span.kind", "type": "string", "value": "client" if i > 0 else "server"},
            ],
            "logs": [],
            "processID": "p1",
            "warnings": None,
        })
    return {
        "traceID": trace_id,
        "spans": spans,
        "processes": {
            "p1": {
                "serviceName": service,
                "tags": [
                    {"key": "hostname", "type": "string", "value": f"{service}-pod-{seed:04d}"},
                    {"key": "jaeger.version", "type": "string", "value": "Go-2.30.0"},
                ],
            }
        },
        "warnings": None,
    }


@jaeger_app.get("/api/services")
async def jaeger_services() -> dict:
    return {"data": JAEGER_SERVICES, "total": len(JAEGER_SERVICES), "limit": 0, "offset": 0, "errors": None}


@jaeger_app.get("/api/services/{service}/operations")
async def jaeger_operations(service: str) -> dict:
    ops = [
        "GET /api/v1/payments",
        "POST /api/v1/orders",
        "PUT /api/v1/accounts",
        "DELETE /api/v1/sessions",
        "GET /health",
    ]
    return {"data": ops, "errors": None}


@jaeger_app.get("/api/traces")
async def jaeger_traces(service: str = "", limit: int = 20) -> dict:
    svc = service if service in JAEGER_SERVICES else JAEGER_SERVICES[0]
    traces = [_make_trace(svc, i) for i in range(min(limit, 20))]
    return {"data": traces, "total": len(traces), "limit": limit, "offset": 0, "errors": None}


@jaeger_app.get("/api/traces/{trace_id}")
async def jaeger_trace(trace_id: str) -> dict:
    seed = int(trace_id[:4], 16) % len(JAEGER_SERVICES)
    service = JAEGER_SERVICES[seed]
    trace = _make_trace(service, seed)
    trace["traceID"] = trace_id
    for span in trace["spans"]:
        span["traceID"] = trace_id
    return {"data": [trace], "total": 1, "limit": 1, "offset": 0, "errors": None}

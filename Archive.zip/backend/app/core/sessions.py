"""File-based conversation session store.

Sessions are persisted to  runtime/sessions/<session_id>.json  so they survive
backend restarts.  Before deleting or restarting a pod/process, back up the
runtime/sessions/ folder.  On restore, place the folder back and sessions will
be loaded automatically on the next request.

Session files are plain JSON — never store secrets or PII in messages.
"""
import json
import logging
import re
from datetime import UTC, datetime
from pathlib import Path

from app.models import ConversationTurn

logger = logging.getLogger(__name__)

# Stored alongside other runtime artefacts so one backup covers everything.
SESSIONS_DIR = Path(__file__).resolve().parents[3] / "runtime" / "sessions"

# Keep at most this many turns on disk; older turns are trimmed automatically.
MAX_TURNS_PER_SESSION = 100

# How many recent turns to include in each LLM prompt for context.
CONTEXT_WINDOW = 6

_SAFE_CHARS = re.compile(r"[^a-zA-Z0-9\-_]")


def _path(session_id: str) -> Path:
    """Return the file path for a session, sanitised to prevent path traversal."""
    safe = _SAFE_CHARS.sub("", session_id)[:64] or "default"
    return SESSIONS_DIR / f"{safe}.json"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def load_session(session_id: str) -> list[ConversationTurn]:
    """Return all stored turns for *session_id*, or [] if not found."""
    p = _path(session_id)
    if not p.exists():
        return []
    try:
        raw = json.loads(p.read_text(encoding="utf-8"))
        return [ConversationTurn(**t) for t in raw.get("turns", [])]
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not load session %s: %s", session_id, exc)
        return []


def save_session(session_id: str, cluster: str, turns: list[ConversationTurn]) -> None:
    """Persist *turns* to disk, trimming to MAX_TURNS_PER_SESSION."""
    SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
    trimmed = turns[-MAX_TURNS_PER_SESSION:]
    p = _path(session_id)
    try:
        p.write_text(
            json.dumps(
                {
                    "session_id": session_id,
                    "cluster": cluster,
                    "turns": [t.model_dump() for t in trimmed],
                    "updated_at": datetime.now(UTC).isoformat(),
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not save session %s: %s", session_id, exc)


def get_context(session_id: str) -> list[ConversationTurn]:
    """Return the last CONTEXT_WINDOW turns for use as LLM conversation history."""
    return load_session(session_id)[-CONTEXT_WINDOW:]


def append_and_save(session_id: str, cluster: str, role: str, content: str, tool: str | None = None) -> None:
    """Load, append one turn, and save atomically."""
    turns = load_session(session_id)
    turns.append(ConversationTurn(role=role, content=content, tool=tool))  # type: ignore[arg-type]
    save_session(session_id, cluster, turns)

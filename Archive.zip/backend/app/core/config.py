from functools import lru_cache
from pathlib import Path

import yaml
from pydantic import BaseModel, Field

from app.models import ClusterInfo


class BackendConfig(BaseModel):
    host: str = "0.0.0.0"
    port: int = 8000
    log_level: str = "INFO"
    cors_origins: list[str] = Field(default_factory=lambda: ["http://localhost:5173"])
    request_timeout_seconds: float = 15
    max_result_items: int = 50


class FrontendConfig(BaseModel):
    port: int = 5173


class LocalTestServicesConfig(BaseModel):
    elasticsearch_port: int = 9200
    prometheus_port: int = 9090
    jaeger_port: int = 16686


class LLMConfig(BaseModel):
    api_url: str = "https://api.groq.com/openai/v1"
    api_key: str = ""
    model: str = "llama-3.3-70b-versatile"
    temperature: float = 0.1
    max_tokens: int = 1200


class OrganizationConfig(BaseModel):
    name: str
    prometheus_url: str = ""
    jaeger_url: str = ""
    elasticsearch_url: str = ""
    elasticsearch_index: str = ""
    elasticsearch_username: str = ""
    elasticsearch_password: str = ""
    elasticsearch_token: str = ""
    log_field_prefix: str = "mule_logger"
    enabled: bool = True

    @property
    def elasticsearch_auth(self) -> tuple[str, str] | None:
        if self.elasticsearch_username and self.elasticsearch_password:
            return (self.elasticsearch_username, self.elasticsearch_password)
        if self.elasticsearch_token:
            import base64
            try:
                # Decodes base64 string to "username:password"
                decoded = base64.b64decode(self.elasticsearch_token.strip()).decode("utf-8")
                if ":" in decoded:
                    u, p = decoded.split(":", 1)
                    return (u, p)
            except Exception:
                pass
        return None

    def to_cluster_info(self) -> ClusterInfo:
        return ClusterInfo(
            name=self.name,
            has_prometheus=bool(self.prometheus_url),
            has_jaeger=bool(self.jaeger_url),
            has_elasticsearch=bool(self.elasticsearch_url),
        )


class Settings(BaseModel):
    backend: BackendConfig = Field(default_factory=BackendConfig)
    frontend: FrontendConfig = Field(default_factory=FrontendConfig)
    local_test_services: LocalTestServicesConfig = Field(default_factory=LocalTestServicesConfig)
    llm: LLMConfig = Field(default_factory=LLMConfig)
    organizations: dict[str, OrganizationConfig] = Field(default_factory=dict)

    @property
    def log_level(self) -> str:
        return self.backend.log_level

    @property
    def cors_origin_list(self) -> list[str]:
        return self.backend.cors_origins

    @property
    def request_timeout_seconds(self) -> float:
        return self.backend.request_timeout_seconds

    @property
    def max_result_items(self) -> int:
        return self.backend.max_result_items


@lru_cache
def get_settings() -> Settings:
    config_path = Path(__file__).resolve().parents[3] / "config" / "observability.yaml"
    with config_path.open(encoding="utf-8") as f:
        settings = Settings.model_validate(yaml.safe_load(f) or {})
    names = [o.name for o in settings.organizations.values()]
    if len(names) != len(set(names)):
        raise ValueError("Each organization configuration must have a unique name.")
    return settings


def get_organizations() -> dict[str, OrganizationConfig]:
    return get_settings().organizations


def get_organization(selected_name: str) -> OrganizationConfig:
    for org in get_organizations().values():
        if org.name == selected_name:
            return org
    raise ValueError(f"Unsupported cluster: {selected_name!r}. Valid clusters: {[o.name for o in get_organizations().values()]}")


def get_cluster_info_list() -> list[ClusterInfo]:
    """Return metadata for all enabled clusters — used by /api/clusters."""
    return [org.to_cluster_info() for org in get_organizations().values() if org.enabled]

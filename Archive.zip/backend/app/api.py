"""FastAPI routes for the Engineering Observability Copilot.

Endpoints:
  GET  /api/health          — liveness + cluster config summary
  GET  /api/clusters        — list configured cluster names and capabilities
  POST /api/chat            — non-streaming chat (returns full ChatResponse)
  POST /api/chat/stream     — SSE streaming chat (typed event protocol)
"""
from __future__ import annotations

import json
import logging

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import StreamingResponse

from app.core.config import get_cluster_info_list, get_settings
from app.models import ChatRequest, ChatResponse, ClusterInfo
from app.services.agent import ObservabilityAgent

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api")
agent = ObservabilityAgent()


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@router.get("/health")
async def health() -> dict:
    settings = get_settings()
    clusters = get_cluster_info_list()
    return {
        "status": "ok",
        "clusters": len(clusters),
        "llm_configured": bool(settings.llm.api_url and settings.llm.api_key),
        "model": settings.llm.model,
    }


# ---------------------------------------------------------------------------
# Cluster registry
# ---------------------------------------------------------------------------

@router.get("/clusters", response_model=list[ClusterInfo])
async def clusters() -> list[ClusterInfo]:
    """Return metadata for all enabled clusters so the UI doesn't hardcode names."""
    return get_cluster_info_list()


# ---------------------------------------------------------------------------
# Non-streaming chat
# ---------------------------------------------------------------------------

@router.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest) -> ChatResponse:
    try:
        return await agent.answer(request)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception("Unhandled error in /api/chat")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


# ---------------------------------------------------------------------------
# SSE streaming chat
# ---------------------------------------------------------------------------

@router.post("/chat/stream")
async def chat_stream(request: ChatRequest) -> StreamingResponse:
    """Server-Sent Events endpoint for streaming chat responses.

    Event protocol (in order):
      event: metadata    — {route: RouteDecision, session_id: str}
      event: thinking    — {tools: list[str]}           (only when tools are called)
      event: results     — {results: list[ToolResult]}  (raw tool data, before LLM)
      event: token       — {text: str}                  (one LLM output token)
      event: suggestions — {suggestions: list[str]}     (3 follow-up questions)
      event: done        — {}

    Clients should accumulate token events and render progressively.
    On connection error, re-connect using the last known session_id.
    """
    try:
        return StreamingResponse(
            agent.answer_stream(request),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",   # disable nginx buffering
                "Connection": "keep-alive",
            },
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

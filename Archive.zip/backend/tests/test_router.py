from app.router import IntentRouter


def test_correlation_id_defaults_to_elk() -> None:
    decision = IntentRouter().route("analyze logs for correlation id abc-123")
    assert decision.tools == ["elk"]


def test_explicit_trace_wins_for_correlation_id() -> None:
    decision = IntentRouter().route("show trace for correlation id abcdef1234")
    assert decision.tools == ["jaeger"]


def test_namespaces_are_returned_from_prometheus_metrics() -> None:
    decision = IntentRouter().route("show all namespaces")
    assert decision.tools == ["prometheus"]


def test_pods_are_returned_from_prometheus_metrics() -> None:
    decision = IntentRouter().route("show pods under mule-uat-ns-01")
    assert decision.tools == ["prometheus"]


def test_cpu_goes_to_prometheus() -> None:
    decision = IntentRouter().route("what is CPU usage of api-gateway")
    assert decision.tools == ["prometheus"]


def test_greeting_is_handled_as_chat_not_unsupported_intent() -> None:
    decision = IntentRouter().route("Hi bro")
    assert decision.reason == "greeting"
    assert decision.clarification == "greeting"


def test_general_chat_is_sent_to_ai_conversation() -> None:
    # 'what can you' now matched by the extended greeting pattern; the agent
    # will handle it as a warm conversational reply — same UX outcome.
    decision = IntentRouter().route("what can you help me with")
    assert decision.reason in ("greeting", "conversation")


def test_empty_chat_is_sent_to_ai_conversation() -> None:
    # Empty input is treated as a greeting/conversation — same handling path.
    decision = IntentRouter().route("")
    assert decision.reason in ("greeting", "conversation")


# ── Transaction routing tests (regression guard) ─────────────────────────────

def test_failed_transactions_routes_to_elk_not_jaeger() -> None:
    """'failed transactions' = Mule log events in ELK, NOT Jaeger distributed traces."""
    decision = IntentRouter().route("show me failed transactions 10")
    assert decision.tools == ["elk"], f"Expected elk, got {decision.tools} (reason: {decision.reason})"
    assert decision.confidence >= 0.90


def test_transactions_routes_to_elk() -> None:
    decision = IntentRouter().route("show last 10 transactions")
    assert decision.tools == ["elk"]


def test_failed_transaction_singular_routes_to_elk() -> None:
    decision = IntentRouter().route("why did this transaction fail")
    assert decision.tools == ["elk"]


def test_mule_transaction_routes_to_elk() -> None:
    decision = IntentRouter().route("show mule transaction logs")
    assert decision.tools == ["elk"]


def test_trace_still_goes_to_jaeger() -> None:
    """Explicit 'trace' or 'span' language should still route to Jaeger."""
    decision = IntentRouter().route("show trace abc123def456")
    assert decision.tools == ["jaeger"]


def test_distributed_tracing_goes_to_jaeger() -> None:
    decision = IntentRouter().route("show distributed tracing for payment-service")
    assert decision.tools == ["jaeger"]


def test_list_services_routing() -> None:
    decision = IntentRouter().route("List all services in the cluster")
    assert decision.tools == ["jaeger"]
    assert decision.confidence >= 0.90


def test_list_apps_routing() -> None:
    decision = IntentRouter().route("show all apps in cluster")
    assert decision.tools == ["jaeger"]


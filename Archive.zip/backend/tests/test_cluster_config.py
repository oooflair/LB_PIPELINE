import pytest
from app.core.config import get_organization, get_organizations


def test_all_ui_clusters_have_one_exact_configuration() -> None:
    for name in ("MULE-UAT", "MULE-PROD", "JAVA-UAT", "JAVA-PROD"):
        assert get_organization(name).name == name
    assert len(get_organizations()) == 4


def test_backend_and_frontend_settings_are_loaded() -> None:
    from app.core.config import get_settings
    settings = get_settings()
    assert settings.backend.port == 8000
    assert settings.frontend.port == 5173


def test_unknown_cluster_is_rejected_without_fallback() -> None:
    with pytest.raises(ValueError, match="Unsupported cluster"):
        get_organization("UNKNOWN")

from app.services.llm import InternalLLMClient


CAPABILITIES = {"prometheus": "metrics", "elk": "logs"}


def test_llm_plan_allows_only_registered_tool() -> None:
    decision = InternalLLMClient._parse_plan('{"tool":"prometheus","reason":"CPU is a metric"}', CAPABILITIES)
    assert decision.tools == ["prometheus"]
    assert decision.clarification is None


def test_llm_plan_returns_unavailable_for_unknown_tool() -> None:
    decision = InternalLLMClient._parse_plan('{"tool":"kubernetes","reason":"pods"}', CAPABILITIES)
    assert decision.tools == []
    assert decision.reason == "unavailable"

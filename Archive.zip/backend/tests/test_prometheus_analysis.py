from app.tools.prometheus import PrometheusTool


def test_all_prometheus_series_are_aggregated_without_first_n_truncation() -> None:
    result = [
        {"metric": {"namespace": "ns-a", "service": "service-a"}, "value": [0, "10"]},
        {"metric": {"namespace": "ns-b", "service": "service-b"}, "value": [0, "30"]},
        {"metric": {"namespace": "ns-b", "service": "service-c"}, "value": [0, "20"]},
    ]
    analysis = PrometheusTool._analyze_all_series(result, "show memory")
    assert analysis["total_series"] == 3
    assert analysis["namespace_count"] == 2
    assert analysis["sum"] == 60
    assert analysis["average"] == 20
    assert analysis["highest_consumers"][0]["service"] == "service-b"

from fastapi.testclient import TestClient
from app.mock_observability import elasticsearch_app, prometheus_app


def test_prometheus_has_metrics_for_ten_namespaces_and_one_hundred_apps_each() -> None:
    response = TestClient(prometheus_app).get("/api/v1/query", params={"query": "container_cpu_usage_seconds_total"})
    result = response.json()["data"]["result"]
    assert len(result) == 1000
    assert len({item["metric"]["namespace"] for item in result}) == 10
    assert len({item["metric"]["service"] for item in result}) == 1000


def test_prometheus_namespace_inventory_returns_ten_namespaces() -> None:
    response = TestClient(prometheus_app).get("/api/v1/query", params={"query": "count by (namespace) (kube_pod_info)"})
    result = response.json()["data"]["result"]
    assert len(result) == 10


def test_prometheus_pod_inventory_can_filter_by_namespace() -> None:
    response = TestClient(prometheus_app).get("/api/v1/query", params={"query": 'kube_pod_info{namespace="mule-uat-ns-01"}'})
    result = response.json()["data"]["result"]
    assert len(result) == 100
    assert {item["metric"]["namespace"] for item in result} == {"mule-uat-ns-01"}


def test_prometheus_metrics_can_filter_by_full_service_name() -> None:
    response = TestClient(prometheus_app).get(
        "/api/v1/query",
        params={"query": 'sum by (service) (rate(container_cpu_usage_seconds_total{service=~"mule-app-079-service-01"}[5m]))'},
    )
    result = response.json()["data"]["result"]
    assert len(result) == 1
    assert {item["metric"]["service"] for item in result} == {"mule-app-079-service-01"}


def test_elasticsearch_uses_mule_logger_correlation_id() -> None:
    response = TestClient(elasticsearch_app).post(
        "/elk-mulesoftrtf-uat-*/_search",
        json={"size": 10, "query": {"bool": {"must": [{"match_phrase": {"mule_logger.correlationId": "mule-correlation-0000"}}]}}},
        headers={"Authorization": "Basic YWRtaW46bXVsZWVsa2xvY2Fs"}
    )
    event = response.json()["hits"]["hits"][0]["_source"]
    assert event["mule_logger"]["correlationId"] == "mule-correlation-0000"


def test_elasticsearch_fails_with_invalid_token() -> None:
    response = TestClient(elasticsearch_app).post(
        "/elk-mulesoftrtf-uat-*/_search",
        json={"size": 10, "query": {"bool": {"must": [{"match_phrase": {"mule_logger.correlationId": "mule-correlation-0000"}}]}}},
        headers={"Authorization": "Basic d3Jvbmc6dG9rZW4="} # wrong token
    )
    assert response.status_code == 401


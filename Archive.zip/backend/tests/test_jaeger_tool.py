from app.tools.jaeger import JaegerTool


def test_jaeger_service_list_query_detection() -> None:
    assert JaegerTool._is_service_list_query("how many apps present jaeger") is True
    assert JaegerTool._is_service_list_query("list services present in jaeger") is True
    assert JaegerTool._is_service_list_query("show all apps in jaeger") is True
    assert JaegerTool._is_service_list_query("get services list") is True
    assert JaegerTool._is_service_list_query("show trace 12345") is False


def test_jaeger_extract_service_ignores_generic_terms() -> None:
    assert JaegerTool._extract_service("show traces for apps") is None
    assert JaegerTool._extract_service("get services list") is None
    assert JaegerTool._extract_service("show traces for payment-service") == "payment-service"

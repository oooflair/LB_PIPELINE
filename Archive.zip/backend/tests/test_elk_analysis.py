from app.tools.elk import ElkTool
from app.core.config import OrganizationConfig
import pytest


def test_elk_analysis_returns_ten_distinct_correlation_ids() -> None:
    events = [
        {"mule_logger": {"correlationId": f"correlation-{number}", "applicationName": "app-a", "priority": "INFO"}}
        for number in range(12)
    ]
    analysis = ElkTool._analyze_events(events, "mule_logger", total=12)
    assert analysis["total_matching_events"] == 12
    assert len(analysis["correlation_ids"]) == 10
    assert analysis["correlation_ids"][0] == "correlation-0"


def test_elk_analysis_reconstructs_ordered_transaction_flow() -> None:
    events = [
        {"mule_logger": {"correlationId": "flow-1", "applicationName": "app-a", "priority": "INFO", "tracePoint": "COMPLETE", "message": "done", "elapsed": 20, "timestamp": "2026-01-01T00:00:02Z"}},
        {"mule_logger": {"correlationId": "flow-1", "applicationName": "app-a", "priority": "INFO", "tracePoint": "START", "message": "started", "elapsed": 10, "timestamp": "2026-01-01T00:00:01Z"}},
    ]
    flow = ElkTool._analyze_events(events, "mule_logger", total=2)["transaction_flows"][0]
    assert flow["total_elapsed_ms"] == 30
    assert [stage["trace_point"] for stage in flow["stages"]] == ["START", "COMPLETE"]
    assert flow["stages"][0]["from_application"] == "Client"
    assert flow["stages"][1]["from_application"] == "app-a"


def test_elk_severity_extraction() -> None:
    assert ElkTool._extract_severity("show failed transactions") == "ERROR"
    assert ElkTool._extract_severity("show error logs") == "ERROR"
    assert ElkTool._extract_severity("fatal exception in gateway") == "FATAL"
    assert ElkTool._extract_severity("warn log for service") == "WARN"
    assert ElkTool._extract_severity("normal log info") is None


def test_elk_time_range_parsing() -> None:
    res = ElkTool._parse_time_range("show logs last 30 minutes")
    assert res is not None
    gte, lte = res
    assert gte < lte

    res_day = ElkTool._parse_time_range("show logs today")
    assert res_day is not None

    res_none = ElkTool._parse_time_range("show logs")
    assert res_none is None


def test_elk_correlation_id_extraction() -> None:
    # 1. Standard pattern
    assert ElkTool._extract_correlation_id("show logs for correlation id my-id-123") == "my-id-123"
    assert ElkTool._extract_correlation_id("request id: abc.def") == "abc.def"

    # 2. Bare known patterns (mule-correlation-* or correlation-*)
    assert ElkTool._extract_correlation_id("mule-correlation-0000 why did this transaction fail") == "mule-correlation-0000"
    assert ElkTool._extract_correlation_id("what happened in correlation-abc-123-xyz") == "correlation-abc-123-xyz"

    # 3. UUID pattern
    assert ElkTool._extract_correlation_id("check logs for 9b1deb4d-3b7d-4bad-9bdd-2b0d7b3dcb6d") == "9b1deb4d-3b7d-4bad-9bdd-2b0d7b3dcb6d"

    # 4. No correlation ID
    assert ElkTool._extract_correlation_id("show failed transactions") is None



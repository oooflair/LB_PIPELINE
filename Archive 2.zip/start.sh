#!/usr/bin/env bash
# Starts the full local development stack without Docker.
# Reads all ports from config/observability.yaml.
#
# Services started:
#   - Local Elasticsearch test service  (default: 9200)
#   - Local Prometheus test service     (default: 9090)
#   - Local Jaeger test service         (default: 16686)
#   - FastAPI backend                   (default: 8000)
#   - Vite frontend dev server          (default: 5173)
#
# Session history is persisted in runtime/sessions/.
# Back up this folder before restarting to preserve conversation history.
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$ROOT_DIR/backend"
FRONTEND_DIR="$ROOT_DIR/frontend"
RUNTIME_DIR="$ROOT_DIR/runtime"
CONFIG_FILE="$ROOT_DIR/config/observability.yaml"

API_PORT=""
UI_PORT=""
ELK_PORT=""
PROMETHEUS_PORT=""
JAEGER_PORT=""

PYTHON_BIN="$BACKEND_DIR/.venv/bin/python"
NODE_BIN="${NODE_BIN:-${HOME}/.local/node/bin/node}"
NPM_BIN="$(dirname "$NODE_BIN")/npm"

BACKEND_PID=""
FRONTEND_PID=""
ELK_PID=""
PROMETHEUS_PID=""
JAEGER_PID=""

mkdir -p "$RUNTIME_DIR"
mkdir -p "$RUNTIME_DIR/sessions"

# ─── helpers ────────────────────────────────────────────────────────────────

fail() { printf '\nERROR: %s\n' "$1" >&2; exit 1; }

cleanup_on_failure() {
  local status=$?
  if [[ "$status" -ne 0 ]]; then
    [[ -n "$BACKEND_PID"    ]] && kill "$BACKEND_PID"    2>/dev/null || true
    [[ -n "$FRONTEND_PID"   ]] && kill "$FRONTEND_PID"   2>/dev/null || true
    [[ -n "$ELK_PID"        ]] && kill "$ELK_PID"        2>/dev/null || true
    [[ -n "$PROMETHEUS_PID" ]] && kill "$PROMETHEUS_PID" 2>/dev/null || true
    [[ -n "$JAEGER_PID"     ]] && kill "$JAEGER_PID"     2>/dev/null || true
  fi
}
trap cleanup_on_failure EXIT

stop_port() {
  local port="$1" pids
  pids="$(lsof -tiTCP:"$port" -sTCP:LISTEN 2>/dev/null || true)"
  [[ -z "$pids" ]] && return
  printf 'Stopping existing service(s) on port %s: %s\n' "$port" "$pids"
  kill $pids 2>/dev/null || true
  for _ in {1..20}; do
    sleep 0.2
    [[ -z "$(lsof -tiTCP:"$port" -sTCP:LISTEN 2>/dev/null || true)" ]] && return
  done
  pids="$(lsof -tiTCP:"$port" -sTCP:LISTEN 2>/dev/null || true)"
  [[ -z "$pids" ]] || kill -9 $pids 2>/dev/null || true
}

yaml_val() {
  "$PYTHON_BIN" -c "import sys, yaml; d=yaml.safe_load(open(sys.argv[1])); print($2)" "$CONFIG_FILE"
}

# ─── pre-flight checks ────────────────────────────────────────────────────────

command -v lsof >/dev/null || fail "lsof is required to identify services using ports."
[[ -x "$PYTHON_BIN" ]] || fail "Python environment missing. Expected: $PYTHON_BIN. Run: cd backend && python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt"
[[ -x "$NODE_BIN"   ]] || fail "Node.js missing. Expected: $NODE_BIN (or set NODE_BIN env var)."
[[ -x "$NPM_BIN"    ]] || fail "npm missing beside Node.js: $NPM_BIN"
[[ -f "$CONFIG_FILE" ]] || fail "Configuration missing: $CONFIG_FILE"
[[ -d "$FRONTEND_DIR/node_modules" ]] || fail "Frontend dependencies missing. Run: cd \"$FRONTEND_DIR\" && \"$NPM_BIN\" install"
"$PYTHON_BIN" -c "import fastapi, httpx, mcp, uvicorn, yaml" || fail "Backend Python dependencies are missing. Run: cd backend && pip install -r requirements.txt"

# ─── read ports from config ───────────────────────────────────────────────────

API_PORT="$(yaml_val . 'd["backend"]["port"]')"         || fail "Could not read backend.port"
UI_PORT="$(yaml_val .  'd["frontend"]["port"]')"        || fail "Could not read frontend.port"
ELK_PORT="$(yaml_val . 'd["local_test_services"]["elasticsearch_port"]')" || fail "Could not read elasticsearch_port"
PROMETHEUS_PORT="$(yaml_val . 'd["local_test_services"]["prometheus_port"]')" || fail "Could not read prometheus_port"
JAEGER_PORT="$(yaml_val .    'd["local_test_services"]["jaeger_port"]')"      || fail "Could not read jaeger_port"

# ─── stop any existing processes ─────────────────────────────────────────────

stop_port "$API_PORT"
stop_port "$UI_PORT"
stop_port "$ELK_PORT"
stop_port "$PROMETHEUS_PORT"
stop_port "$JAEGER_PORT"
rm -f "$RUNTIME_DIR/backend.pid" "$RUNTIME_DIR/frontend.pid" \
      "$RUNTIME_DIR/elasticsearch.pid" "$RUNTIME_DIR/prometheus.pid" \
      "$RUNTIME_DIR/jaeger.pid"

# ─── start services ───────────────────────────────────────────────────────────

printf 'Starting local Elasticsearch test service on port %s...\n' "$ELK_PORT"
(
  cd "$BACKEND_DIR"
  exec "$PYTHON_BIN" -m uvicorn app.mock_observability:elasticsearch_app \
    --host 0.0.0.0 --port "$ELK_PORT"
) >"$RUNTIME_DIR/elasticsearch.log" 2>&1 &
ELK_PID=$!
printf '%s\n' "$ELK_PID" >"$RUNTIME_DIR/elasticsearch.pid"

printf 'Starting local Prometheus test service on port %s...\n' "$PROMETHEUS_PORT"
(
  cd "$BACKEND_DIR"
  exec "$PYTHON_BIN" -m uvicorn app.mock_observability:prometheus_app \
    --host 0.0.0.0 --port "$PROMETHEUS_PORT"
) >"$RUNTIME_DIR/prometheus.log" 2>&1 &
PROMETHEUS_PID=$!
printf '%s\n' "$PROMETHEUS_PID" >"$RUNTIME_DIR/prometheus.pid"

printf 'Starting local Jaeger test service on port %s...\n' "$JAEGER_PORT"
(
  cd "$BACKEND_DIR"
  exec "$PYTHON_BIN" -m uvicorn app.mock_observability:jaeger_app \
    --host 0.0.0.0 --port "$JAEGER_PORT"
) >"$RUNTIME_DIR/jaeger.log" 2>&1 &
JAEGER_PID=$!
printf '%s\n' "$JAEGER_PID" >"$RUNTIME_DIR/jaeger.pid"

printf 'Starting API on port %s...\n' "$API_PORT"
(
  cd "$BACKEND_DIR"
  exec "$PYTHON_BIN" -m uvicorn app.main:app --host 0.0.0.0 --port "$API_PORT"
) >"$RUNTIME_DIR/backend.log" 2>&1 &
BACKEND_PID=$!
printf '%s\n' "$BACKEND_PID" >"$RUNTIME_DIR/backend.pid"

printf 'Starting web UI on port %s...\n' "$UI_PORT"
(
  cd "$FRONTEND_DIR"
  export PATH="$(dirname "$NODE_BIN"):$PATH"
  exec "$NPM_BIN" run dev -- --host 0.0.0.0 --port "$UI_PORT"
) >"$RUNTIME_DIR/frontend.log" 2>&1 &
FRONTEND_PID=$!
printf '%s\n' "$FRONTEND_PID" >"$RUNTIME_DIR/frontend.pid"

# ─── health-check ─────────────────────────────────────────────────────────────

sleep 1.5
if ! kill -0 "$BACKEND_PID" 2>/dev/null; then
  cat "$RUNTIME_DIR/backend.log" >&2
  fail "API failed to start."
fi
if ! kill -0 "$ELK_PID" 2>/dev/null || ! kill -0 "$PROMETHEUS_PID" 2>/dev/null || ! kill -0 "$JAEGER_PID" 2>/dev/null; then
  cat "$RUNTIME_DIR/elasticsearch.log" "$RUNTIME_DIR/prometheus.log" "$RUNTIME_DIR/jaeger.log" >&2
  fail "One or more local observability test services failed to start."
fi
if ! kill -0 "$FRONTEND_PID" 2>/dev/null; then
  cat "$RUNTIME_DIR/frontend.log" >&2
  fail "Web UI failed to start."
fi

printf '\n✓ Engineering Observability Copilot is running\n'
printf '  Web UI:      http://localhost:%s\n'  "$UI_PORT"
printf '  API:         http://localhost:%s\n'  "$API_PORT"
printf '  API docs:    http://localhost:%s/docs\n' "$API_PORT"
printf '  ELK test:    http://localhost:%s\n'  "$ELK_PORT"
printf '  Prometheus:  http://localhost:%s/-/ready\n' "$PROMETHEUS_PORT"
printf '  Jaeger:      http://localhost:%s/api/services\n' "$JAEGER_PORT"
printf '  Sessions:    %s/sessions/\n'         "$RUNTIME_DIR"
printf '  Logs:        %s/*.log\n\n'            "$RUNTIME_DIR"
trap - EXIT

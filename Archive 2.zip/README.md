# AI Observability Assistant

A production-oriented starter for answering operational questions over Elasticsearch/ELK, Prometheus, and Jaeger. It uses deterministic intent routing before any model call, then gives retrieved, bounded evidence to an internal LLM for summarization.

## Architecture

```text
Browser -> React UI -> FastAPI /api/chat
                         |
                 deterministic intent router
                         |
       ELK MCP tool | Prometheus MCP tool | Jaeger MCP tool
                         |
                    Internal LLM summary
```

Explicit phrases win over scoring: `logs for correlation id` routes to ELK; `trace for correlation id` routes to Jaeger. Kubernetes object queries are deliberately rejected until a Kubernetes tool is configured—Prometheus is not used to list namespaces.

## Quick start (no Docker)

```bash
./start.sh
```

`start.sh` verifies dependencies, stops listeners using the `backend.port` and `frontend.port` values in `config/observability.yaml`, starts both services, and prints their URLs.

For local testing it also starts API-compatible test services at `http://localhost:9200` (Elasticsearch search endpoint) and `http://localhost:9090` (Prometheus query endpoint). They contain synthetic Mule data only: 300 logs under the configurable `mule_logger` root, and CPU, memory, request, failed-pod, and HPA metrics for 10 namespaces with 100 applications each.

For Groq testing, set `llm.api_key` in `config/observability.yaml`; the default base URL and model are already configured. Without a token, the API returns a safe deterministic evidence summary, so connectivity and routing can be tested first.

## Run locally

```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

```bash
cd frontend
npm install && npm run dev
```

## MCP tools

The application invokes typed tools through `ToolRegistry`; each tool has an equivalent MCP definition in `backend/app/mcp_server.py`. Run it independently for MCP-capable clients:

```bash
cd backend
python -m app.mcp_server
```

The tool inputs are intentionally constrained. Do not expose generic Elasticsearch DSL or arbitrary PromQL execution directly to untrusted users without authorization and query policy controls.

## Environment setup

`config/observability.yaml` is the only configuration source. Set the Groq token, cluster endpoints, and matching ELK credentials in this file. Prometheus and Jaeger use read-only HTTP APIs.

## Cluster configuration

`config/observability.yaml` is the single source for cluster endpoints. Every request must include one of the exact configured names: `MULE-UAT`, `MULE-PROD`, `JAVA-UAT`, or `JAVA-PROD`. The backend selects only that entry and rejects unknown names; it never falls back to another cluster. Add production endpoints and ELK credentials only to their matching entry.

## Supported questions

- `Show payment-service errors in the last 30 minutes`
- `Analyze logs for correlation id abc-123`
- `Show trace for correlation id abc-123`
- `What is CPU usage for api-gateway?`
- `Show all namespaces` (returns a clear Kubernetes-not-configured response)

## Next production steps

- Add SSO/RBAC and tenant or namespace authorization before deployment.
- Replace keyword route rules with a tested, versioned intent policy for your organization.
- Add a Kubernetes read-only tool once API access is available.
- Store audit events and redacted request metadata in your approved logging platform.
